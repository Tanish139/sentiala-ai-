/** Sentiala API client (polling-based; upgradeable to SSE later). */

const BASE = "";

async function request(path, options = {}) {
  const response = await fetch(BASE + path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!response.ok) {
    let detail = `HTTP ${response.status}`;
    try {
      const body = await response.json();
      if (body.detail) detail = body.detail;
    } catch { /* keep default */ }
    throw new Error(detail);
  }
  return response.json();
}

export const api = {
  health: () => request("/health"),
  sources: () => request("/api/sources"),
  createInvestigation: (username) =>
    request("/api/investigations", {
      method: "POST",
      body: JSON.stringify({ username }),
    }),
  getInvestigation: (id) => request(`/api/investigations/${id}`),
  listInvestigations: () => request("/api/investigations"),
  reportUrl: (id) => `${BASE}/api/investigations/${id}/report`,
};
