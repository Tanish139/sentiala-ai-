/**
 * Sentiala force-directed network visualization.
 *
 * A dependency-free canvas implementation (works fully offline):
 *  - physics: pairwise repulsion, link springs, radial gravity
 *  - interaction: wheel zoom, drag pan, drag nodes, click to inspect
 *  - animation: pulsing nodes, animated edges, glowing center node
 */

const CATEGORY_COLORS = {
  Social: "#f472b6", Developer: "#4cc9f0", Publishing: "#a78bfa",
  Creative: "#fbbf24", Gaming: "#34d399", Professional: "#5eead4",
  Packages: "#fb923c", Communities: "#60a5fa",
};
const DEFAULT_COLOR = "#5f7085";
const CENTER_COLOR = "#4cc9f0";

export class ForceGraph {
  constructor(canvas, { onNodeClick } = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.onNodeClick = onNodeClick || (() => {});
    this.nodes = [];
    this.links = [];
    this.scale = 1;
    this.offsetX = 0;
    this.offsetY = 0;
    this.alpha = 1;
    this.dragNode = null;
    this.hoverNode = null;
    this.animId = null;
    this._bindEvents();
    this._resizeObserver = new ResizeObserver(() => this._resize());
    this._resizeObserver.observe(canvas.parentElement);
    this._resize();
  }

  // ------------------------------------------------------------- data
  setData(nodes, links) {
    const prev = new Map(this.nodes.map((n) => [n.id, n]));
    this.nodes = nodes.map((n) => {
      const old = prev.get(n.id);
      return {
        ...n,
        x: old ? old.x : (Math.random() - 0.5) * 260,
        y: old ? old.y : (Math.random() - 0.5) * 260,
        vx: old ? old.vx : 0,
        vy: old ? old.vy : 0,
        fixed: n.type === "username",
        birth: old ? old.birth : performance.now(),
      };
    });
    this.links = links;
    this.alpha = 1;
  }

  start() {
    if (this.animId || !this.nodes.length) return;
    const loop = () => {
      this._tick();
      this._render();
      this.animId = requestAnimationFrame(loop);
    };
    this.animId = requestAnimationFrame(loop);
  }

  stop() {
    if (this.animId) cancelAnimationFrame(this.animId);
    this.animId = null;
  }

  hasNodes() {
    return this.nodes.length > 0;
  }

  // ------------------------------------------------------------- physics
  _tick() {
    const damp = 0.86;
    const nodes = this.nodes;
    const repulsion = 2600;
    this.alpha = Math.max(0.05, this.alpha * 0.995);
    const energy = this.alpha;

    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i], b = nodes[j];
        let dx = b.x - a.x, dy = b.y - a.y;
        let d2 = dx * dx + dy * dy;
        if (d2 < 1) { dx = Math.random() - 0.5; dy = Math.random() - 0.5; d2 = 1; }
        const d = Math.sqrt(d2);
        const force = Math.min(6, repulsion / d2) * energy;
        const fx = (dx / d) * force, fy = (dy / d) * force;
        a.vx -= fx; a.vy -= fy;
        b.vx += fx; b.vy += fy;
      }
    }

    for (const link of this.links) {
      const a = this._nodeById(link.source), b = this._nodeById(link.target);
      if (!a || !b) continue;
      const dx = b.x - a.x, dy = b.y - a.y;
      const d = Math.max(1, Math.hypot(dx, dy));
      const rest = link.rest ?? 130;
      const force = (d - rest) * 0.012 * energy;
      const fx = (dx / d) * force, fy = (dy / d) * force;
      a.vx += fx; a.vy += fy;
      b.vx -= fx; b.vy -= fy;
    }

    for (const node of nodes) {
      if (node.fixed) { node.x = 0; node.y = 0; continue; }
      // gentle gravity to center
      node.vx -= node.x * 0.0026 * energy;
      node.vy -= node.y * 0.0026 * energy;
      node.vx *= damp; node.vy *= damp;
      node.x += node.vx; node.y += node.vy;
    }
  }

  _nodeById(id) {
    return this.nodes.find((n) => n.id === id);
  }

  // ------------------------------------------------------------- render
  _render() {
    const ctx = this.ctx;
    const { width, height } = this.canvas;
    const t = performance.now();
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.translate(width / 2 + this.offsetX, height / 2 + this.offsetY);
    ctx.scale(this.scale, this.scale);

    // edges
    for (const link of this.links) {
      const a = this._nodeById(link.source), b = this._nodeById(link.target);
      if (!a || !b) continue;
      const grad = ctx.createLinearGradient(a.x, a.y, b.x, b.y);
      const ca = this._color(a), cb = this._color(b);
      const alpha = 0.22 + 0.10 * Math.sin(t / 700 + a.x);
      grad.addColorStop(0, ca + "55");
      grad.addColorStop(1, cb + "55");
      ctx.strokeStyle = grad;
      ctx.globalAlpha = 0.75;
      ctx.lineWidth = 1 / this.scale + 0.4;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    // nodes
    const sorted = [...this.nodes].sort((a, b) => a.type.localeCompare(b.type));
    for (const node of sorted) {
      const r = this._radius(node, t);
      const color = this._color(node);

      // glow
      const glow = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, r * 3);
      glow.addColorStop(0, color + "44");
      glow.addColorStop(1, color + "00");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(node.x, node.y, r * 3, 0, Math.PI * 2);
      ctx.fill();

      // body
      ctx.fillStyle = "#0a1120";
      ctx.strokeStyle = color;
      ctx.lineWidth = node === this.hoverNode ? 3 : 1.6;
      ctx.beginPath();
      ctx.arc(node.x, node.y, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // inner dot for found nodes
      if (node.type === "source" || node.type === "username") {
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(node.x, node.y, Math.max(1.5, r * 0.3), 0, Math.PI * 2);
        ctx.fill();
      }

      // label
      ctx.font = `${node.type === "username" ? 13 : 10.5}px ui-monospace, monospace`;
      ctx.fillStyle = node === this.hoverNode ? "#eaf3fb" : this._labelColor(node);
      ctx.textAlign = "center";
      ctx.fillText(node.label, node.x, node.y + r + 13);
    }
    ctx.restore();
  }

  _radius(node, t) {
    const base = node.type === "username" ? 24 : node.type === "source" ? 13 : 8;
    const pulse = node.type === "username" ? 1.6 : 1.1;
    return base + Math.sin(t / 600 + (node.birth % 1000)) * pulse;
  }

  _color(node) {
    if (node.type === "username") return CENTER_COLOR;
    if (node.type === "domain") return "#a78bfa";
    return CATEGORY_COLORS[node.category] || DEFAULT_COLOR;
  }

  _labelColor(node) {
    if (node.type === "username") return "#eaf3fb";
    if (node.type === "domain") return "#a78bfa";
    return "#8ea3ba";
  }

  // ------------------------------------------------------------- events
  _bindEvents() {
    const c = this.canvas;
    c.addEventListener("wheel", (e) => {
      e.preventDefault();
      const factor = Math.exp(-e.deltaY * 0.0012);
      const newScale = Math.min(4, Math.max(0.25, this.scale * factor));
      // zoom towards cursor
      const rect = c.getBoundingClientRect();
      const mx = e.clientX - rect.left - rect.width / 2;
      const my = e.clientY - rect.top - rect.height / 2;
      this.offsetX = mx - (mx - this.offsetX) * (newScale / this.scale);
      this.offsetY = my - (my - this.offsetY) * (newScale / this.scale);
      this.scale = newScale;
    }, { passive: false });

    let dragging = false, moved = 0, lastX = 0, lastY = 0;
    c.addEventListener("pointerdown", (e) => {
      dragging = true; moved = 0;
      lastX = e.clientX; lastY = e.clientY;
      const hit = this._hitTest(e);
      this.dragNode = hit;
      c.setPointerCapture(e.pointerId);
    });
    c.addEventListener("pointermove", (e) => {
      const world = this._toWorld(e);
      if (dragging && this.dragNode && !this.dragNode.fixed && moved > 4) {
        this.dragNode.x = world.x; this.dragNode.y = world.y;
        this.dragNode.vx = 0; this.dragNode.vy = 0;
      } else if (dragging) {
        const dx = e.clientX - lastX, dy = e.clientY - lastY;
        moved += Math.abs(dx) + Math.abs(dy);
        if (!this.dragNode) {
          this.offsetX += dx; this.offsetY += dy;
        }
        lastX = e.clientX; lastY = e.clientY;
      }
      this.hoverNode = this._hitTest(e);
      c.style.cursor = this.hoverNode ? "pointer" : dragging ? "grabbing" : "grab";
    });
    c.addEventListener("pointerup", (e) => {
      const wasNode = this.dragNode;
      dragging = false;
      if (moved < 5 && wasNode) this.onNodeClick(wasNode);
      this.dragNode = null;
    });
    c.addEventListener("pointerleave", () => { this.hoverNode = null; });
  }

  _toWorld(e) {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left - rect.width / 2 - this.offsetX) / this.scale,
      y: (e.clientY - rect.top - rect.height / 2 - this.offsetY) / this.scale,
    };
  }

  _hitTest(e) {
    const p = this._toWorld(e);
    let best = null, bestD = Infinity;
    const t = performance.now();
    for (const node of this.nodes) {
      const r = this._radius(node, t) + 6;
      const d = Math.hypot(node.x - p.x, node.y - p.y);
      if (d < r && d < bestD) { best = node; bestD = d; }
    }
    return best;
  }

  _resize() {
    const parent = this.canvas.parentElement;
    if (!parent) return;
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = parent.clientWidth * dpr;
    this.canvas.height = parent.clientHeight * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
}
