/** Deep scan stage stepper - driven 100% by real backend stage status. */

const ICONS = { PENDING: "⏳", RUNNING: "⟳", DONE: "✓", FAILED: "✕" };

export function createDeepScanPanel(container) {
  container.innerHTML = `
    <div class="panel stages-panel">
      <div class="panel-title"><span class="dot"></span> DEEP SCAN SYSTEM
        <span class="right muted" id="stages-hint">real backend stages · no simulation</span>
      </div>
      <div class="stage-track" id="stage-track" role="list" aria-label="Deep scan stages"></div>
    </div>`;

  const track = container.querySelector("#stage-track");
  let built = false;

  function update(data) {
    const stages = data.stages || [];
    if (!stages.length) return;
    if (!built) {
      track.innerHTML = stages
        .map(
          (s) => `
          <div class="stage-step" role="listitem" data-key="${s.key}">
            <span class="stage-node">${ICONS[s.status] || "·"}</span>
            <span class="stage-label">${s.label}</span>
          </div>`
        )
        .join("");
      built = true;
    }
    for (const s of stages) {
      const el = track.querySelector(`[data-key="${s.key}"]`);
      if (!el) continue;
      if (el.dataset.status !== s.status) {
        el.dataset.status = s.status;
        el.className = `stage-step ${s.status.toLowerCase()}`;
        el.querySelector(".stage-node").textContent = ICONS[s.status] || "·";
        if (s.status === "RUNNING") {
          el.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
        }
      }
    }
  }

  return { update };
}
