/** Evidence board: structured, classified evidence items from the backend. */

const FILTERS = [
  ["all", "All"],
  ["DIRECT EVIDENCE", "Direct"],
  ["CORRELATED SIGNAL", "Correlated"],
  ["WEAK SIGNAL", "Weak"],
  ["UNCONFIRMED", "Unconfirmed"],
];

function esc(s) {
  const d = document.createElement("div");
  d.textContent = String(s ?? "");
  return d.innerHTML;
}

const CLASS_BADGE = {
  "DIRECT EVIDENCE": "direct",
  "CORRELATED SIGNAL": "correlated",
  "WEAK SIGNAL": "weak",
  UNCONFIRMED: "unconfirmed",
};

export function createEvidenceBoard(container) {
  let filter = "all";
  let items = [];

  container.innerHTML = `
    <div class="panel">
      <div class="panel-title"><span class="dot"></span> EVIDENCE ANALYSIS
        <span class="right muted" id="evidence-total">0 items</span>
      </div>
      <div class="evidence-filters" id="evidence-filters"></div>
      <div class="evidence-list" id="evidence-list"></div>
    </div>`;

  const filtersBar = container.querySelector("#evidence-filters");
  const list = container.querySelector("#evidence-list");
  const totalEl = container.querySelector("#evidence-total");

  for (const [key, label] of FILTERS) {
    const chip = document.createElement("button");
    chip.type = "button";
    chip.className = "chip" + (key === "all" ? " active" : "");
    chip.textContent = label;
    chip.addEventListener("click", () => {
      filter = key;
      filtersBar.querySelectorAll(".chip").forEach((c) => c.classList.toggle("active", c === chip));
      render();
    });
    filtersBar.appendChild(chip);
  }

  function render() {
    const visible = filter === "all" ? items : items.filter((i) => i.classification === filter);
    totalEl.textContent = `${items.length} items`;
    if (!visible.length) {
      list.innerHTML = `<div class="empty-note" style="padding:20px;text-align:center">${
        items.length ? "no items in this classification" : "no evidence collected yet"
      }</div>`;
      return;
    }
    list.innerHTML = visible.slice(0, 120).map((e, i) => `
      <div class="evidence-item" style="animation-delay:${Math.min(i * 30, 400)}ms">
        <div class="evidence-item-head">
          <span class="evidence-source">${esc(e.source)}</span>
          <span class="badge ${CLASS_BADGE[e.classification] || "weak"}">${e.classification}</span>
          <span class="badge ${e.confidence === "likely" ? "likely" : "weak"}">${esc(e.confidence)}</span>
        </div>
        <div class="evidence-type">${esc(e.evidence_type)}</div>
        <div class="evidence-observed">${esc(e.observed_value)}</div>
        <div class="evidence-why">${esc(e.why_it_matters)}</div>
        <div class="evidence-meta">
          <span>${esc(e.timestamp)}</span>
          ${e.url ? `<a href="${esc(e.url)}" target="_blank" rel="noopener noreferrer">source ↗</a>` : ""}
        </div>
      </div>`).join("") + (visible.length > 120
        ? `<div class="empty-note" style="text-align:center">…and ${visible.length - 120} more (see the full report)</div>`
        : "");
  }

  return {
    update(data) {
      const newItems = data.evidence_items || [];
      if (newItems.length !== items.length || (newItems.length && newItems.some((e, i) => e.observed_value !== items[i]?.observed_value))) {
        items = newItems;
        render();
      }
    },
  };
}
