/** Landing screen: Sentiala brand, username input, ethics note. */
import { api } from "../services/api.js";

export function renderLanding(root, { onStart }) {
  root.innerHTML = `
    <div class="landing">
      <div class="landing-logo">
        <div class="landing-rings"><span></span><span></span><span></span></div>
      </div>
      <h1 class="landing-title">S E N T I A L A</h1>
      <div class="landing-sub">Digital Intelligence System</div>
      <form class="landing-form" id="landing-form" autocomplete="off">
        <input class="landing-input" id="landing-input" type="text"
               placeholder="Enter username..." maxlength="32"
               spellcheck="false" aria-label="Username to investigate">
        <button class="btn primary" id="landing-scan" type="submit">Initialize Scan</button>
      </form>
      <div class="landing-error" id="landing-error" role="alert"></div>
      <div class="landing-tags" id="landing-tags">
        <span class="landing-tag"><b>—</b> sources</span>
        <span class="landing-tag">OSINT</span>
        <span class="landing-tag">AI</span>
        <span class="landing-tag">completely free</span>
      </div>
      <p class="landing-ethics">
        Sentiala researches <b>publicly accessible pages only</b>. It never attempts
        to bypass authentication or access private accounts, and correlations are
        presented as <b>possible signals — never proof of identity</b>.
      </p>
    </div>`;

  // real source count from the backend (no fabricated numbers)
  api.sources()
    .then((info) => {
      const tag = root.querySelector(".landing-tag b");
      if (tag) tag.textContent = info.total_sources + "+";
    })
    .catch(() => {});

  const form = root.querySelector("#landing-form");
  const input = root.querySelector("#landing-input");
  const button = root.querySelector("#landing-scan");
  const error = root.querySelector("#landing-error");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = input.value.trim();
    error.textContent = "";
    if (!username) {
      error.textContent = "Enter a username to initialize a scan.";
      input.focus();
      return;
    }
    button.disabled = true;
    button.textContent = "Initializing...";
    try {
      await onStart(username);
    } catch (err) {
      error.textContent = err.message || "Could not start the investigation.";
      button.disabled = false;
      button.textContent = "Initialize Scan";
    }
  });
  input.focus();
}
