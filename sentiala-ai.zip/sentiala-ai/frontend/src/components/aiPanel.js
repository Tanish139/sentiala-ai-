/** AI analysis panel: animated exposure score, group + component breakdown, summary. */

const GROUP_LABELS = {
  source_coverage: "Source Coverage",
  identity_signals: "Identity Signals",
  cross_platform_correlation: "Cross-Platform Correlation",
  public_information_exposure: "Public Information Exposure",
  geographic_signals: "Geographic Signals",
};

const COMPONENT_LABELS = {
  profile_breadth: "profile breadth",
  category_breadth: "category breadth",
  public_links: "public links",
  metadata_availability: "metadata exposure",
  username_reuse: "username reuse",
  web_discovery: "web discovery",
  domain_diversity: "domain diversity",
};

const COMPONENT_GROUP = {
  profile_breadth: "source_coverage",
  category_breadth: "source_coverage",
  username_reuse: "identity_signals",
  web_discovery: "identity_signals",
  public_links: "public_information_exposure",
  metadata_availability: "public_information_exposure",
  domain_diversity: "public_information_exposure",
};

function countUp(el, target, duration = 1100) {
  const start = parseInt(el.dataset.value || "0", 10);
  if (start === target) return;
  const t0 = performance.now();
  el.dataset.value = String(target);
  const step = (now) => {
    const p = Math.min(1, (now - t0) / duration);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(start + (target - start) * eased);
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

export function createAIPanel(container, { onViewReport }) {
  let renderedOnce = false;
  let lastSignature = "";

  container.innerHTML = `
    <div class="panel ai-panel">
      <div class="panel-title"><span class="dot"></span> AI ANALYSIS
        <span class="right muted">exposure, not identity</span>
      </div>
      <div class="ai-body" id="ai-body">
        <div class="empty-note mono" id="ai-waiting">AWAITING EVIDENCE COLLECTION</div>
      </div>
    </div>`;

  const body = container.querySelector("#ai-body");

  function render(data) {
    const analysis = data.analysis;
    const score = data.score;
    if (!score && !analysis) return;

    const groups = score?.groups || {};
    const comps = score?.components || {};

    const groupRows = Object.entries(groups).map(([k, v]) => `
      <div class="breakdown-row">
        <span>${GROUP_LABELS[k] || k}</span>
        <div class="breakdown-bar"><div class="breakdown-fill" data-fill="${v}"></div></div>
        <span class="breakdown-val">${v}</span>
      </div>`).join("");

    const compRows = Object.entries(comps).map(([k, v]) => `
      <div class="breakdown-row breakdown-sub">
        <span>${COMPONENT_LABELS[k] || k}</span>
        <div class="breakdown-bar"><div class="breakdown-fill" data-fill="${v}"></div></div>
        <span class="breakdown-val">${v}</span>
      </div>`).join("");

    const notes = analysis?.risk_notes?.length
      ? `<div class="ai-notes">${analysis.risk_notes.map((n) => `<div class="ai-note">${n}</div>`).join("")}</div>`
      : "";

    body.innerHTML = `
      <div>
        <div class="ai-score-label">Public footprint · exposure score</div>
        <div class="ai-score-wrap">
          <span class="ai-score" id="ai-score-num" data-value="0">0</span>
          <span class="ai-score-max">/ 100</span>
        </div>
        <div class="score-ring" style="margin-top:8px"><div class="score-ring-fill" id="ai-score-ring"></div></div>
        <div class="ai-meta" style="margin-top:6px">why each group contributed:</div>
      </div>
      ${groupRows ? `<div class="ai-breakdown">${groupRows}</div>` : ""}
      ${compRows ? `<div class="ai-score-label" style="margin-top:4px">detailed components</div><div class="ai-breakdown">${compRows}</div>` : ""}
      ${analysis ? `
        <div>
          <div class="ai-score-label">Summary</div>
          <p class="ai-summary">${analysis.summary}</p>
          <div class="ai-meta" style="margin-top:8px">
            confidence: ${analysis.confidence} · analyzed by ${analysis.analyzed_by}
          </div>
        </div>
        ${notes}
        <div class="ai-ethics"><b>Observed vs inferred.</b> ${analysis.ethics_note}</div>
        <button class="btn" id="ai-view-report" style="align-self:flex-start">View full report →</button>
      ` : ""}`;

    requestAnimationFrame(() => {
      const num = body.querySelector("#ai-score-num");
      if (num && score) countUp(num, score.value);
      const ring = body.querySelector("#ai-score-ring");
      if (ring) ring.style.width = `${score?.value ?? 0}%`;
      body.querySelectorAll(".breakdown-fill").forEach((el) => {
        el.style.width = `${el.dataset.fill}%`;
      });
      const btn = body.querySelector("#ai-view-report");
      if (btn) btn.addEventListener("click", onViewReport);
    });
    renderedOnce = true;
  }

  return {
    update(data) {
      const signature = JSON.stringify([data.score, data.analysis]);
      if (!data.score && !data.analysis) {
        if (!renderedOnce) {
          body.innerHTML = `<div class="empty-note mono">${
            data.status === "RUNNING" ? "COLLECTING PUBLIC EVIDENCE…" : "AWAITING EVIDENCE"
          }</div>`;
        }
        return;
      }
      if (signature !== lastSignature) {
        lastSignature = signature;
        render(data);
      }
    },
  };
}
