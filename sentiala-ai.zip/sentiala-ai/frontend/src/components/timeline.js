/** Investigation stages panel + timeline panel (driven by real backend state). */

export function createStagesPanel(container, categories) {
  container.innerHTML = `
    <div class="panel stages-panel">
      <div class="panel-title"><span class="dot"></span> INVESTIGATION PHASES</div>
      <div class="stage-list" id="stage-list"></div>
    </div>`;
  const list = container.querySelector("#stage-list");
  const stages = [
    { key: "registry", label: "Source registry" },
    ...categories.map((c) => ({ key: `cat:${c}`, label: `${c} sources` })),
    { key: "discovery", label: "Public web search" },
    { key: "metadata", label: "Metadata analysis" },
    { key: "correlation", label: "Correlation" },
    { key: "ai", label: "AI analysis" },
  ];

  function update(data) {
    const rows = stages.map((s) => {
      let state = "pending";
      if (s.key === "registry") state = data.total_sources > 0 ? "done" : "pending";
      else if (s.key.startsWith("cat:")) {
        const cat = s.key.slice(4);
        const catResults = (data.results || []).filter((r) => r.category === cat);
        if (!catResults.length) state = "pending";
        else if (catResults.every((r) => r.status !== "SCANNING")) state = "done";
        else state = "running";
      } else if (s.key === "discovery") {
        state = data.discovery_status === "PENDING" ? "pending"
          : data.discovery_status === "RUNNING" ? "running" : "done";
      } else if (s.key === "metadata") {
        const scanning = (data.results || []).some((r) => r.status === "SCANNING");
        state = data.discovery_status === "PENDING" ? "pending" : scanning ? "running" : "done";
      } else if (s.key === "correlation") {
        state = data.correlation_status === "PENDING" ? "pending"
          : data.correlation_status === "RUNNING" ? "running" : "done";
      } else if (s.key === "ai") {
        state = data.analysis_status === "PENDING" ? "pending"
          : data.analysis_status === "RUNNING" ? "running" : "done";
      }
      const icon = state === "done" ? "✓" : state === "running" ? "⟳" : "⏳";
      return `<div class="stage-row ${state}"><span class="stage-icon">${icon}</span>${s.label.toUpperCase()}</div>`;
    }).join("");
    if (list.dataset.rows !== rows) {
      list.dataset.rows = rows;
      list.innerHTML = rows;
    }
  }
  return { update };
}

export function createTimelinePanel(container) {
  container.innerHTML = `
    <div class="panel timeline-panel">
      <div class="panel-title"><span class="dot"></span> TIMELINE</div>
      <div class="timeline-list" id="timeline-list"></div>
    </div>`;
  const list = container.querySelector("#timeline-list");
  return {
    update(data) {
      const events = data.timeline || [];
      const html = events.map((e) =>
        `<div class="timeline-event"><span class="t">${e.time}</span><span class="m">${e.message}</span></div>`
      ).join("");
      if (list.dataset.count !== String(events.length)) {
        list.dataset.count = String(events.length);
        list.innerHTML = html;
        list.scrollTop = list.scrollHeight;
      }
    },
  };
}
