/** Interactive network visualization panel (custom canvas force graph).

Nodes: TARGET -> PLATFORM -> PUBLIC ATTRIBUTE (shared domains).
Edges carry reasons, surfaced via the correlation modal.
*/
import { ForceGraph } from "../visualizations/forceGraph.js";
import { renderCorrelationModal } from "./report.js";

export function createNetworkGraph(container, { onResultClick, onPlatformClick } = {}) {
  container.innerHTML = `
    <div class="panel graph-panel">
      <div class="panel-title"><span class="dot"></span> CORRELATION GRAPH
        <span class="right muted">target → platform → public attribute</span>
      </div>
      <div class="graph-canvas-wrap">
        <canvas id="graph-canvas"></canvas>
        <div class="graph-legend" id="graph-legend"></div>
        <div class="graph-hint">scroll = zoom · drag = pan · click node = inspect</div>
        <div class="graph-empty" id="graph-empty">AWAITING RESULTS</div>
      </div>
    </div>`;

  const canvas = container.querySelector("#graph-canvas");
  const empty = container.querySelector("#graph-empty");

  const graph = new ForceGraph(canvas, {
    onNodeClick: (node) => {
      if (node.type === "source" && node.result) {
        if (onPlatformClick) onPlatformClick(node.result.platform);
        else if (onResultClick) onResultClick(node.result);
      } else if (node.type === "domain" && node.correlations?.length) {
        renderCorrelationModal(node.correlations, `PUBLIC ATTRIBUTE: ${node.label.toUpperCase()}`);
      }
    },
  });

  // performance: pause the render loop when the tab is hidden
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) graph.stop();
    else if (graph.hasNodes()) graph.start();
  });

  const legend = container.querySelector("#graph-legend");
  legend.innerHTML = [
    ["#4cc9f0", "target username"],
    ["#8ea3ba", "public profile"],
    ["#a78bfa", "public attribute (shared domain)"],
  ].map(([c, l]) => `<div class="legend-item"><span class="legend-swatch" style="background:${c}"></span>${l}</div>`).join("");

  function rebuild(data) {
    const found = (data.results || []).filter((r) => r.status === "FOUND");
    const nodes = [];
    const links = [];
    if (data.username) {
      nodes.push({ id: "__username__", label: data.username, type: "username" });
    }
    for (const r of found) {
      nodes.push({ id: `src:${r.platform}`, label: r.platform, type: "source", category: r.category, result: r });
      links.push({ source: "__username__", target: `src:${r.platform}`, rest: 150 });
    }
    // attribute nodes: shared public domains from correlations
    const domainMap = new Map();
    for (const c of data.correlations || []) {
      if (c.type !== "shared_public_domain") continue;
      if (!domainMap.has(c.signal)) domainMap.set(c.signal, []);
      domainMap.get(c.signal).push(c);
    }
    for (const [domain, corrs] of domainMap) {
      const domainId = `dom:${domain}`;
      nodes.push({ id: domainId, label: domain, type: "domain", correlations: corrs });
      const sources = new Set(corrs.flatMap((c) => [c.source_a, c.source_b]));
      for (const s of sources) {
        links.push({ source: `src:${s}`, target: domainId, rest: 90 });
      }
    }
    if (nodes.length > 1) {
      empty.style.display = "none";
      graph.setData(nodes, links);
      graph.start();
    } else if (data.status === "COMPLETED") {
      empty.style.display = "flex";
      empty.textContent = "NO CONFIRMED PROFILES — NETWORK EMPTY";
      graph.setData([], []);
    }
  }

  return { update: rebuild };
}
