/** Platform intelligence: filterable category groups of expandable detail cards. */

const STATUS_FILTERS = [
  ["all", "All"],
  ["FOUND", "Found"],
  ["NOT_FOUND", "Not found"],
  ["UNCERTAIN", "Uncertain"],
  ["BLOCKED", "Blocked"],
  ["TIMEOUT", "Timeout"],
  ["ERROR", "Error"],
];

const NA = '<span class="na">Not publicly available.</span>';

function esc(s) {
  const d = document.createElement("div");
  d.textContent = String(s ?? "");
  return d.innerHTML;
}

let currentUsername = "";

export function createSourceMatrix(container) {
  let statusFilter = "all";
  let categoryFilter = "all";
  let search = "";
  let results = [];
  let categories = [];
  let listEl = null;


  container.innerHTML = `
    <div class="panel matrix-panel">
      <div class="panel-title"><span class="dot"></span> PLATFORM INTELLIGENCE
        <span class="right muted" id="matrix-total"></span>
      </div>
      <div class="matrix-filters" id="matrix-filters">
        <input class="matrix-search" id="matrix-search" placeholder="search platform…" autocomplete="off" aria-label="Search platforms">
        <select class="matrix-search" id="matrix-category" aria-label="Filter by category" style="max-width:150px;cursor:pointer">
          <option value="all">All categories</option>
        </select>
      </div>
      <div class="matrix-count" id="matrix-count"></div>
      <div class="matrix-list" id="matrix-list"></div>
    </div>`;

  const filtersBar = container.querySelector("#matrix-filters");
  const list = container.querySelector("#matrix-list");
  const searchInput = container.querySelector("#matrix-search");
  const categorySelect = container.querySelector("#matrix-category");
  const countEl = container.querySelector("#matrix-count");
  const totalEl = container.querySelector("#matrix-total");
  const openCards = new Set();

  for (const [key, label] of STATUS_FILTERS) {
    const chip = document.createElement("button");
    chip.type = "button";
    chip.className = "chip" + (key === "all" ? " active" : "");
    chip.dataset.filter = key;
    chip.textContent = label;
    chip.addEventListener("click", () => {
      statusFilter = key;
      filtersBar.querySelectorAll(".chip[data-filter]").forEach((c) => c.classList.toggle("active", c === chip));
      render();
    });
    filtersBar.insertBefore(chip, searchInput);
  }

  categorySelect.addEventListener("change", () => {
    categoryFilter = categorySelect.value;
    render();
  });

  searchInput.addEventListener("input", () => {
    search = searchInput.value.trim().toLowerCase();
    render();
  });

  function matches(r) {
    if (statusFilter !== "all" && r.status !== statusFilter) return false;
    if (categoryFilter !== "all" && r.category !== categoryFilter) return false;
    if (search && !r.platform.toLowerCase().includes(search) && !r.category.toLowerCase().includes(search)) return false;
    return true;
  }

  function detailInner(r) {
    const ev = r.public_evidence || {};
    const checks = [
      ["Username visible", ev.username_found],
      ["Page title available", ev.page_title_available],
      ["Description / bio available", ev.description_available],
      ["Public links available", ev.public_links_available],
      ["Display name available", !!ev.display_name],
      ["Avatar available", !!ev.avatar_url],
    ];
    const links = (ev.public_links || []).slice(0, 8)
      .map((l) => `<a href="${esc(l)}" target="_blank" rel="noopener noreferrer">${esc(l)}</a>`)
      .join("<br>");
    return `
      <div class="plat-detail">
        <dl>
          <dt>Profile URL</dt><dd><a href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${esc(r.url)}</a></dd>
          <dt>Username</dt><dd class="mono">${esc(currentUsername)}</dd>
          <dt>Display name</dt><dd>${ev.display_name ? esc(ev.display_name) : NA}</dd>
          <dt>Public bio</dt><dd>${ev.bio ? esc(ev.bio) : NA}</dd>
          <dt>Public avatar</dt><dd>${ev.avatar_url ? `<img class="avatar-box" src="${esc(ev.avatar_url)}" alt="Public avatar of the ${esc(r.platform)} profile" loading="lazy">` : NA}</dd>
          <dt>Page title</dt><dd>${ev.title ? esc(ev.title) : NA}</dd>
          <dt>Source type</dt><dd>${esc(r.source_type || "—")}</dd>
          <dt>Status</dt><dd><span class="badge ${r.status.toLowerCase()}">${esc(r.status.replace("_", " "))}</span></dd>
          <dt>Confidence</dt><dd style="text-transform:capitalize">${esc(r.confidence)}</dd>
          <dt>Match score</dt><dd>
            <div class="score-line">
              <div class="match-bar"><div class="match-fill" style="width:${r.match_score || 0}%"></div></div>
              <span class="mono">${r.match_score || 0}</span>
            </div>
          </dd>
          <dt>Match explanation</dt><dd>${esc(r.match_explanation || "—")}</dd>
          <dt>Public evidence</dt>
          <dd class="checks">${checks.map(([label, ok]) => `<div class="check-line ${ok ? "" : "off"}">${label}</div>`).join("")}</dd>
          <dt>Response time</dt><dd>${ev.response_time_ms != null ? `${ev.response_time_ms} ms` : NA}</dd>
          <dt>Scan timestamp</dt><dd>${ev.scanned_at ? `${esc(ev.scanned_at)} (server time)` : NA}</dd>
          <dt>Domain</dt><dd>${ev.domain ? esc(ev.domain) : NA}</dd>
          <dt>Limitations</dt><dd>${r.limitations && r.limitations !== "none observed" ? esc(r.limitations) : "none observed"}</dd>
          ${links ? `<dt>Public links</dt><dd style="font-family:var(--mono);font-size:10.5px;line-height:1.8">${links}</dd>` : ""}
        </dl>
        <div style="margin-top:14px">
          <a class="btn small" href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">Open public page ↗</a>
        </div>`;
  }

  function detailHtml(r) {
    return `<div class="plat-detail">${detailInner(r)}</div>`;
  }

  function render() {
    const visible = results.filter(matches);
    const byCat = new Map();
    for (const r of visible) {
      if (!byCat.has(r.category)) byCat.set(r.category, []);
      byCat.get(r.category).push(r);
    }
    totalEl.textContent = `${results.length} sources`;
    countEl.textContent = `${visible.length} shown · ${results.filter((r) => r.status === "FOUND").length} found`;
    if (!byCat.size) {
      list.innerHTML = `<div class="empty-note" style="padding:24px;text-align:center">no platforms match the current filters</div>`;
      return;
    }
    let html = "";
    let idx = 0;
    for (const [cat, rows] of byCat) {
      const found = rows.filter((r) => r.status === "FOUND").length;
      html += `<div class="matrix-cat-header">${esc(cat)} <span class="muted">${found} found · ${rows.length} checked</span></div>`;
      for (const r of rows) {
        const isOpen = openCards.has(r.platform);
        html += `
          <div class="plat-card is-${r.status.toLowerCase()} ${isOpen ? "open" : ""}" data-source="${esc(r.platform)}">
            <button class="plat-head" type="button" aria-expanded="${isOpen}" aria-controls="detail-${esc(r.platform)}">
              <span class="badge ${r.status.toLowerCase()}">${r.status.replace("_", " ")}</span>
              <span class="plat-name">${esc(r.platform)}</span>
              <span class="plat-conf">${r.confidence && r.confidence !== "none" ? esc(r.confidence) : "—"}</span>
              <span class="plat-caret" aria-hidden="true">▶</span>
            </button>
            ${isOpen ? `<div class="plat-detail" id="detail-${esc(r.platform)}">${detailHtml(r)}</div>` : ""}
          </div>`;
        idx++;
      }
    }
    list.innerHTML = html;
    list.querySelectorAll(".plat-head").forEach((head) => {
      head.addEventListener("click", () => {
        const card = head.closest(".plat-card");
        const name = card.dataset.source;
        const r = results.find((x) => x.platform === name);
        if (!r) return;
        if (openCards.has(name)) {
          openCards.delete(name);
          card.classList.remove("open");
          head.setAttribute("aria-expanded", "false");
          const detail = card.querySelector(".plat-detail");
          if (detail) detail.remove();
        } else {
          openCards.add(name);
          card.classList.add("open");
          head.setAttribute("aria-expanded", "true");
          card.insertAdjacentHTML("beforeend", `<div class="plat-detail" id="detail-${esc(name)}">${detailHtml(r)}</div>`);
        }
      });
    });
  }  return {
    focusPlatform(name) {
      // reset filters so the platform is guaranteed visible
      statusFilter = "all";
      categoryFilter = "all";
      if (search) { search = ""; container.querySelector("#matrix-search").value = ""; }
      const catSel = container.querySelector("#matrix-category");
      if (catSel) catSel.value = "all";
      container.querySelectorAll(".chip[data-filter]").forEach((c, i) =>
        c.classList.toggle("active", i === 0));
      openCards.add(name);
      render();
      requestAnimationFrame(() => {
        const card = list.querySelector(`[data-source="${CSS.escape(name)}"]`);
        if (card) card.scrollIntoView({ block: "center", behavior: "smooth" });
      });
    },
    update(data) {
      currentUsername = data.username || currentUsername;
      const newResults = data.results || [];
      const cats = [...new Set(newResults.map((r) => r.category))].sort();
      const changed =
        newResults.length !== results.length ||
        cats.join() !== categories.join() ||
        newResults.some((r, i) => r.status !== results[i]?.status);
      results = newResults;
      if (cats.join() !== categories.join()) {
        categories = cats;
        categorySelect.innerHTML =
          `<option value="all">All categories</option>` +
          cats.map((c) => `<option value="${esc(c)}">${esc(c)}</option>`).join("");
        if (categoryFilter !== "all" && !cats.includes(categoryFilter)) {
          categoryFilter = "all";
          categorySelect.value = "all";
        }
      }
      if (changed) render();
      // live-refresh already-open cards without closing them
      for (const name of openCards) {
        const card = list.querySelector(`[data-source="${CSS.escape(name)}"]`);
        if (card && card.classList.contains("open")) {
          const r = results.find((x) => x.platform === name);
          const detail = card.querySelector(".plat-detail");
          if (r && detail) detail.innerHTML = detailInner(r);
        }
      }
    },
  };
}
