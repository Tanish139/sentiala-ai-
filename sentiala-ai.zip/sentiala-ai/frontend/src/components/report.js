/** Full investigation report modal (uses the shared modal system). */
import { openModal } from "./modal.js";
import { api } from "../services/api.js";

function esc(s) {
  const d = document.createElement("div");
  d.textContent = String(s ?? "");
  return d.innerHTML;
}

export function renderCorrelationModal(correlations, title = "CORRELATION SIGNALS") {
  openModal(title, correlations.map((c) => `
    <div class="corr-item">
      <div class="corr-head">
        <span class="corr-type">${c.type}</span>
        <span class="corr-pair">${c.source_a} ↔ ${c.source_b}</span>
        <span class="badge ${c.confidence === "likely" ? "likely" : "weak"}">${c.confidence}</span>
      </div>
      <div class="corr-expl">${c.explanation}</div>
    </div>`).join("") || `<div class="empty-note">no signals</div>`);
}

export async function renderReportModal(data) {
  const counts = data.counts || {};
  const score = data.score?.value ?? 0;
  const groups = data.score?.groups || {};
  const comps = data.score?.components || {};

  // ---- overview / target ----
  const kv = [
    ["Target username", data.username],
    ["Scan status", data.status],
    ["Started", data.created_at],
    ["Completed", data.completed_at || "—"],
    ["Sources checked", `${counts.checked ?? 0} / ${data.total_sources ?? 0}`],
    ["Profiles discovered", counts.found ?? 0],
    ["Not found", counts.not_found ?? 0],
    ["Uncertain", counts.uncertain ?? 0],
    ["Blocked", counts.blocked ?? 0],
    ["Timeouts", counts.timeout ?? 0],
    ["Errors", counts.error ?? 0],
    ["Categories", counts.categories ?? 0],
    ["Public domains", counts.domains ?? 0],
    ["Correlation signals", counts.correlations ?? 0],
    ["Evidence items", counts.evidence_items ?? 0],
    ["Geo signals", data.geo_signals?.length ?? 0],
    ["Exposure score", `${score} / 100`],
  ].map(([k, v]) => `<div class="report-kv"><div class="k">${k}</div><div class="v">${esc(v)}</div></div>`).join("");

  // ---- platform results (wide table: horizontal scroll) ----
  const results = data.results || [];
  const resultRows = results.map((r) => `
    <tr>
      <td><a href="${r.url}" target="_blank" rel="noopener noreferrer">${esc(r.platform)}</a>
          <div class="muted" style="font-size:10px">${esc(r.category)} · ${esc(r.source_type || "")}</div></td>
      <td><span class="badge ${r.status.toLowerCase()}">${r.status.replace("_", " ")}</span></td>
      <td class="mono" style="color:#8ea3ba">${r.confidence}${r.match_score ? ` · ${r.match_score}` : ""}</td>
    </tr>`).join("");

  // ---- geographic signals ----
  const geoRows = (data.geo_signals || []).map((g) => `
    <tr>
      <td>${esc(g.country)}<div class="muted" style="font-size:10px">${esc(g.signal_type.replace(/_/g, " "))}</div></td>
      <td><a href="${esc(g.url)}" target="_blank" rel="noopener noreferrer">${esc(g.domain)}</a>
          <div class="muted" style="font-size:10px">via ${esc(g.source)}</div></td>
      <td class="muted" style="font-size:11px">${esc(g.explanation)}</td>
    </tr>`).join("");

  // ---- evidence ----
  const evidenceRows = (data.evidence_items || []).slice(0, 60).map((e) => `
    <tr>
      <td>${esc(e.source)}<div class="muted" style="font-size:10px">${esc(e.evidence_type)}</div></td>
      <td><span class="badge ${e.classification === "DIRECT EVIDENCE" ? "direct" : e.classification === "CORRELATED SIGNAL" ? "correlated" : "weak"}">${e.classification}</span></td>
      <td class="muted" style="font-size:11px">${esc(e.observed_value.slice(0, 140))}</td>
    </tr>`).join("");

  // ---- correlations ----
  const corrHtml = (data.correlations || []).map((c) => `
    <div class="corr-item">
      <div class="corr-head">
        <span class="corr-type">${c.type}</span>
        <span class="corr-pair">${c.source_a} ↔ ${c.source_b}</span>
        <span class="badge ${c.confidence === "likely" ? "likely" : "weak"}">${c.confidence}</span>
      </div>
      <div class="corr-expl">${c.explanation}</div>
    </div>`).join("");

  // ---- exposure ----
  const groupRows = Object.entries(groups).map(([k, v]) =>
    `<div class="report-kv"><div class="k">${k.replace(/_/g, " ")}</div><div class="v">${v}</div></div>`).join("");
  const compRows = Object.entries(comps).map(([k, v]) =>
    `<div class="report-kv"><div class="k">${k.replace(/_/g, " ")}</div><div class="v">${v}</div></div>`).join("");

  const a = data.analysis;
  const timelineRows = (data.timeline || []).map((e) =>
    `<tr><td class="mono muted" style="width:90px">${esc(e.time)}</td><td>${esc(e.message)}</td></tr>`).join("");

  const sourceList = results.map((r) => `${r.platform} (${r.status})`).join(" · ");

  openModal(
    "INVESTIGATION REPORT",
    `
    <div class="report-section">
      <h3>Executive Summary</h3>
      <p class="ai-summary">${a?.summary || "Analysis pending — see dashboard."}</p>
      ${a ? `<div class="ai-meta" style="margin-top:8px">confidence: ${a.confidence} · analyzed by ${a.analyzed_by}</div>` : ""}
    </div>
    <div class="report-section">
      <h3>Target & Scan Summary</h3>
      <div class="report-grid">${kv}</div>
    </div>
    <div class="report-section">
      <h3>Platform Results</h3>
      <div class="table-wrap">
        <table class="report-table"><tr><th>Source</th><th>Status</th><th>Confidence</th></tr>${resultRows}</table>
      </div>
    </div>
    <div class="report-section">
      <h3>Geographic Signals</h3>
      ${geoRows
        ? `<div class="table-wrap"><table class="report-table"><tr><th>Country</th><th>Domain</th><th>Signal</th></tr>${geoRows}</table></div>
           <p class="muted" style="font-size:11px">Public geographic signals describe publicly referenced country-code domains — not the account owner's location.</p>`
        : `<div class="empty-note">No reliable public geographic signal detected.</div>`}
    </div>
    <div class="report-section">
      <h3>Evidence</h3>
      ${evidenceRows
        ? `<div class="table-wrap"><table class="report-table"><tr><th>Source</th><th>Classification</th><th>Observed value</th></tr>${evidenceRows}</table></div>`
        : `<div class="empty-note">no structured evidence items were collected</div>`}
    </div>
    <div class="report-section">
      <h3>Correlations — possible signals, never proof</h3>
      ${corrHtml || `<div class="empty-note">no correlation signals were observed</div>`}
    </div>
    <div class="report-section">
      <h3>Exposure Analysis</h3>
      <div class="ai-score-wrap" style="margin-bottom:10px">
        <span class="ai-score" style="font-size:40px">${score}</span>
        <span class="ai-score-max">/ 100</span>
      </div>
      <div class="report-grid" style="grid-template-columns:repeat(auto-fill,minmax(150px,1fr))">${groupRows}</div>
      <p class="muted" style="font-size:11px;margin:10px 0 6px">Detailed components</p>
      <div class="report-grid" style="grid-template-columns:repeat(auto-fill,minmax(150px,1fr))">${compRows}</div>
      <p class="muted" style="font-size:11px">The score describes the breadth of publicly discoverable information for this username — not identity, character or risk.</p>
    </div>
    <div class="report-section">
      <h3>Limitations</h3>
      <ul class="muted" style="font-size:11.5px;line-height:1.8;padding-left:18px">
        <li>Sentiala inspects publicly accessible pages only — no authentication bypass, no rate-limit evasion.</li>
        <li>NOT FOUND means the platform reported no profile to an automated request; blocked, timed-out or JavaScript-only platforms could not be conclusively checked.</li>
        <li>Correlations are possible signals, never proof that accounts belong to the same person.</li>
        <li>Geographic signals describe publicly referenced domains, not the account owner's location.</li>
      </ul>
    </div>
    <div class="report-section">
      <h3>Source List</h3>
      <p class="muted" style="font-size:11px;line-height:2">${esc(sourceList)}</p>
    </div>
    <div class="report-section">
      <h3>Timeline</h3>
      <table class="report-table">${timelineRows}</table>
    </div>`,
    `<button class="btn" id="report-export-json">Export JSON ⤓</button>
     <a class="btn" href="${api.reportUrl(data.id)}" target="_blank" rel="noopener noreferrer">Open HTML report ↗</a>`,
    { wide: true }
  );

  document.getElementById("modal-root")
    .querySelector("#report-export-json")
    .addEventListener("click", () => {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = `sentiala-${data.username}-${data.id}.json`;
      link.click();
      URL.revokeObjectURL(link.href);
    });
}
