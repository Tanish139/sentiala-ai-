/** Target intelligence header: TARGET, scan status, live statistics, real progress. */

export function createTargetHeader(container) {
  container.innerHTML = `
    <div class="panel target-header">
      <div class="target-row">
        <div>
          <div class="target-label">Target</div>
          <div class="target-name" id="target-name">—</div>
        </div>
        <div class="target-status-group">
          <div>
            <div class="target-label">Scan status</div>
            <div class="scan-status-badge RUNNING" id="target-status" role="status">RUNNING</div>
          </div>
          <div>
            <div class="target-label">Deep scan</div>
            <div class="target-name" style="font-size:18px" id="target-progress">0%</div>
          </div>
          <button class="btn small" id="target-new">New scan</button>
          <button class="btn small" id="target-report" style="display:none">Report</button>
        </div>
      </div>
      <div class="progress-bar" style="margin-top:14px" aria-hidden="true">
        <div class="progress-fill" id="target-progress-fill"></div>
      </div>
      <div class="stat-grid" id="target-stats"></div>
    </div>`;

  const nameEl = container.querySelector("#target-name");
  const statusEl = container.querySelector("#target-status");
  const pctEl = container.querySelector("#target-progress");
  const fillEl = container.querySelector("#target-progress-fill");
  const statsEl = container.querySelector("#target-stats");
  const reportBtn = container.querySelector("#target-report");
  let lastCounts = "";

  function update(data) {
    nameEl.textContent = data.username;
    statusEl.textContent = data.status;
    statusEl.className = `scan-status-badge ${data.status}`;
    const pct = data.progress?.percent ?? 0;
    pctEl.textContent = `${pct}%`;
    fillEl.style.width = `${pct}%`;

    const c = data.counts || {};
    const stats = [
      ["Sources", data.total_sources, ""],
      ["Checked", c.checked ?? 0, ""],
      ["Found", c.found ?? 0, "hi"],
      ["Not found", c.not_found ?? 0, ""],
      ["Uncertain", c.uncertain ?? 0, ""],
      ["Blocked", c.blocked ?? 0, "warn"],
      ["Timeout", c.timeout ?? 0, "warn"],
      ["Evidence", c.evidence_items ?? 0, ""],
      ["Correlations", c.correlations ?? 0, ""],
      ["Geo signals", c.geo_countries ?? 0, ""],
    ];
    const key = JSON.stringify(stats);
    if (key !== lastCounts) {
      lastCounts = key;
      statsEl.innerHTML = stats
        .map(
          ([label, value, cls], i) => `
          <div class="stat-card ${cls}" style="animation-delay:${i * 40}ms">
            <div class="k">${label}</div>
            <div class="v">${value}</div>
          </div>`
        )
        .join("");
    }
    if (data.status === "COMPLETED" || data.status === "FAILED") {
      reportBtn.style.display = "";
    }
  }

  return { update, reportBtn, newScanBtn: container.querySelector("#target-new") };
}
