/**
 * WORLD INTELLIGENCE MAP
 *
 * A dependency-free canvas world map rendered from a vendored
 * world-atlas TopoJSON (no network needed at runtime).
 *
 * Only countries with REAL public geographic signals (backend
 * `geo_signals`, derived from ccTLD references in public evidence)
 * are highlighted. Nothing is fabricated, and every signal is
 * labelled a "public geographic signal", never an owner location.
 */

const REDUCED_MOTION = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

/* ---------------- minimal TopoJSON decoder ---------------- */

function decodeTopo(topology) {
  const { transform } = topology;
  const [sx, sy] = transform.scale;
  const [tx, ty] = transform.translate;

  const arcs = topology.arcs.map((arc) => {
    let x = 0, y = 0;
    return arc.map(([dx, dy]) => {
      x += dx; y += dy;
      return [x * sx + tx, y * sy + ty];
    });
  });

  function arcPoints(index) {
    const pts = arcs[index < 0 ? ~index : index];
    return index < 0 ? [...pts].reverse() : pts;
  }

  function ringPoints(ring) {
    const points = [];
    for (const arcIndex of ring) points.push(...arcPoints(arcIndex));
    return points;
  }

  const countries = [];
  for (const geom of topology.objects.countries.geometries) {
    const name = geom.properties?.name || "Unknown";
    if (geom.type === "Polygon") {
      countries.push({ name, polygons: [geom.arcs.map(ringPoints)] });
    } else if (geom.type === "MultiPolygon") {
      countries.push({
        name,
        polygons: geom.arcs.map((poly) => poly.map(ringPoints)),
      });
    }
  }
  return countries;
}

/* point-in-polygon (ray casting) on [lon, lat] points */
function pointInRings(lon, lat, rings) {
  let inside = false;
  for (const ring of rings) {
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const [xi, yi] = ring[i], [xj, yj] = ring[j];
      if ((yi > lat) !== (yj > lat) && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) {
        inside = !inside;
      }
    }
  }
  return inside;
}

/* ---------------- component ---------------- */

export function createWorldMap(container, { openModal }) {
  container.innerHTML = `
    <div class="panel">
      <div class="panel-title"><span class="dot"></span> WORLD INTELLIGENCE MAP
        <span class="right muted">public geographic signals only</span>
      </div>
      <div class="map-wrap">
        <canvas id="map-canvas" aria-label="World map of public geographic signals"></canvas>
        <div class="map-legend">
          <div class="legend-item"><span class="legend-swatch" style="background:#0d1622;border:1px solid #1b2f47"></span>no signal</div>
          <div class="legend-item"><span class="legend-swatch" style="background:rgba(94,234,212,0.7)"></span>public geo signal</div>
        </div>
        <button class="btn small map-reset" id="map-reset">Reset view</button>
        <div class="map-hint">scroll = zoom · drag = pan · click country = details</div>
        <div class="map-empty" id="map-empty" hidden>
          <div class="t">NO RELIABLE PUBLIC GEOGRAPHIC SIGNAL DETECTED.</div>
        </div>
      </div>
      <div class="geo-list" id="geo-list"></div>
    </div>`;

  const canvas = container.querySelector("#map-canvas");
  const ctx = canvas.getContext("2d");
  const emptyEl = container.querySelector("#map-empty");
  const geoList = container.querySelector("#geo-list");

  let countries = [];        // [{name, polygons}]
  let signalsByCountry = new Map();
  let markers = [];          // [{lat, lon, country, count}]
  let scale = 1, offsetX = 0, offsetY = 0;
  let hoverCountry = null;
  let width = 0, height = 0;
  let animId = null;
  let ready = false;
  let lastDataStatus = "";

  const MAP_ASPECT = 2; // width/height of the equirectangular world

  function resize() {
    const parent = canvas.parentElement;
    if (!parent) return;
    const dpr = window.devicePixelRatio || 1;
    width = parent.clientWidth;
    height = parent.clientHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  new ResizeObserver(resize).observe(canvas.parentElement);
  resize();

  // lon/lat -> canvas px (centered, letterboxed to preserve aspect)
  function project(lon, lat) {
    const w = Math.min(width, height * MAP_ASPECT);
    const h = w / MAP_ASPECT;
    const left = (width - w) / 2, top = (height - h) / 2;
    return [
      left + ((lon + 180) / 360) * w,
      top + ((90 - lat) / 180) * h,
    ];
  }
  function unproject(px, py) {
    const w = Math.min(width, height * MAP_ASPECT);
    const h = w / MAP_ASPECT;
    const left = (width - w) / 2, top = (height - h) / 2;
    return [((px - left) / w) * 360 - 180, 90 - ((py - top) / h) * 180];
  }

  /* ---------------- draw loop ---------------- */
  function draw(time) {
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.translate(width / 2 + offsetX, height / 2 + offsetY);
    ctx.scale(scale, scale);
    ctx.translate(-width / 2, -height / 2);

    // graticule
    ctx.strokeStyle = "rgba(28, 60, 94, 0.35)";
    ctx.lineWidth = 0.5 / scale;
    for (let lon = -180; lon <= 180; lon += 30) {
      const a = project(lon, 90), b = project(lon, -90);
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
    }
    for (let lat = -60; lat <= 60; lat += 30) {
      const a = project(-180, lat), b = project(180, lat);
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
    }

    // countries
    for (const country of countries) {
      const highlighted = signalsByCountry.has(country.name);
      const isHover = hoverCountry === country.name;
      ctx.beginPath();
      for (const poly of country.polygons) {
        for (const ring of poly) {
          ring.forEach(([lon, lat], i) => {
            const [x, y] = project(lon, lat);
            i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
          });
          ctx.closePath();
        }
      }
      ctx.fillStyle = highlighted ? "rgba(94, 234, 212, 0.18)" : "rgba(13, 22, 34, 0.9)";
      ctx.fill();
      ctx.strokeStyle = highlighted ? "rgba(94, 234, 212, 0.75)" : "#1b2f47";
      ctx.lineWidth = (highlighted ? 1.1 : 0.6) / scale;
      ctx.stroke();
      if (isHover) {
        ctx.fillStyle = "rgba(76, 201, 240, 0.22)";
        ctx.fill();
      }
    }

    // markers
    const pulse = REDUCED_MOTION ? 0 : Math.sin(time / 500);
    for (const m of markers) {
      const [x, y] = project(m.lon, m.lat);
      if (!REDUCED_MOTION) {
        const halo = ctx.createRadialGradient(x, y, 0, x, y, 16 + pulse * 5);
        halo.addColorStop(0, "rgba(94, 234, 212, 0.35)");
        halo.addColorStop(1, "rgba(94, 234, 212, 0)");
        ctx.fillStyle = halo;
        ctx.beginPath(); ctx.arc(x, y, 16 + pulse * 5, 0, Math.PI * 2); ctx.fill();
      }
      ctx.fillStyle = "#5eead4";
      ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#04121a"; ctx.lineWidth = 1.5 / scale; ctx.stroke();
      // count label
      ctx.font = `${10 / scale}px ui-monospace, monospace`;
      ctx.fillStyle = "#eaf3fb";
      ctx.textAlign = "center";
      ctx.fillText(`${m.country} · ${m.count}`, x, y - 10 / scale);
    }
    ctx.restore();
  }

  function loop(time) {
    draw(time);
    animId = requestAnimationFrame(loop);
  }

  /* ---------------- interactions ---------------- */
  function toCanvasPoint(e) {
    const rect = canvas.getBoundingClientRect();
    return [e.clientX - rect.left, e.clientY - rect.top];
  }
  function toWorld(px, py) {
    return [
      (px - width / 2 - offsetX) / scale + width / 2,
      (py - height / 2 - offsetY) / scale + height / 2,
    ];
  }
  function hitCountry(px, py) {
    const [wx, wy] = toWorld(px, py);
    const [lon, lat] = unproject(wx, wy);
    for (const country of countries) {
      for (const poly of country.polygons) {
        if (pointInRings(lon, lat, poly)) return country.name;
      }
    }
    return null;
  }

  let dragging = false, moved = 0, lastX = 0, lastY = 0;
  canvas.addEventListener("wheel", (e) => {
    e.preventDefault();
    const [px, py] = toCanvasPoint(e);
    const factor = Math.exp(-e.deltaY * 0.0012);
    const newScale = Math.min(12, Math.max(1, scale * factor));
    offsetX = px - width / 2 - ((px - width / 2 - offsetX) * newScale) / scale;
    offsetY = py - height / 2 - ((py - height / 2 - offsetY) * newScale) / scale;
    scale = newScale;
  }, { passive: false });

  canvas.addEventListener("pointerdown", (e) => {
    dragging = true; moved = 0; lastX = e.clientX; lastY = e.clientY;
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener("pointermove", (e) => {
    if (dragging) {
      const dx = e.clientX - lastX, dy = e.clientY - lastY;
      moved += Math.abs(dx) + Math.abs(dy);
      offsetX += dx; offsetY += dy;
      lastX = e.clientX; lastY = e.clientY;
    } else {
      const [px, py] = toCanvasPoint(e);
      hoverCountry = hitCountry(px, py);
      canvas.style.cursor = hoverCountry ? "pointer" : "grab";
    }
  });
  canvas.addEventListener("pointerup", (e) => {
    dragging = false;
    if (moved < 5) {
      const [px, py] = toCanvasPoint(e);
      const name = hitCountry(px, py);
      if (name) openCountryPanel(name);
    }
  });
  canvas.addEventListener("pointerleave", () => { hoverCountry = null; });
  container.querySelector("#map-reset").addEventListener("click", () => {
    scale = 1; offsetX = 0; offsetY = 0;
  });

  /* ---------------- data / panels ---------------- */
  function openCountryPanel(name) {
    const signals = signalsByCountry.get(name);
    const items = signals
      ? signals.map((s) => `
          <div class="corr-item">
            <div class="corr-head">
              <span class="corr-type">${s.signal_type.replace(/_/g, " ")}</span>
              <span class="corr-pair">${s.domain}</span>
              <span class="badge weak">${s.confidence}</span>
            </div>
            <div class="corr-expl">${s.explanation}</div>
            <div class="evidence-meta">
              <span>via <a href="${s.url}" target="_blank" rel="noopener noreferrer">${s.source}</a></span>
            </div>
          </div>`).join("")
      : "";
    openModal(`${name.toUpperCase()} — GEOGRAPHIC SIGNALS`, `
      <div class="report-section">
        <p class="ai-summary">${signals
          ? `The investigation observed <b>${signals.length}</b> public geographic signal(s) associated with <b>${name}</b>.`
          : `No public geographic signal associated with <b>${name}</b> was observed in this investigation.`}</p>
        <p class="muted" style="font-size:11px">A public geographic signal describes publicly referenced domains (for example a country-code TLD on a public profile link). It is <b>not</b> the account owner's location, and it does not prove the account owner lives in or is connected to this country.</p>
        ${items || '<div class="empty-note">No reliable public geographic signal detected.</div>'}
      </div>`);
  }

  function renderGeoList(data) {
    if (!data.geo_signals?.length) {
      geoList.innerHTML = `
        <div class="geo-list-title">Signal list (text alternative)</div>
        <div class="geo-note">No reliable public geographic signal detected. The map remains available for reference; countries are highlighted only when public evidence supports it.</div>`;
      return;
    }
    const byCountry = new Map();
    for (const s of data.geo_signals) {
      if (!byCountry.has(s.country)) byCountry.set(s.country, []);
      byCountry.get(s.country).push(s);
    }
    const rows = [...byCountry.entries()]
      .map(([country, sigs], i) => {
        const platforms = [...new Set(sigs.map((s) => s.source))].join(", ");
        return `
        <div class="geo-country-row" data-country="${country}" tabindex="0" role="button"
             aria-label="Details for ${country}" style="animation-delay:${i * 60}ms">
          <span class="geo-flag">◉</span>
          <span class="geo-country">${country}</span>
          <span class="muted" style="font-size:10.5px">${platforms}</span>
          <span class="geo-count">${sigs.length} signal${sigs.length > 1 ? "s" : ""}</span>
        </div>`;
      })
      .join("");
    geoList.innerHTML = `
      <div class="geo-list-title">Signal list (text alternative)</div>
      ${rows}
      <div class="geo-note">Public geographic signals describe publicly referenced country-code domains. They do not establish the account owner's location.</div>`;
    geoList.querySelectorAll(".geo-country-row").forEach((row) => {
      const open = () => openCountryPanel(row.dataset.country);
      row.addEventListener("click", open);
      row.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
    });
  }

  /* ---------------- public API ---------------- */
  function update(data) {
    // load map data once (vendored, offline)
    if (!ready) {
      fetch("/static/src/assets/world-110m.json")
        .then((r) => r.json())
        .then((topo) => {
          countries = decodeTopo(topo);
          ready = true;
          if (!animId) loop(performance.now());
        })
        .catch(() => {
          geoList.innerHTML = `<div class="geo-note">Map data could not be loaded — use the signal list below.</div>`;
        });
      loop(performance.now());
    }

    const signals = data.geo_signals || [];
    signalsByCountry = new Map();
    for (const s of signals) {
      if (!signalsByCountry.has(s.country)) signalsByCountry.set(s.country, []);
      signalsByCountry.get(s.country).push(s);
    }
    markers = [...signalsByCountry.entries()].map(([country, sigs]) => {
      const first = sigs[0];
      return { country, lat: first.latitude, lon: first.longitude, count: sigs.length };
    });
    emptyEl.hidden = signals.length > 0 || data.status === "RUNNING";
    renderGeoList(data);
    lastDataStatus = data.status;
  }

  return { update };
}
