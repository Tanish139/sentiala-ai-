/** Shared modal helpers used by report, country panels and correlations. */

export function closeModal() {
  const root = document.getElementById("modal-root");
  root.innerHTML = "";
}

export function openModal(title, bodyHtml, footHtml = "", { wide = false } = {}) {
  const root = document.getElementById("modal-root");
  const safeTitle = title.split('"').join("");
  const styleAttr = wide ? "style='width:min(1100px,100%)'" : "";
  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal" ${styleAttr} role="dialog" aria-modal="true" aria-label="${safeTitle}">
        <div class="modal-head">
          <div class="modal-title">${title}</div>
          <button class="evidence-close" id="modal-close" aria-label="Close dialog">✕</button>
        </div>
        <div class="modal-body">${bodyHtml}</div>
        ${footHtml ? `<div class="modal-foot">${footHtml}</div>` : ""}
      </div>
    </div>`;
  root.querySelector("#modal-close").addEventListener("click", closeModal);
  root.querySelector("#modal-overlay").addEventListener("click", (e) => {
    if (e.target.id === "modal-overlay") closeModal();
  });
  document.addEventListener("keydown", function esc(e) {
    if (e.key === "Escape") { closeModal(); document.removeEventListener("keydown", esc); }
  });
  const closeBtn = root.querySelector("#modal-close");
  if (closeBtn) closeBtn.focus();
  return root.querySelector(".modal-body");
}
