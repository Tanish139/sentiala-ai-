/** Live scan feed - real backend events only.

Feed lines are derived from two genuine sources:
1. result status transitions observed between polls (Checking X → outcome)
2. backend timeline events (stage completions, discovery, correlation...)

Nothing is synthesized for animation; when nothing happens, nothing is added.
*/

export function createLiveFeed(container) {
  container.innerHTML = `
    <div class="panel feed-panel">
      <div class="panel-title"><span class="dot"></span> LIVE SCAN FEED
        <span class="right muted" id="feed-count">0 events</span>
      </div>
      <div class="feed-list" id="feed-list" role="log" aria-live="polite" aria-label="Live scan activity"></div>
    </div>`;

  const list = container.querySelector("#feed-list");
  const counter = container.querySelector("#feed-count");
  const seen = new Set();
  const MAX_ITEMS = 200;

  function stamp() {
    return new Date().toLocaleTimeString("en-GB", { hour12: false });
  }

  function add(kind, message) {
    const line = `${kind}|${message}`;
    if (seen.has(line)) return;
    seen.add(line);
    const item = document.createElement("div");
    item.className = `feed-item ${kind}`;
    item.innerHTML = `<span class="t">${stamp()}</span><span class="m"></span>`;
    item.querySelector(".m").textContent = message;
    list.appendChild(item);
    while (list.children.length > MAX_ITEMS) list.removeChild(list.firstChild);
    list.scrollTop = list.scrollHeight;
    counter.textContent = `${list.children.length} events`;
  }

  const OUTCOME = {
    FOUND: ["good", "Public profile discovered - evidence extracted"],
    NOT_FOUND: ["bad", "No public profile found"],
    UNCERTAIN: ["warn", "Page reachable but username not visible (uncertain)"],
    BLOCKED: ["warn", "Request blocked or redirected by the platform"],
    TIMEOUT: ["warn", "Source timed out"],
    ERROR: ["warn", "Source error (not interpreted as 'not found')"],
  };

  function update(data) {
    // 1. platform transitions we have not logged yet
    for (const r of data.results || []) {
      const state = r.status;
      if (state === "SCANNING") {
        add("sys", `Scanning ${r.platform}…`);
      } else {
        const [kind, msg] = OUTCOME[state] || ["", state];
        add(kind || "", `${r.platform}: ${msg}`);
      }
    }
    // 2. backend timeline events
    for (const e of data.timeline || []) {
      add("sys", e.message);
    }
  }

  return { update };
}
