/**
 * Sentiala AI — application controller (v3 deep-scan dashboard).
 *
 * Polling architecture (clean, upgradeable to WebSockets/SSE later):
 * the UI polls GET /api/investigations/{id} and every animation
 * reflects REAL backend state. Nothing is faked.
 *
 * Layout is scroll-first: the whole dashboard is one naturally
 * scrolling page with a sticky header; only lists inside panels
 * have contained scroll areas.
 */
import { api } from "./services/api.js";
import { renderLanding } from "./components/landing.js";
import { createTargetHeader } from "./components/targetHeader.js";
import { createDeepScanPanel } from "./components/deepScan.js";
import { createSourceMatrix } from "./components/sourceMatrix.js";
import { createWorldMap } from "./components/worldMap.js";
import { createNetworkGraph } from "./components/networkGraph.js";
import { createLiveFeed } from "./components/liveFeed.js";
import { createAIPanel } from "./components/aiPanel.js";
import { createEvidenceBoard } from "./components/evidenceBoard.js";
import { createTimelinePanel } from "./components/timeline.js";
import { renderReportModal } from "./components/report.js";
import { openModal } from "./components/modal.js";
import { startParticles } from "./animations/particles.js";

const POLL_MS = 1200;

const landingScreen = document.getElementById("screen-landing");
const dashScreen = document.getElementById("screen-dashboard");

let pollTimer = null;
let pollFailures = 0;

// ------------------------------------------------------------- ambient
startParticles(document.getElementById("bg-particles"));

// ------------------------------------------------------------- flow
renderLanding(landingScreen, {
  onStart: async (username) => {
    const created = await api.createInvestigation(username);
    openDashboard(created.id, username);
  },
});

// Deep links:
//   #investigate=<username>  start a new investigation
//   #view=<investigation id> open an existing (stored) investigation
//   ?scroll=bottom           scroll to the page bottom once loaded
const urlParams = new URLSearchParams(location.search);
const deepLink = location.hash.match(/^#investigate=(.+)$/);
const viewLink = location.hash.match(/^#view=([0-9a-zA-Z]+)$/);
if (deepLink) {
  const name = decodeURIComponent(deepLink[1]);
  api.createInvestigation(name)
    .then((created) => openDashboard(created.id, name))
    .catch(() => {});
} else if (viewLink) {
  openDashboard(viewLink[1], null);
} else if (urlParams.get("scroll")) {
  const target = urlParams.get("scroll");
  window.addEventListener("load", () => {
    const y = target === "bottom" ? document.body.scrollHeight : parseInt(target, 10) || 0;
    window.scrollTo({ top: y, behavior: "instant" });
  });
}

function openDashboard(id, username) {
  landingScreen.hidden = true;
  dashScreen.hidden = false;
  // return to the top whenever a new dashboard opens
  window.scrollTo({ top: 0, behavior: "instant" });

  dashScreen.innerHTML = `
    <div class="dash">
      <div class="dash-header panel" id="dash-header">
        <span class="dash-brand">SENTIALA<span class="ai">·AI</span></span>
        <span class="dash-user" id="dash-user-name">${username || "…"}</span>
        <span class="badge" id="dash-status">RUNNING</span>
        <span class="badge" id="dash-stages-mini"></span>
        <button class="btn small" id="dash-new">New scan</button>
        <div class="dash-progress-wrap">
          <div class="progress-bar"><div class="progress-fill" id="dash-progress"></div></div>
          <div class="progress-label">
            <span id="dash-progress-text">INITIALIZING INVESTIGATION</span>
            <span id="dash-progress-percent">0%</span>
          </div>
        </div>
      </div>

      <div id="target-slot"></div>
      <div id="stages-slot"></div>

      <div class="dash-body">
        <div id="matrix-slot"></div>
        <div id="feed-slot"></div>
        <div class="span-12" id="map-slot"></div>
        <div id="graph-slot"></div>
        <div id="ai-slot"></div>
        <div class="span-12" id="evidence-slot"></div>
        <div class="span-12" id="timeline-slot"></div>
      </div>
    </div>`;

  // ------------------------------------------------------ components
  const target = createTargetHeader(dashScreen.querySelector("#target-slot"));
  const stages = createDeepScanPanel(dashScreen.querySelector("#stages-slot"));
  const matrix = createSourceMatrix(dashScreen.querySelector("#matrix-slot"));
  const feed = createLiveFeed(dashScreen.querySelector("#feed-slot"));
  const map = createWorldMap(dashScreen.querySelector("#map-slot"), { openModal });
  const graph = createNetworkGraph(dashScreen.querySelector("#graph-slot"), {
    openModal,
    onPlatformClick: (name) => matrix.focusPlatform(name),
  });
  const ai = createAIPanel(dashScreen.querySelector("#ai-slot"), {
    onViewReport: () => fetchAndRenderReport(),
  });
  const evidence = createEvidenceBoard(dashScreen.querySelector("#evidence-slot"));
  const timeline = createTimelinePanel(dashScreen.querySelector("#timeline-slot"));

  const newScan = () => {
    stopPolling();
    dashScreen.hidden = true;
    landingScreen.hidden = false;
    window.scrollTo({ top: 0 });
    renderLanding(landingScreen, {
      onStart: async (username) => {
        const created = await api.createInvestigation(username);
        openDashboard(created.id, username);
      },
    });
  };
  dashScreen.querySelector("#dash-new").addEventListener("click", newScan);
  target.newScanBtn.addEventListener("click", newScan);
  target.reportBtn.addEventListener("click", () => fetchAndRenderReport());

  // ------------------------------------------------------ polling
  let didAutoScroll = false;
  const scrollParam = urlParams.get("scroll");

  function autoScroll() {
    if (didAutoScroll || scrollParam === null) return;
    didAutoScroll = true;
    const y = scrollParam === "bottom" ? document.body.scrollHeight : parseInt(scrollParam, 10) || 0;
    requestAnimationFrame(() => window.scrollTo({ top: y, behavior: "instant" }));
  }

  function updateAll(data) {
    const status = dashScreen.querySelector("#dash-status");
    status.textContent = data.status;
    status.className = `badge ${data.status === "COMPLETED" ? "found" : data.status === "FAILED" ? "error" : "scanning"}`;

    const nameSpan = dashScreen.querySelector("#dash-user-name");
    if (nameSpan && data.username && nameSpan.textContent !== data.username) {
      nameSpan.textContent = data.username;
    }

    const runningStages = (data.stages || []).filter((s) => s.status === "RUNNING").length;
    const doneStages = (data.stages || []).filter((s) => s.status === "DONE").length;
    const mini = dashScreen.querySelector("#dash-stages-mini");
    mini.textContent = `DEEP SCAN ${doneStages}/10${runningStages ? " · RUNNING" : ""}`;

    const pct = data.progress?.percent ?? 0;
    dashScreen.querySelector("#dash-progress").style.width = `${pct}%`;
    dashScreen.querySelector("#dash-progress-percent").textContent = `${pct}%`;
    dashScreen.querySelector("#dash-progress-text").textContent =
      data.status === "RUNNING"
        ? `SCANNING ${data.progress?.completed ?? 0} / ${data.progress?.total ?? 0} SOURCES`
        : data.status === "COMPLETED" ? "INVESTIGATION COMPLETE" : "INVESTIGATION FAILED";

    target.update(data);
    stages.update(data);
    matrix.update(data);
    feed.update(data);
    map.update(data);
    graph.update(data);
    evidence.update(data);
    ai.update(data);
    timeline.update(data);

    if (data.status === "COMPLETED" || data.status === "FAILED") {
      stopPolling();
    }

    // ?scroll=<px|bottom>: jump to a scroll position after the first render
    autoScroll();
  }

  async function poll() {
    try {
      const data = await api.getInvestigation(id);
      pollFailures = 0;
      updateAll(data);
    } catch {
      // tolerate transient errors, stop after repeated failures
      pollFailures += 1;
      if (pollFailures > 5) stopPolling();
    }
  }

  function stopPolling() {
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  }

  async function fetchAndRenderReport() {
    const data = await api.getInvestigation(id);
    renderReportModal(data);
  }

  poll();
  pollTimer = setInterval(poll, POLL_MS);
}
