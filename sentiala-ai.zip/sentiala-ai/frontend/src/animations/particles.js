/** Ambient background particles: slow drifting data motes on a canvas.
 *  Performance: capped count, paused when the tab is hidden or when the
 *  user prefers reduced motion (a single static frame is drawn instead).
 */

const REDUCED_MOTION = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

export function startParticles(canvas) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  let w, h, particles = [];

  function resize() {
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
  }
  window.addEventListener("resize", resize);
  resize();

  const count = Math.min(50, Math.floor(window.innerWidth / 30));
  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.6 + 0.4,
      vx: (Math.random() - 0.5) * 0.15,
      vy: (Math.random() - 0.5) * 0.15,
      a: Math.random() * 0.35 + 0.08,
      phase: Math.random() * Math.PI * 2,
    });
  }

  let running = !REDUCED_MOTION;

  function frame(t) {
    ctx.clearRect(0, 0, w, h);
    for (const p of particles) {
      if (running) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < -5) p.x = w + 5; if (p.x > w + 5) p.x = -5;
        if (p.y < -5) p.y = h + 5; if (p.y > h + 5) p.y = -5;
      }
      const alpha = p.a * (running ? 0.6 + 0.4 * Math.sin(t / 900 + p.phase) : 0.8);
      ctx.fillStyle = `rgba(76, 201, 240, ${alpha.toFixed(3)})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  document.addEventListener("visibilitychange", () => {
    running = !document.hidden && !REDUCED_MOTION;
  });
}
