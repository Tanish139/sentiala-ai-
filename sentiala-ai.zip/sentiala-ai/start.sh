#!/usr/bin/env bash
# ============================================================
#  SENTIALA AI - one-command launcher (Kali / Linux / macOS)
#
#  Cloned -> ./start.sh -> browser opens Sentiala.
#  Completely free. No accounts, no keys required.
# ============================================================
set -e

cd "$(dirname "$0")"

# --- config --------------------------------------------------
HOST="${SENTIALA_HOST:-127.0.0.1}"
PORT="${SENTIALA_PORT:-8765}"
URL="http://$HOST:$PORT"
VENV=".venv"

# --- banner --------------------------------------------------
clear
cat <<'BANNER'
   _____ _   _ _____    _    _   _ _____ _____ ____
  / ____| \ | |  __ \  / \  | \ | |_   _| ____/ __ \
 | (___ |  \| | |  | |/ _ \ |  \| | | | | |__ | |  | |
  \___ \| .   | |  | / ___ \| .   | | | |  __|| |  | |
  ____) | |\  | |__| / /   \ \ |\  |_| |_|    | |__| |
 |_____/|_| \_|_____/_/     \_| \_|_____|_|     \____/

   completely free · ethical OSINT · 100+ public sources
BANNER

# --- python --------------------------------------------------
if ! command -v python3 >/dev/null 2>&1; then
    echo "[!] python3 is required but was not found."; exit 1
fi

# --- virtual environment + dependencies ----------------------
if [ ! -d "$VENV" ]; then
    echo "[*] Creating virtual environment..."
    python3 -m venv "$VENV"
fi
# shellcheck disable=SC1091
source "$VENV/bin/activate"

echo "[*] Installing/updating dependencies (fast if already installed)..."
pip install -q --upgrade pip >/dev/null 2>&1 || true
pip install -q -r requirements.txt
echo "[+] Dependencies ready."

# --- load optional environment --------------------------------
if [ -f .env ]; then
    set -a; source .env; set +a
    echo "[+] Loaded .env (optional external AI config)."
fi

# --- start ----------------------------------------------------
echo "[*] Starting Sentiala on $URL"
echo "[*] Press Ctrl+C to stop."

# open the browser once the server is up (best effort)
(
    sleep 2
    if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL" >/dev/null 2>&1 || true
    elif command -v sensible-browser >/dev/null 2>&1; then sensible-browser "$URL" >/dev/null 2>&1 || true
    fi
) &

exec python -m uvicorn backend.app.main:app --host "$HOST" --port "$PORT"
