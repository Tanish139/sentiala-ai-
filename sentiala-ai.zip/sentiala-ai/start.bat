@echo off
REM ============================================================
REM  SENTIALA AI - one-command launcher (Windows)
REM  Cloned -> start.bat -> browser opens Sentiala.
REM ============================================================
setlocal
cd /d "%~dp0"

set HOST=127.0.0.1
set PORT=8765
set URL=http://%HOST%:%PORT%

echo    _____ _   _ _____    _    _   _ _____ _____ ____
echo   / ____^| \ ^| ^|  __ \  / \  ^| \ ^| ^|_   ^|^| ____/ __ \
echo  ^| (___ ^|  ^\^| ^| ^|  ^| ^|/ _ \ ^|  ^\^| ^| ^| ^|^| ^|__^| ^|  ^| ^|
echo   \___ \^| .   ^| ^|  ^| / ___ \^| .   ^| ^| ^|^|  __^|^| ^|  ^| ^|
echo  ____) ^| ^|\  ^| ^|__^|/ /   \ \ ^|\  ^|_^| ^|_^|    ^| ^|__^| ^|
echo ^|_____/^|_^| \_^|_____/_/     \_^| \_^|_____^|_^|     \____/
echo.
echo    completely free - ethical OSINT - 100+ public sources
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [!] python is required but was not found. Install Python 3.10+ from python.org
    pause
    exit /b 1
)

if not exist .venv (
    echo [*] Creating virtual environment...
    python -m venv .venv
)
call .venv\Scripts\activate.bat

echo [*] Installing dependencies...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt
echo [+] Dependencies ready.

if exist .env (
    echo [+] Loading .env
    for /f "usebackq eol=# tokens=1,* delims==" %%a in (".env") do set "%%a=%%b"
)

echo [*] Starting Sentiala on %URL%
start "" %URL%
python -m uvicorn backend.app.main:app --host %HOST% --port %PORT%
endlocal
