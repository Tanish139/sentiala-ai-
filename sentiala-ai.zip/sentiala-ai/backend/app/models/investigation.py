"""Data models: the investigation aggregate."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field

from .source import Correlation, DiscoveryResult, SourceResult

INVESTIGATION_STATES = ("RUNNING", "COMPLETED", "FAILED")

# The deep-scan pipeline stages, in execution order. Each stage maps to
# real work in the engine - the UI visualises these as they genuinely
# transition from PENDING -> RUNNING -> DONE.
DEEP_SCAN_STAGES = [
    ("initializing", "Initializing"),
    ("source_discovery", "Source Discovery"),
    ("platform_validation", "Platform Validation"),
    ("profile_extraction", "Public Profile Extraction"),
    ("variant_discovery", "Username Variant Discovery"),
    ("evidence_collection", "Evidence Collection"),
    ("correlation", "Cross-Source Correlation"),
    ("geographic", "Geographic Signal Analysis"),
    ("exposure", "Exposure Analysis"),
    ("report", "Report Generation"),
]


def _now() -> str:
    return time.strftime("%H:%M:%S")


def _ts() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


@dataclass
class TimelineEvent:
    time: str
    message: str

    def to_dict(self) -> dict:
        return {"time": self.time, "message": self.message}


@dataclass
class GeoSignal:
    """One publicly observable geographic signal.

    IMPORTANT: a geo signal is evidence such as a country-code domain
    referenced on a public page. It is NOT the account owner's location.
    """

    country: str
    country_code: str
    latitude: float
    longitude: float
    signal_type: str          # e.g. "country_code_domain"
    domain: str
    source: str               # platform or "Public web discovery"
    url: str
    confidence: str           # weak | possible
    explanation: str

    def to_dict(self) -> dict:
        return {
            "country": self.country,
            "country_code": self.country_code,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "signal_type": self.signal_type,
            "domain": self.domain,
            "source": self.source,
            "url": self.url,
            "confidence": self.confidence,
            "explanation": self.explanation,
        }


@dataclass
class EvidenceItem:
    """One structured evidence line, classified by strength.

    Classification:
    - DIRECT EVIDENCE: directly observed on a public platform page.
    - CORRELATED SIGNAL: relationship between two public pages.
    - WEAK SIGNAL: reachable but unverified, or low-confidence match.
    - UNCONFIRMED: publicly indexed search hit, not platform-verified.
    """

    source: str
    classification: str       # DIRECT EVIDENCE | CORRELATED SIGNAL | WEAK SIGNAL | UNCONFIRMED
    evidence_type: str        # e.g. "username match", "public bio"
    observed_value: str
    url: str
    timestamp: str
    confidence: str
    why_it_matters: str

    def to_dict(self) -> dict:
        return {
            "source": self.source,
            "classification": self.classification,
            "evidence_type": self.evidence_type,
            "observed_value": self.observed_value,
            "url": self.url,
            "timestamp": self.timestamp,
            "confidence": self.confidence,
            "why_it_matters": self.why_it_matters,
        }


@dataclass
class ExposureScore:
    value: int
    components: dict[str, int]
    groups: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"value": self.value, "components": self.components, "groups": self.groups}


@dataclass
class AnalysisReport:
    summary: str = ""
    exposure_score: int = 0
    risk_notes: list[str] = field(default_factory=list)
    confidence: str = "none"
    analyzed_by: str = "local-evidence-analysis"  # or "external-ai"
    ethics_note: str = (
        "Analysis is based only on collected public evidence. Correlations are "
        "possible signals, not proof of identity."
    )

    def to_dict(self) -> dict:
        return {
            "summary": self.summary,
            "exposure_score": self.exposure_score,
            "risk_notes": self.risk_notes,
            "confidence": self.confidence,
            "analyzed_by": self.analyzed_by,
            "ethics_note": self.ethics_note,
        }


@dataclass
class Investigation:
    """Full state of one username investigation."""

    id: str
    username: str
    status: str = "RUNNING"
    created_at: str = field(default_factory=_ts)
    completed_at: str | None = None
    results: list[SourceResult] = field(default_factory=list)
    result_index: dict[str, SourceResult] = field(default_factory=dict)
    discovery: list[DiscoveryResult] = field(default_factory=list)
    discovery_status: str = "PENDING"  # PENDING | RUNNING | DONE | FAILED
    variants: list[str] = field(default_factory=list)
    correlations: list[Correlation] = field(default_factory=list)
    correlation_status: str = "PENDING"
    geo_signals: list[GeoSignal] = field(default_factory=list)
    geo_status: str = "PENDING"
    evidence_items: list[EvidenceItem] = field(default_factory=list)
    evidence_status: str = "PENDING"
    analysis: AnalysisReport | None = None
    analysis_status: str = "PENDING"
    score: ExposureScore | None = None
    timeline: list[TimelineEvent] = field(default_factory=list)
    stage_status: dict[str, str] = field(
        default_factory=lambda: {key: "PENDING" for key, _ in DEEP_SCAN_STAGES}
    )
    total_sources: int = 0
    error: str | None = None

    # ------------------------------------------------------------------
    @classmethod
    def create(cls, username: str) -> "Investigation":
        return cls(id=uuid.uuid4().hex[:12], username=username)

    def add_event(self, message: str) -> None:
        self.timeline.append(TimelineEvent(_now(), message))

    def add_result(self, result: SourceResult) -> None:
        existing = self.result_index.get(result.source)
        if existing is not None:
            # Deduplicate: keep the first completed result per source.
            if existing.status == "SCANNING":
                self.results[self.results.index(existing)] = result
                self.result_index[result.source] = result
            return
        self.results.append(result)
        self.result_index[result.source] = result

    # ------------------------------------------------------- deep stages
    def set_stage(self, key: str, status: str) -> None:
        if key in self.stage_status:
            self.stage_status[key] = status

    def stage_list(self) -> list[dict]:
        return [
            {"key": key, "label": label, "status": self.stage_status.get(key, "PENDING")}
            for key, label in DEEP_SCAN_STAGES
        ]

    # ------------------------------------------------------------------
    @property
    def completed_count(self) -> int:
        return sum(1 for r in self.results if r.status != "SCANNING")

    @property
    def found_count(self) -> int:
        return sum(1 for r in self.results if r.status == "FOUND")

    @property
    def status_counts(self) -> dict[str, int]:
        counts = dict.fromkeys(("FOUND", "NOT_FOUND", "UNCERTAIN", "BLOCKED", "TIMEOUT", "ERROR"), 0)
        for r in self.results:
            if r.status in counts:
                counts[r.status] += 1
        return counts

    @property
    def evidence_count(self) -> int:
        return sum(
            sum(
                (
                    r.evidence.username_found,
                    r.evidence.page_title_available,
                    r.evidence.description_available,
                    r.evidence.public_links_available,
                    bool(r.evidence.display_name),
                    bool(r.evidence.bio),
                    bool(r.evidence.avatar_url),
                )
            )
            for r in self.results
            if r.status == "FOUND"
        )

    @property
    def categories_found(self) -> list[str]:
        return sorted({r.category for r in self.results if r.status == "FOUND"})

    @property
    def public_domains(self) -> list[str]:
        return sorted({r.evidence.domain for r in self.results if r.status == "FOUND" and r.evidence.domain})

    @property
    def geo_country_count(self) -> int:
        return len({g.country for g in self.geo_signals})

    def category_progress(self) -> dict[str, dict[str, int]]:
        """Per-category pending/running/done counts, for real progress UI."""
        progress: dict[str, dict[str, int]] = {}
        for result in self.results:
            bucket = progress.setdefault(result.category, {"done": 0, "total": 0})
            bucket["total"] += 1
            if result.status != "SCANNING":
                bucket["done"] += 1
        return progress

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "username": self.username,
            "status": self.status,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "total_sources": self.total_sources,
            "stages": self.stage_list(),
            "variants": self.variants,
            "progress": {
                "completed": self.completed_count,
                "total": self.total_sources or len(self.results),
                "percent": int(100 * self.completed_count / self.total_sources) if self.total_sources else 0,
            },
            "counts": {
                "found": self.found_count,
                "checked": self.completed_count,
                "not_found": self.status_counts["NOT_FOUND"],
                "uncertain": self.status_counts["UNCERTAIN"],
                "blocked": self.status_counts["BLOCKED"],
                "timeout": self.status_counts["TIMEOUT"],
                "error": self.status_counts["ERROR"],
                "categories": len(self.categories_found),
                "domains": len(self.public_domains),
                "correlations": len(self.correlations),
                "discovery_hits": len(self.discovery),
                "evidence_items": len(self.evidence_items),
                "geo_countries": self.geo_country_count,
            },
            "results": [r.to_dict() for r in self.results],
            "discovery_status": self.discovery_status,
            "discovery": [d.to_dict() for d in self.discovery],
            "correlation_status": self.correlation_status,
            "correlations": [c.to_dict() for c in self.correlations],
            "geo_status": self.geo_status,
            "geo_signals": [g.to_dict() for g in self.geo_signals],
            "evidence_status": self.evidence_status,
            "evidence_items": [e.to_dict() for e in self.evidence_items],
            "analysis_status": self.analysis_status,
            "analysis": self.analysis.to_dict() if self.analysis else None,
            "score": self.score.to_dict() if self.score else None,
            "timeline": [e.to_dict() for e in self.timeline],
            "error": self.error,
        }
