"""Data models: source definitions and scan results."""

from __future__ import annotations

import time
from dataclasses import dataclass, field

# Possible per-source states. An HTTP error is NEVER interpreted as
# proof that a profile does not exist.
SOURCE_STATES = ("SCANNING", "FOUND", "NOT_FOUND", "UNCERTAIN", "BLOCKED", "ERROR", "TIMEOUT")

CONFIDENCE_LEVELS = ("high", "medium", "low", "none")


@dataclass(frozen=True)
class SourceSpec:
    """A single public source in the registry.

    Attributes:
        name:        Human readable platform name.
        category:    Registry category (Social, Developer, ...).
        url_template: ``{u}`` is replaced with the username.
        reliability: How reliably this platform's HTTP response
                     indicates profile existence.
        error_hints: Lowercase substrings which, when present in the
                     page body, indicate "profile does not exist".
        probe_only:  If True, the URL is a public search/lookup page;
                     results are reported with lower confidence.
    """

    name: str
    category: str
    url_template: str
    reliability: str = "medium"
    error_hints: tuple[str, ...] = ()
    probe_only: bool = False

    @property
    def source_type(self) -> str:
        return "public search/lookup page" if self.probe_only else "public profile page"

    def build_url(self, username: str) -> str:
        return self.url_template.replace("{u}", username)


@dataclass
class Evidence:
    """Structured, observed public evidence for one source result."""

    username_found: bool = False
    page_title_available: bool = False
    description_available: bool = False
    public_links_available: bool = False
    title: str | None = None
    description: str | None = None
    domain: str | None = None
    final_url: str | None = None
    http_status: int | None = None
    public_links: list[str] = field(default_factory=list)
    redirect_followed: bool = False

    # ---- deep-scan detail (filled by the enrichment pass) ----
    display_name: str | None = None
    bio: str | None = None
    avatar_url: str | None = None
    og_site_name: str | None = None
    response_time_ms: int | None = None
    scanned_at: str | None = None

    def to_dict(self) -> dict:
        return {
            "username_found": self.username_found,
            "page_title_available": self.page_title_available,
            "description_available": self.description_available,
            "public_links_available": self.public_links_available,
            "title": self.title,
            "description": self.description,
            "domain": self.domain,
            "final_url": self.final_url,
            "http_status": self.http_status,
            "public_links": self.public_links,
            "redirect_followed": self.redirect_followed,
            "display_name": self.display_name,
            "bio": self.bio,
            "avatar_url": self.avatar_url,
            "og_site_name": self.og_site_name,
            "response_time_ms": self.response_time_ms,
            "scanned_at": self.scanned_at,
        }


@dataclass
class SourceResult:
    """Result of checking one source."""

    source: str
    category: str
    url: str
    status: str = "SCANNING"
    confidence: str = "none"
    match_score: int = 0
    evidence: Evidence = field(default_factory=Evidence)
    note: str = ""

    @property
    def source_type(self) -> str:
        return "public search/lookup page" if self._probe_only else "public profile page"

    _probe_only: bool = False

    def set_probe_only(self, value: bool) -> None:
        self._probe_only = value

    @property
    def match_explanation(self) -> str:
        """Plain-language explanation of how this status was reached."""
        if self.status == "FOUND":
            return (
                f"The public page at {self.evidence.domain or 'this domain'} loaded successfully "
                "and the target username is visibly present on it."
            )
        if self.status == "NOT_FOUND":
            reason = "returned an explicit not-found response" if (self.evidence.http_status in (404, 410)) else "displayed a known 'profile does not exist' page"
            return f"The platform {reason} for this username."
        if self.status == "UNCERTAIN":
            return "The page is reachable but the username is not visible on it (it may require JavaScript or show generic content)."
        if self.status == "BLOCKED":
            return "The platform declined the automated request or redirected it to a login wall."
        if self.status == "TIMEOUT":
            return "The platform did not respond within the timeout window."
        if self.status == "ERROR":
            return f"The platform returned a server/network error (HTTP {self.evidence.http_status or 'n/a'}) and is not interpreted as 'not found'."
        return "This source is currently being checked."

    @property
    def limitations(self) -> str:
        limits = []
        if self._probe_only:
            limits.append("matched via a public search page, not a direct profile URL")
        if self.status == "UNCERTAIN":
            limits.append("page content could not be verified without JavaScript")
        if self.status == "BLOCKED":
            limits.append("platform restricts automated access")
        if self.confidence == "low":
            limits.append("low platform reliability")
        return "; ".join(limits) or "none observed"

    def to_dict(self) -> dict:
        return {
            "platform": self.source,
            "category": self.category,
            "url": self.url,
            "status": self.status,
            "confidence": self.confidence,
            "match_score": self.match_score,
            "note": self.note,
            "source_type": self.source_type,
            "match_explanation": self.match_explanation,
            "limitations": self.limitations,
            "public_evidence": self.evidence.to_dict(),
        }


@dataclass
class DiscoveryResult:
    """A single public web discovery hit."""

    url: str
    title: str | None
    domain: str
    snippet: str | None
    discovery_source: str
    confidence: str = "medium"
    matched_variant: str | None = None

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "title": self.title,
            "domain": self.domain,
            "snippet": self.snippet,
            "discovery_source": self.discovery_source,
            "confidence": self.confidence,
            "matched_variant": self.matched_variant,
        }


@dataclass
class Correlation:
    """A possible relationship between two public results.

    IMPORTANT: a correlation is a *signal*, never proof of identity.
    """

    type: str
    source_a: str
    source_b: str
    signal: str
    confidence: str  # "possible" | "likely"
    explanation: str

    def to_dict(self) -> dict:
        return {
            "type": self.type,
            "source_a": self.source_a,
            "source_b": self.source_b,
            "signal": self.signal,
            "confidence": self.confidence,
            "explanation": self.explanation,
        }
