"""Sentiala AI application configuration.

All settings are read from environment variables (see .env.example).
No secrets are ever hardcoded. The application is completely free and
works with zero configuration; every external service (e.g. an optional
AI provider) degrades gracefully to local fallback behaviour.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

# Repository root: backend/app/config.py -> ../../..
PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _env(name: str, default: str) -> str:
    value = os.environ.get(name, "")
    return value if value.strip() else default


def _env_int(name: str, default: int) -> int:
    try:
        return int(_env(name, str(default)))
    except ValueError:
        return default


def _env_bool(name: str, default: bool) -> bool:
    return _env(name, "1" if default else "0").strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Settings:
    """Runtime settings for Sentiala AI."""

    # --- Core behaviour -------------------------------------------------
    app_name: str = "Sentiala AI"
    app_version: str = "1.0.0"
    database_path: Path = field(default_factory=lambda: PROJECT_ROOT / "sentiala.db")

    # --- HTTP scanning --------------------------------------------------
    request_timeout: float = 12.0          # per-source timeout (seconds)
    max_concurrency: int = 15              # controlled concurrency cap
    user_agent: str = (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 SentialaAI/1.0 "
        "(ethical OSINT; public pages only)"
    )

    # --- Public web discovery -------------------------------------------
    discovery_enabled: bool = True
    discovery_provider: str = "duckduckgo"  # public HTML endpoint, no API key

    # --- Optional external AI (never required) ---------------------------
    ai_api_key: str = ""                   # e.g. an OpenAI-compatible key
    ai_base_url: str = "https://api.openai.com/v1"
    ai_model: str = "gpt-4o-mini"
    ai_timeout: float = 30.0

    @classmethod
    def from_env(cls) -> "Settings":
        db_raw = os.environ.get("SENTIALA_DB_PATH", "").strip()
        return cls(
            database_path=Path(db_raw).expanduser() if db_raw else cls().database_path,
            request_timeout=float(_env("SENTIALA_TIMEOUT", "12")),
            max_concurrency=_env_int("SENTIALA_MAX_CONCURRENCY", 15),
            discovery_enabled=_env_bool("SENTIALA_DISCOVERY_ENABLED", True),
            ai_api_key=os.environ.get("SENTIALA_AI_API_KEY", "").strip(),
            ai_base_url=_env("SENTIALA_AI_BASE_URL", "https://api.openai.com/v1"),
            ai_model=_env("SENTIALA_AI_MODEL", "gpt-4o-mini"),
            ai_timeout=float(_env("SENTIALA_AI_TIMEOUT", "30")),
        )


settings = Settings.from_env()
