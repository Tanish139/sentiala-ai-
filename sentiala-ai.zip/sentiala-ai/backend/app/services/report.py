"""HTML report generation for a completed investigation.

A standalone, printable HTML document - no external assets, no
citations of AI certainty, full transparency of observed evidence.
"""

from __future__ import annotations

import html
from typing import Any

_STYLE = """
:root { color-scheme: dark; }
* { box-sizing: border-box; }
body { font-family: 'Segoe UI', system-ui, sans-serif; background:#06090f;
       color:#c9d6e3; margin:0; padding:40px; line-height:1.55; }
.wrap { max-width: 960px; margin: 0 auto; }
h1 { letter-spacing: 14px; color:#5eead4; font-weight:300; margin:0; }
h2 { color:#7dd3fc; border-bottom:1px solid #12304a; padding-bottom:8px;
     font-weight:500; letter-spacing:1px; }
.sub { color:#64748b; letter-spacing:4px; font-size:12px; text-transform:uppercase; }
.badge { display:inline-block; padding:2px 10px; border-radius:10px; font-size:11px;
         border:1px solid #1e3a5f; color:#93c5fd; }
.found { color:#5eead4; border-color:#14532d; }
.notfound { color:#64748b; }
.blocked { color:#fbbf24; border-color:#78350f; }
.error, .timeout, .uncertain { color:#f87171; }
table { width:100%; border-collapse:collapse; font-size:13px; margin:12px 0 28px; }
th { text-align:left; color:#64748b; font-weight:500; text-transform:uppercase;
     font-size:10px; letter-spacing:1px; border-bottom:1px solid #12304a; padding:8px; }
td { border-bottom:1px solid #0d1b2a; padding:8px; vertical-align:top; }
.meta { color:#64748b; font-size:12px; }
a { color:#38bdf8; text-decoration:none; }
.score { font-size:52px; color:#5eead4; font-weight:200; }
.note { background:#0b1220; border:1px solid #12304a; border-radius:8px;
        padding:14px 18px; font-size:13px; }
ul { padding-left:18px; }
@media print { body { background:#fff; color:#111; } h2 { color:#03548c; } }
"""


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _limitations(inv: dict) -> list[str]:
    notes = [
        "Sentiala only inspects publicly accessible pages. It never attempts to bypass "
        "authentication, rate limits or any access control.",
        "A NOT FOUND result means only that the platform reported no such profile to an "
        "automated request; some platforms block or require JavaScript, so absence here is "
        "not proof of absence anywhere.",
        "Correlations are possible signals, never proof that accounts belong to the same person.",
        "Geographic signals describe publicly referenced domains, not the account owner's location.",
    ]
    counts = inv.get("counts", {})
    blocked = counts.get("blocked", 0) + counts.get("timeout", 0) + counts.get("error", 0)
    if blocked:
        notes.insert(
            1,
            f"{blocked} of {inv.get('total_sources', 0)} sources were blocked, timed out or "
            "errored during this scan and could not be conclusively checked.",
        )
    return notes


def render_report(inv: dict) -> str:
    username = _esc(inv["username"])
    counts = inv.get("counts", {})
    score = (inv.get("score") or {})
    analysis = inv.get("analysis") or {}
    sections: list[str] = []

    # ---- executive summary ----
    exec_lines = [
        f"Investigation of the username “{_esc(inv['username'])}” across "
        f"{inv.get('total_sources', 0)} public sources: {counts.get('found', 0)} confirmed public "
        f"profiles across {counts.get('categories', 0)} categories, {counts.get('correlations', 0)} "
        f"possible correlation signals, {counts.get('discovery_hits', 0)} publicly indexed pages, "
        f"and {len(inv.get('geo_signals', []))} public geographic signals. "
        f"Public-footprint exposure score: {score.get('value', 0)}/100."
    ]
    if analysis.get("summary"):
        exec_lines.append(_esc(analysis["summary"]))
    sections.append(
        "<h2>Executive Summary</h2>"
        + "".join(f"<p>{line}</p>" for line in exec_lines)
    )

    # ---- target & scan summary ----
    kv_rows = "".join(
        f"<tr><th>{_esc(k)}</th><td>{_esc(v)}</td></tr>"
        for k, v in [
            ("Target username", inv["username"]),
            ("Investigation ID", inv["id"]),
            ("Scan status", inv["status"]),
            ("Started (server time)", inv["created_at"]),
            ("Completed (server time)", inv.get("completed_at") or "—"),
            ("Sources checked", f"{counts.get('checked', 0)} / {inv.get('total_sources', 0)}"),
            ("Profiles discovered", counts.get("found", 0)),
            ("Not found", counts.get("not_found", 0)),
            ("Uncertain", counts.get("uncertain", 0)),
            ("Blocked", counts.get("blocked", 0)),
            ("Timeout", counts.get("timeout", 0)),
            ("Errors (never 'not found')", counts.get("error", 0)),
            ("Evidence items", counts.get("evidence_items", 0)),
            ("Correlation signals", counts.get("correlations", 0)),
            ("Geographic signals", len(inv.get("geo_signals", []))),
            ("Exposure score", f"{score.get('value', 0)} / 100"),
            ("Report generated (server time)", inv.get("completed_at") or inv["created_at"]),
        ]
    )
    sections.append(f"<h2>Target & Scan Summary</h2><table>{kv_rows}</table>")

    # ---- platform results ----
    rows = []
    for r in inv.get("results", []):
        cls = r["status"].lower()
        ev = r.get("public_evidence", {})
        detail_bits = []
        if r.get("source_type"):
            detail_bits.append(_esc(r["source_type"]))
        if ev.get("response_time_ms") is not None:
            detail_bits.append(f"responded in {ev['response_time_ms']} ms")
        detail = " · ".join(detail_bits)
        rows.append(
            f"<tr><td><a href='{_esc(r['url'])}' target='_blank' rel='noopener'>{_esc(r['platform'])}</a>"
            f"<div class='meta'>{_esc(r['category'])}</div></td>"
            f"<td><span class='badge {cls}'>{_esc(r['status'])}</span>"
            f"<div class='meta'>{_esc(r['confidence'])} confidence"
            + (f" · score {r['match_score']}" if r.get("match_score") else "")
            + "</div></td>"
            f"<td class='meta'>{_esc(r.get('match_explanation', ''))}"
            + (f"<div class='meta'>Limitations: {_esc(r.get('limitations', ''))}</div>" if r.get("limitations") != "none observed" else "")
            + (f"<div class='meta'>{detail}</div>" if detail else "")
            + "</td></tr>"
        )
    sections.append(
        f"<h2>Platform Results</h2><table><tr><th>Source</th><th>Status</th><th>Match explanation</th></tr>{''.join(rows)}</table>"
    )

    # ---- geographic signals ----
    geo = inv.get("geo_signals", [])
    if geo:
        grows = "".join(
            f"<tr><td>{_esc(g['country'])} ({_esc(g['country_code'])})"
            f"<div class='meta'>{_esc(g['signal_type'].replace('_', ' '))}</div></td>"
            f"<td><a href='{_esc(g['url'])}' target='_blank' rel='noopener'>{_esc(g['domain'])}</a>"
            f"<div class='meta'>via {_esc(g['source'])}</div></td>"
            f"<td class='meta'>{_esc(g['explanation'])}</td></tr>"
            for g in geo
        )
        sections.append(
            "<h2>Geographic Signals (public domain references only)</h2>"
            "<table><tr><th>Country</th><th>Domain</th><th>Explanation</th></tr>" + grows + "</table>"
        )
    else:
        sections.append(
            "<h2>Geographic Signals</h2>"
            "<p class='meta'>No reliable public geographic signal detected.</p>"
        )

    # ---- evidence ----
    items = inv.get("evidence_items", [])
    if items:
        erows = "".join(
            f"<tr><td>{_esc(e['source'])}</td>"
            f"<td>{_esc(e['classification'])}<div class='meta'>{_esc(e['evidence_type'])}</div></td>"
            f"<td class='meta'>{_esc(e['observed_value'][:160])}</td></tr>"
            for e in items[:60]
        )
        sections.append(
            "<h2>Evidence (structured, public)</h2>"
            "<table><tr><th>Source</th><th>Classification</th><th>Observed value</th></tr>"
            + erows
            + ("</table><p class='meta'>…and " + str(len(items) - 60) + " more items in the interactive dashboard.</p>" if len(items) > 60 else "</table>")
        )
    else:
        sections.append("<h2>Evidence</h2><p class='meta'>No structured evidence items were collected.</p>")

    # ---- correlations ----
    if inv.get("correlations"):
        crows = "".join(
            f"<tr><td>{_esc(c['type'])}<div class='meta'>{_esc(c['confidence'])}</div></td>"
            f"<td>{_esc(c['source_a'])} &harr; {_esc(c['source_b'])}<div class='meta'>{_esc(c['signal'])}</div></td>"
            f"<td class='meta'>{_esc(c['explanation'])}</td></tr>"
            for c in inv["correlations"]
        )
        sections.append(f"<h2>Correlations (possible signals only)</h2><table><tr><th>Type</th><th>Between</th><th>Explanation</th></tr>{crows}</table>")
    else:
        sections.append("<h2>Correlations</h2><p class='meta'>No correlation signals were observed.</p>")

    # ---- exposure analysis ----
    if score:
        comps = score.get("components", {})
        groups = score.get("groups", {})
        group_rows = "".join(
            f"<tr><th>{_esc(k.replace('_', ' ').title())}</th><td>{v} / 100</td></tr>"
            for k, v in groups.items()
        )
        comp_rows = "".join(
            f"<tr><th class='meta'>{_esc(k.replace('_', ' ').title())}</th><td class='meta'>{v} / 100</td></tr>"
            for k, v in comps.items()
        )
        sections.append(
            f"<h2>Exposure Analysis</h2>"
            f"<p class='score'>{score.get('value', 0)} <span style='font-size:16px;color:#64748b'>/ 100 public-footprint exposure</span></p>"
            f"<table style='max-width:420px'>{group_rows}</table>"
            f"<p class='meta'><b>Detailed components</b></p>"
            f"<table style='max-width:420px'>{comp_rows}</table>"
            f"<p class='meta'>The score describes the breadth of publicly discoverable information "
            f"attached to this username. It is not a statement about a person, their identity, "
            f"character or risk.</p>"
        )

    # ---- limitations ----
    sections.append(
        "<h2>Limitations</h2><ul>"
        + "".join(f"<li>{_esc(n)}</li>" for n in _limitations(inv))
        + "</ul>"
    )

    # ---- source list ----
    sources = sorted((r["platform"], r["status"]) for r in inv.get("results", []))
    source_text = ", ".join(f"{_esc(name)} ({_esc(status)})" for name, status in sources)
    sections.append(
        "<h2>Source List</h2><p class='meta' style='line-height:2'>" + source_text + "</p>"
    )

    # ---- timeline ----
    trows = "".join(
        f"<tr><td class='meta'>{_esc(e['time'])}</td><td>{_esc(e['message'])}</td></tr>"
        for e in inv.get("timeline", [])
    )
    sections.append(f"<h2>Timeline</h2><table><tr><th>Time</th><th>Event</th></tr>{trows}</table>")

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sentiala AI &middot; {username} &middot; Investigation Report</title>
<style>{_STYLE}</style></head><body><div class="wrap">
<div style="margin-bottom:36px">
  <h1>S E N T I A L A</h1>
  <div class="sub">Digital Intelligence System &middot; Deep-Scan Investigation Report</div>
</div>
{''.join(sections)}
<div class="note" style="margin-top:32px">This report contains only publicly accessible information.
Correlations are possible signals, never proof of identity. Geographic signals describe publicly
referenced domains, not account-owner locations. Generated by Sentiala AI - completely free, ethical OSINT.</div>
</div></body></html>"""
