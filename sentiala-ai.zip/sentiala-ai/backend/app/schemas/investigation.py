"""Pydantic schemas for the Sentiala API."""

from __future__ import annotations

from pydantic import BaseModel, Field


class InvestigationCreate(BaseModel):
    username: str = Field(..., min_length=1, max_length=64, description="Username to investigate")


class InvestigationCreated(BaseModel):
    id: str
    username: str
    status: str
    total_sources: int


class HealthResponse(BaseModel):
    status: str
    app: str
    version: str
    sources: int
    categories: list[str]
    free: bool = True
    ethics: str = "public-data OSINT only"
