"""Sentiala AI - FastAPI application entry point.

Serves the API under /api and the animated frontend from /frontend.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .api.routes import router
from .config import PROJECT_ROOT, Settings, settings
from .database import Database
from .osint.engine import InvestigationEngine
from .osint.registry import SourceRegistry

FRONTEND_DIR = PROJECT_ROOT / "frontend"


def create_app(settings_override: Settings | None = None) -> FastAPI:
    app_settings = settings_override or settings

    @asynccontextmanager
    async def _lifespan(app: FastAPI):
        yield
        for task in app.state.tasks:
            task.cancel()
        app.state.db.close()

    app = FastAPI(
        title="Sentiala AI",
        description=(
            "Completely free, ethical OSINT username investigation platform. "
            "Public data only. Correlations are possible signals, never proof of identity."
        ),
        version=app_settings.app_version,
        lifespan=_lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Application state -------------------------------------------------
    registry = SourceRegistry()
    app.state.settings = app_settings
    app.state.registry = registry
    app.state.engine = InvestigationEngine(registry, app_settings)
    app.state.db = Database(app_settings.database_path)
    app.state.investigations = {}
    app.state.tasks = []

    # API ---------------------------------------------------------------
    app.include_router(router)

    # Health is also mounted at the root path for convenience.
    @app.get("/health")
    async def root_health() -> dict:
        return {
            "status": "operational",
            "app": app_settings.app_name,
            "version": app_settings.app_version,
            "sources": registry.total,
            "categories": registry.categories,
            "free": True,
        }

    # Frontend ----------------------------------------------------------
    if FRONTEND_DIR.exists():
        app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

        @app.get("/", include_in_schema=False)
        async def index() -> FileResponse:
            return FileResponse(FRONTEND_DIR / "index.html")

    return app


app = create_app()
