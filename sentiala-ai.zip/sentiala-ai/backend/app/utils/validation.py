"""Username validation.

Sentiala only accepts sane, safe username strings. We deliberately
restrict the character set so that URLs can never be polluted with
injection payloads.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

# Safe, URL-friendly username characters only.
USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,30}[A-Za-z0-9])?$")

MAX_LENGTH = 32
MIN_LENGTH = 2

RESERVED = {"", ".", "..", "admin", "root", "null", "undefined", "none"}


@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    reason: str = ""


def validate_username(raw: str) -> ValidationResult:
    """Return whether ``raw`` is a safe username to investigate."""
    if not isinstance(raw, str):
        return ValidationResult(False, "Username must be a string.")
    username = raw.strip()

    if not username:
        return ValidationResult(False, "Username is required.")
    if len(username) < MIN_LENGTH:
        return ValidationResult(False, f"Username must be at least {MIN_LENGTH} characters.")
    if len(username) > MAX_LENGTH:
        return ValidationResult(False, f"Username must be at most {MAX_LENGTH} characters.")
    if username.lower() in RESERVED:
        return ValidationResult(False, "That username is reserved and cannot be investigated.")
    if not USERNAME_PATTERN.match(username):
        return ValidationResult(
            False,
            "Username may only contain letters, digits, dots, underscores and hyphens, "
            "and must start and end with a letter or digit.",
        )
    return ValidationResult(True)
