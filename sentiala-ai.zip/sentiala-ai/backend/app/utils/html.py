"""Small HTML helpers used by the evidence engine."""

from __future__ import annotations

import html as html_module
import re

TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
META_DESC_RE = re.compile(
    r'<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']',
    re.IGNORECASE | re.DOTALL,
)
OG_DESC_RE = re.compile(
    r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\'](.*?)["\']',
    re.IGNORECASE | re.DOTALL,
)
OG_TITLE_RE = re.compile(
    r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\'](.*?)["\']',
    re.IGNORECASE | re.DOTALL,
)
OG_IMAGE_RE = re.compile(
    r'<meta[^>]+(?:property|name)=["\'](?:og:image|twitter:image)["\'][^>]+content=["\'](.*?)["\']',
    re.IGNORECASE | re.DOTALL,
)
OG_SITE_RE = re.compile(
    r'<meta[^>]+(?:property|name)=["\']og:site_name["\'][^>]+content=["\'](.*?)["\']',
    re.IGNORECASE | re.DOTALL,
)
HREF_RE = re.compile(r'href=["\'](https?://[^"\']+)["\']', re.IGNORECASE)
TAG_RE = re.compile(r"<[^>]+>")
WS_RE = re.compile(r"\s+")


def strip_tags(fragment: str) -> str:
    """Remove tags and collapse whitespace from an HTML fragment."""
    text = TAG_RE.sub(" ", html_module.unescape(fragment or ""))
    return WS_RE.sub(" ", text).strip()


def extract_title(body: str) -> str | None:
    match = TITLE_RE.search(body or "")
    if not match:
        return None
    title = strip_tags(match.group(1))
    return title or None


def extract_meta_description(body: str) -> str | None:
    match = META_DESC_RE.search(body or "")
    if not match:
        return None
    desc = strip_tags(match.group(1))
    return desc or None


def extract_og_description(body: str) -> str | None:
    match = OG_DESC_RE.search(body or "")
    if not match:
        return None
    desc = strip_tags(match.group(1))
    return desc or None


def extract_og_title(body: str) -> str | None:
    match = OG_TITLE_RE.search(body or "")
    if not match:
        return None
    title = strip_tags(match.group(1))
    return title or None


def extract_og_image(body: str) -> str | None:
    match = OG_IMAGE_RE.search(body or "")
    if not match:
        return None
    url = strip_tags(match.group(1))
    return url if url.startswith("http") else None


def extract_og_site_name(body: str) -> str | None:
    match = OG_SITE_RE.search(body or "")
    if not match:
        return None
    site = strip_tags(match.group(1))
    return site or None


def extract_public_links(body: str, limit: int = 25) -> list[str]:
    """Extract absolute external links from a public HTML page."""
    seen: set[str] = set()
    links: list[str] = []
    for match in HREF_RE.finditer(body or ""):
        url = match.group(1)
        # Skip obvious asset/CDN/self-referential noise.
        if any(ext in url for ext in (".css", ".js", ".png", ".jpg", ".svg", ".ico", ".woff")):
            continue
        if url not in seen:
            seen.add(url)
            links.append(url)
        if len(links) >= limit:
            break
    return links
