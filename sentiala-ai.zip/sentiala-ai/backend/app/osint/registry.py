"""Source registry access layer.

The registry is data-driven (see ``sources.py``). New sources are
added by appending one tuple - the engine never changes.
"""

from __future__ import annotations

from ..models.source import SourceSpec
from .sources import SOURCE_REGISTRY


class SourceRegistry:
    """Read-only view over the global source registry."""

    def __init__(self, sources: dict[str, SourceSpec] | None = None) -> None:
        self._sources = dict(sources if sources is not None else SOURCE_REGISTRY)

    # ------------------------------------------------------------------
    @property
    def total(self) -> int:
        return len(self._sources)

    @property
    def categories(self) -> list[str]:
        return sorted({s.category for s in self._sources.values()})

    def category_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for source in self._sources.values():
            counts[source.category] = counts.get(source.category, 0) + 1
        return dict(sorted(counts.items()))

    def all_sources(self) -> list[SourceSpec]:
        return list(self._sources.values())

    def sources_by_category(self) -> dict[str, list[SourceSpec]]:
        grouped: dict[str, list[SourceSpec]] = {}
        for source in self._sources.values():
            grouped.setdefault(source.category, []).append(source)
        return dict(sorted(grouped.items()))

    def get(self, name: str) -> SourceSpec | None:
        return self._sources.get(name)

    def summary(self) -> dict:
        return {
            "total_sources": self.total,
            "categories": self.category_counts(),
        }
