"""Structured evidence items for the evidence analysis panel.

Every item is classified by evidential strength:

- DIRECT EVIDENCE   : directly observed on a public platform page.
- CORRELATED SIGNAL : a relationship between two public pages.
- WEAK SIGNAL       : reachable but unverified, or a low-confidence match.
- UNCONFIRMED       : publicly indexed search hit, not platform-verified.

Nothing here is invented: every item is derived from observed data, and
a weak username match is never upgraded into a confirmed identity.
"""

from __future__ import annotations

from ..models.investigation import EvidenceItem, Investigation

MAX_ITEMS = 250
MAX_LINK_ITEMS_PER_SOURCE = 2


def build_evidence_items(inv: Investigation) -> list[EvidenceItem]:
    items: list[EvidenceItem] = []
    username = inv.username

    # -------------------------------------------------- direct evidence
    for result in inv.results:
        if result.status != "FOUND":
            continue
        ev = result.evidence
        stamp = ev.scanned_at or _stamp()
        base_conf = result.confidence

        if ev.username_found:
            items.append(EvidenceItem(
                source=result.source, classification="DIRECT EVIDENCE",
                evidence_type="username match",
                observed_value=f"'{username}' visibly present on the public page",
                url=result.url, timestamp=stamp, confidence=base_conf,
                why_it_matters=(
                    "The exact target username appears on a publicly accessible profile page. "
                    "This confirms the username exists on this platform - it does not identify "
                    "the person behind it."
                ),
            ))
        if ev.display_name:
            items.append(EvidenceItem(
                source=result.source, classification="DIRECT EVIDENCE",
                evidence_type="public display name",
                observed_value=ev.display_name,
                url=result.url, timestamp=stamp, confidence=base_conf,
                why_it_matters=(
                    "The public profile exposes a display name, which is publicly visible "
                    "metadata associated with the username."
                ),
            ))
        if ev.bio:
            items.append(EvidenceItem(
                source=result.source, classification="DIRECT EVIDENCE",
                evidence_type="public bio",
                observed_value=ev.bio[:300],
                url=result.url, timestamp=stamp, confidence=base_conf,
                why_it_matters=(
                    "A public bio/description is exposed on the profile page and is indexed "
                    "by search engines."
                ),
            ))
        if ev.avatar_url:
            items.append(EvidenceItem(
                source=result.source, classification="DIRECT EVIDENCE",
                evidence_type="public avatar",
                observed_value=ev.avatar_url,
                url=ev.avatar_url, timestamp=stamp, confidence=base_conf,
                why_it_matters="A publicly hosted avatar image is linked from the profile page.",
            ))
        if ev.title and not ev.display_name:
            items.append(EvidenceItem(
                source=result.source, classification="DIRECT EVIDENCE",
                evidence_type="page title",
                observed_value=ev.title,
                url=result.url, timestamp=stamp, confidence=base_conf,
                why_it_matters="The public page title is observable metadata for this username.",
            ))
        for link in ev.public_links[:MAX_LINK_ITEMS_PER_SOURCE]:
            items.append(EvidenceItem(
                source=result.source, classification="DIRECT EVIDENCE",
                evidence_type="public link",
                observed_value=link,
                url=link, timestamp=stamp, confidence=base_conf,
                why_it_matters=(
                    "A publicly visible outbound link on the profile - it may connect to other "
                    "public pages or platforms."
                ),
            ))

    # ---------------------------------------------- correlated signals
    for c in inv.correlations:
        items.append(EvidenceItem(
            source=f"{c.source_a} ↔ {c.source_b}", classification="CORRELATED SIGNAL",
            evidence_type=c.type.replace("_", " "),
            observed_value=c.signal,
            url="", timestamp=_stamp(), confidence=c.confidence,
            why_it_matters=c.explanation,
        ))

    # -------------------------------------------------- weak signals
    for result in inv.results:
        if result.status == "FOUND" and result.confidence == "low":
            items.append(EvidenceItem(
                source=result.source, classification="WEAK SIGNAL",
                evidence_type="low-confidence match",
                observed_value=f"match score {result.match_score} · {result.limitations}",
                url=result.url, timestamp=result.evidence.scanned_at or _stamp(),
                confidence="low",
                why_it_matters=(
                    "The page loaded and shows the username, but platform reliability is low or "
                    "the match came from a search page - verify manually before drawing conclusions."
                ),
            ))
        elif result.status == "UNCERTAIN":
            items.append(EvidenceItem(
                source=result.source, classification="WEAK SIGNAL",
                evidence_type="unverified page",
                observed_value=result.note,
                url=result.url, timestamp=result.evidence.scanned_at or _stamp(),
                confidence="low",
                why_it_matters=(
                    "The profile URL is reachable but the username could not be verified in the "
                    "returned content. This is neither confirmation nor refutation."
                ),
            ))

    # -------------------------------------------------- unconfirmed
    for hit in inv.discovery[:30]:
        items.append(EvidenceItem(
            source=hit.domain, classification="UNCONFIRMED",
            evidence_type="publicly indexed page",
            observed_value=hit.title or hit.url,
            url=hit.url, timestamp=_stamp(), confidence=hit.confidence,
            why_it_matters=(
                "A publicly indexed search result mentions the username. It has not been "
                "verified against any platform profile and may be unrelated."
            ),
        ))

    return items[:MAX_ITEMS]


def _stamp() -> str:
    import time

    return time.strftime("%Y-%m-%dT%H:%M:%S")
