"""Public web discovery via publicly indexed search results.

Uses DuckDuckGo's public HTML endpoint - no API key, no payment. If the
provider is unreachable or declines the request, discovery fails
*openly* (the investigation continues, and the UI shows the failure).
No results are ever fabricated.
"""

from __future__ import annotations

import html as html_module
import re
from urllib.parse import parse_qs, unquote, urlparse

import httpx

from ..config import Settings
from ..models.source import DiscoveryResult

_RESULT_BLOCK_RE = re.compile(
    r'<a[^>]+class="[^"]*result__a[^"]*"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL,
)
_SNIPPET_RE = re.compile(
    r'class="[^"]*result__snippet[^"]*"[^>]*>(.*?)</(?:a|div)>',
    re.IGNORECASE | re.DOTALL,
)
_TAG_RE = re.compile(r"<[^>]+>")


def _clean(fragment: str) -> str:
    text = _TAG_RE.sub(" ", html_module.unescape(fragment or ""))
    return re.sub(r"\s+", " ", text).strip()


def _resolve_ddg_url(href: str) -> str:
    """DuckDuckGo wraps results in a redirect; unwrap it."""
    if "duckduckgo.com/l/" in href:
        query = parse_qs(urlparse(href).query)
        target = query.get("uddg", [""])[0]
        if target:
            return unquote(target)
    if href.startswith("//"):
        return "https:" + href
    return href


def parse_results(body: str, username: str, provider: str, limit: int = 30) -> list[DiscoveryResult]:
    """Parse a DuckDuckGo HTML results page into DiscoveryResults.

    Pure function - separated from networking so it is unit-testable.
    """
    blocks = _RESULT_BLOCK_RE.findall(body)
    snippets = _SNIPPET_RE.findall(body)

    results: list[DiscoveryResult] = []
    seen_urls: set[str] = set()
    username_lower = username.lower()
    for index, (href, raw_title) in enumerate(blocks):
        resolved = _resolve_ddg_url(href)
        if not resolved.startswith("http"):
            continue
        if resolved in seen_urls:  # deduplicate URLs
            continue
        seen_urls.add(resolved)
        title = _clean(raw_title) or None
        snippet = _clean(snippets[index]) if index < len(snippets) else None
        domain = urlparse(resolved).netloc.lower()
        domain = domain[4:] if domain.startswith("www.") else domain
        confidence = (
            "high"
            if username_lower in (title or "").lower() or username_lower in (snippet or "").lower()
            else "medium"
        )
        results.append(
            DiscoveryResult(
                url=resolved,
                title=title,
                domain=domain,
                snippet=snippet,
                discovery_source=provider,
                confidence=confidence,
            )
        )
        if len(results) >= limit:
            break
    return results


class DiscoveryEngine:
    PROVIDER = "DuckDuckGo (public index)"

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or Settings.from_env()

    async def search(self, username: str) -> list[DiscoveryResult]:
        """Search the public index for one exact username."""
        return (await self.search_many([username]))[username]

    async def search_many(
        self, terms: list[str], client: httpx.AsyncClient | None = None
    ) -> dict[str, list[DiscoveryResult]]:
        """Search the public index for several username variants.

        Returns {variant: [DiscoveryResult]} with URLs deduplicated across
        variants (the first matching variant wins). Each term is queried as
        an exact quoted phrase - nothing is guessed or fabricated.
        """
        results: dict[str, list[DiscoveryResult]] = {}
        seen_urls: set[str] = set()
        for term in terms:
            found: list[DiscoveryResult] = []
            if client is not None:
                response = await client.post(
                    "https://html.duckduckgo.com/html/", data={"q": f'"{term}"'}
                )
                if response.status_code == 200:
                    for hit in parse_results(response.text, term, self.PROVIDER):
                        if hit.url in seen_urls:
                            continue
                        seen_urls.add(hit.url)
                        hit.matched_variant = term
                        found.append(hit)
                results[term] = found
                continue
            async with httpx.AsyncClient(
                timeout=self.settings.request_timeout,
                follow_redirects=True,
                headers={"User-Agent": self.settings.user_agent},
            ) as client:
                response = await client.post(
                    "https://html.duckduckgo.com/html/", data={"q": f'"{term}"'}
                )
            if response.status_code == 200:
                for hit in parse_results(response.text, term, self.PROVIDER):
                    if hit.url in seen_urls:
                        continue
                    seen_urls.add(hit.url)
                    hit.matched_variant = term
                    found.append(hit)
            results[term] = found
        return results
