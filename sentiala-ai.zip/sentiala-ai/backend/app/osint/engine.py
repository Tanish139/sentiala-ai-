"""Investigation engine: orchestrates a full deep-scan investigation.

The pipeline is presented (and genuinely executed) in stages:

    INITIALIZING -> SOURCE DISCOVERY -> PLATFORM VALIDATION ->
    PUBLIC PROFILE EXTRACTION -> USERNAME VARIANT DISCOVERY ->
    EVIDENCE COLLECTION -> CROSS-SOURCE CORRELATION ->
    GEOGRAPHIC SIGNAL ANALYSIS -> EXPOSURE ANALYSIS -> REPORT GENERATION

Design goals, unchanged from the original architecture:
- controlled concurrency (semaphore) and per-source timeouts
- one failing source never stops the investigation
- results stream into the Investigation as they complete so the
  frontend renders *real* progress via polling
- "deep scan" means deeper analysis of legitimately accessible public
  information only. No auth bypass, no rate-limit evasion, nothing
  outside public pages.
"""

from __future__ import annotations

import asyncio
import time

import httpx

from ..config import Settings
from ..models.investigation import Investigation
from ..models.source import SourceResult
from . import analysis as analysis_module
from .correlation import correlate
from .discovery import DiscoveryEngine
from .evidence import build_result, enrich_result
from .evidence_items import build_evidence_items
from .geo import analyze_geographic_signals
from .registry import SourceRegistry
from .scoring import compute_exposure_score

# For FOUND candidates we keep the public HTML body (capped) so the
# extraction stage can parse detailed public attributes.
MAX_CACHED_BODY = 400_000


class InvestigationEngine:
    def __init__(
        self,
        registry: SourceRegistry,
        settings: Settings | None = None,
    ) -> None:
        self.registry = registry
        self.settings = settings or Settings.from_env()

    # ------------------------------------------------------------------
    async def _check_source(
        self,
        client: httpx.AsyncClient,
        semaphore: asyncio.Semaphore,
        inv: Investigation,
        source,
        found_bodies: dict[str, str],
    ) -> None:
        url = source.build_url(inv.username)
        inv.add_result(
            SourceResult(source=source.name, category=source.category, url=url, status="SCANNING")
        )
        async with semaphore:
            started = time.perf_counter()
            try:
                response = await client.get(url)
                result = build_result(source, inv.username, response=response)
                if result.status == "FOUND":
                    found_bodies[source.name] = (response.text or "")[:MAX_CACHED_BODY]
            except httpx.TimeoutException as exc:
                result = build_result(source, inv.username, error=exc)
            except httpx.HTTPError as exc:
                result = build_result(source, inv.username, error=exc)
            elapsed_ms = int((time.perf_counter() - started) * 1000)
            result.evidence.response_time_ms = elapsed_ms
        inv.add_result(result)

    # ------------------------------------------------------------------
    def _username_variants(self, username: str) -> list[str]:
        """Legitimate variants used for *exact* public-index searches.

        Only case variants of the same string - no leetspeak or guessing,
        so every discovery hit remains an exact public mention.
        """
        variants = [username]
        lowered = username.lower()
        if lowered != username:
            variants.append(lowered)
        return variants

    # ------------------------------------------------------------------
    async def run(self, inv: Investigation, client: httpx.AsyncClient | None = None) -> Investigation:
        """Execute the full deep-scan pipeline."""
        inv.status = "RUNNING"

        # ------------------------------------------------- INITIALIZING
        inv.set_stage("initializing", "RUNNING")
        inv.add_event("Investigation initialized")
        inv.set_stage("initializing", "DONE")

        # --------------------------------------------- SOURCE DISCOVERY
        inv.set_stage("source_discovery", "RUNNING")
        sources = self.registry.all_sources()
        inv.total_sources = len(sources)
        inv.add_event(f"Source registry loaded ({len(sources)} sources)")
        inv.set_stage("source_discovery", "DONE")

        owned_client = client is None
        if client is None:
            client = httpx.AsyncClient(
                timeout=self.settings.request_timeout,
                follow_redirects=True,
                headers={"User-Agent": self.settings.user_agent, "Accept-Language": "en"},
                limits=httpx.Limits(max_connections=self.settings.max_concurrency + 5),
            )

        semaphore = asyncio.Semaphore(self.settings.max_concurrency)
        found_bodies: dict[str, str] = {}
        try:
            # ---------------------------------- PLATFORM VALIDATION
            inv.set_stage("platform_validation", "RUNNING")
            tasks = [
                asyncio.create_task(self._check_source(client, semaphore, inv, source, found_bodies))
                for source in sources
            ]
            await asyncio.gather(*tasks)
            for cat in list(self.registry.sources_by_category()):
                done_in_cat = sum(
                    1 for r in inv.results if r.category == cat and r.status != "SCANNING"
                )
                total_in_cat = sum(1 for r in inv.results if r.category == cat)
                if total_in_cat and done_in_cat >= total_in_cat:
                    inv.add_event(f"{cat} sources completed")
            inv.add_event("Source scanning completed")
            inv.set_stage("platform_validation", "DONE")

            # ------------------------------ PUBLIC PROFILE EXTRACTION
            inv.set_stage("profile_extraction", "RUNNING")
            inv.add_event("Public profile extraction started")
            enriched = 0
            for result in inv.results:
                if result.status != "FOUND":
                    continue
                body = found_bodies.get(result.source, "")
                enrich_result(result, body, inv.username)
                if result.evidence.display_name or result.evidence.bio or result.evidence.avatar_url:
                    enriched += 1
            inv.add_event(
                f"Public profile extraction completed "
                f"({inv.found_count} profiles, {enriched} with public attributes)"
            )
            inv.set_stage("profile_extraction", "DONE")

            # ------------------------------ USERNAME VARIANT DISCOVERY
            inv.set_stage("variant_discovery", "RUNNING")
            inv.variants = self._username_variants(inv.username)
            if self.settings.discovery_enabled:
                inv.discovery_status = "RUNNING"
                inv.add_event(
                    f"Public web discovery started (variants: {', '.join(inv.variants)})"
                )
                discovery = DiscoveryEngine(self.settings)
                try:
                    per_variant = await discovery.search_many(inv.variants)
                    inv.discovery = [hit for hits in per_variant.values() for hit in hits]
                    inv.discovery_status = "DONE"
                except Exception:
                    inv.discovery = []
                    inv.discovery_status = "FAILED"
                inv.add_event(
                    f"Public discovery completed ({len(inv.discovery)} indexed pages)"
                    if inv.discovery
                    else "Public discovery completed (no indexed pages returned)"
                )
            else:
                inv.discovery_status = "FAILED"
                inv.add_event("Public web discovery disabled")
            inv.set_stage("variant_discovery", "DONE")

            # --------------------------------- EVIDENCE COLLECTION
            inv.set_stage("evidence_collection", "RUNNING")
            inv.add_event("Evidence collection started")
            inv.evidence_items = build_evidence_items(inv)
            inv.evidence_status = "DONE"
            inv.add_event(f"Evidence collection completed ({len(inv.evidence_items)} items)")
            inv.set_stage("evidence_collection", "DONE")

            # -------------------------------------- CORRELATION
            inv.set_stage("correlation", "RUNNING")
            inv.add_event("Correlation analysis started")
            inv.correlations = correlate(inv)
            inv.correlation_status = "DONE"
            inv.add_event(f"Correlation completed ({len(inv.correlations)} possible signals)")
            inv.set_stage("correlation", "DONE")

            # --------------------------------- GEOGRAPHIC SIGNALS
            inv.set_stage("geographic", "RUNNING")
            inv.add_event("Geographic signal analysis started")
            inv.geo_signals = analyze_geographic_signals(inv)
            inv.geo_status = "DONE"
            if inv.geo_signals:
                countries = sorted({g.country for g in inv.geo_signals})
                inv.add_event(
                    f"Geographic analysis completed "
                    f"({len(inv.geo_signals)} public signals across {len(countries)} countries)"
                )
            else:
                inv.add_event("Geographic analysis completed (no reliable public geographic signal detected)")
            inv.set_stage("geographic", "DONE")

            # ---------------------------------- EXPOSURE ANALYSIS
            inv.set_stage("exposure", "RUNNING")
            inv.analysis_status = "RUNNING"
            inv.add_event("Exposure and AI analysis started")
            score = compute_exposure_score(inv, self.registry)
            inv.score = score
            report = await analysis_module.analyze(inv, score, settings=self.settings, client=client)
            inv.analysis = report
            inv.analysis_status = "DONE"
            inv.add_event(
                f"AI analysis completed ({'external AI' if report.analyzed_by == 'external-ai' else 'local evidence-based fallback'})"
            )
            inv.set_stage("exposure", "DONE")

            # --------------------------------- REPORT GENERATION
            inv.set_stage("report", "RUNNING")
            inv.status = "COMPLETED"
            inv.completed_at = time.strftime("%H:%M:%S")
            inv.add_event(
                f"Investigation finalized - {inv.found_count} of {inv.total_sources} sources matched"
            )
            inv.set_stage("report", "DONE")
        except Exception as exc:  # pragma: no cover - defensive
            inv.status = "FAILED"
            inv.error = "Investigation failed unexpectedly."
            inv.add_event("Investigation failed")
            for key in inv.stage_status:
                if inv.stage_status[key] == "RUNNING":
                    inv.stage_status[key] = "FAILED"
            # Never leak internals; log type only.
            print(f"[sentiala] investigation {inv.id} failed: {type(exc).__name__}")
        finally:
            if owned_client:
                await client.aclose()
        return inv
