"""Transparent exposure scoring (0-100).

The score describes the BREADTH of publicly discoverable information
attached to a username - not personality, morality, identity or danger.

Every component is measurable and shown to the user in the UI, so the
score is never a black box.
"""

from __future__ import annotations

from ..models.investigation import ExposureScore, Investigation
from .registry import SourceRegistry

# How each component maps onto the 0-100 exposure scale.
WEIGHTS = {
    "profile_breadth": 30,      # how many public profiles were found
    "category_breadth": 15,     # how many distinct categories
    "public_links": 15,         # volume of public links on those pages
    "metadata_availability": 10,  # how much public metadata is exposed
    "username_reuse": 15,       # cross-category username reuse
    "web_discovery": 10,        # publicly indexed search hits
    "domain_diversity": 5,      # distinct public domains referencing it
}

# Saturation points: the input value at which a component hits 100.
_SATURATION = {
    "profile_breadth": 30.0,     # 30+ found profiles = full marks
    "category_breadth": 6.0,     # 6+ categories = full marks
    "public_links": 150.0,      # 150+ public links = full marks
    "metadata_availability": 1.0,  # ratio (0..1)
    "username_reuse": 4.0,      # 4+ categories with reuse = full marks
    "web_discovery": 20.0,     # 20+ indexed hits = full marks
    "domain_diversity": 15.0,   # 15+ domains = full marks
}


def compute_exposure_score(inv: Investigation, registry: SourceRegistry) -> ExposureScore:
    """Compute the public-footprint exposure score with a visible breakdown."""
    found = [r for r in inv.results if r.status == "FOUND"]
    found_count = len(found)
    categories = inv.categories_found

    public_links = sum(len(r.evidence.public_links) for r in found)
    metadata_fields = 0
    metadata_slots = max(1, found_count * 4)
    for r in found:
        ev = r.evidence
        metadata_fields += sum(
            (ev.username_found, ev.page_title_available, ev.description_available, ev.public_links_available)
        )
    metadata_ratio = min(1.0, metadata_fields / metadata_slots) if found_count else 0.0

    reuse_categories = sorted({r.category for r in found if r.confidence in ("high", "medium")})
    reuse_signal = max(0, len(reuse_categories) - 1)
    domain_count = len(
        {
            d
            for r in found
            for d in _external_domain_set(r.evidence.public_links, r.evidence.domain or "")
        }
    ) + len(inv.public_domains)

    discovery_count = len(inv.discovery)

    raw = {
        "profile_breadth": found_count,
        "category_breadth": len(categories),
        "public_links": public_links,
        "metadata_availability": metadata_ratio,
        "username_reuse": reuse_signal,
        "web_discovery": discovery_count,
        "domain_diversity": domain_count,
    }

    components: dict[str, int] = {}
    for key, weight in WEIGHTS.items():
        value = raw[key]
        sat = _SATURATION[key]
        component = int(round(min(1.0, value / sat) * 100))
        components[key] = component

    total = int(round(sum(components[k] * WEIGHTS[k] for k in WEIGHTS) / sum(WEIGHTS.values())))
    value = max(0, min(100, total))

    # ---- presentation groups (additive; the 7 components above stay
    # the authoritative, tested breakdown). Groups aggregate components
    # plus correlation and geographic-signal inputs for the UI.
    correlation_count = len(inv.correlations)
    geo_countries = inv.geo_country_count
    groups = {
        "source_coverage": _avg([components["profile_breadth"], components["category_breadth"]]),
        "identity_signals": _avg([components["username_reuse"], components["web_discovery"]]),
        "cross_platform_correlation": min(100, correlation_count * 20),
        "public_information_exposure": _avg([
            components["public_links"],
            components["metadata_availability"],
            components["domain_diversity"],
        ]),
        "geographic_signals": min(100, geo_countries * 25),
    }
    return ExposureScore(value=value, components=components, groups=groups)


def _avg(values: list[int]) -> int:
    return int(round(sum(values) / len(values)))


def _external_domain_set(links: list[str], own_domain: str) -> set[str]:
    from urllib.parse import urlparse

    domains = set()
    for link in links:
        try:
            netloc = urlparse(link).netloc.lower()
        except ValueError:
            continue
        if netloc.startswith("www."):
            netloc = netloc[4:]
        if netloc and netloc != own_domain:
            domains.add(netloc)
    return domains
