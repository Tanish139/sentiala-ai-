"""Correlation engine: identifies POSSIBLE relationships between results.

Every correlation is a signal, never proof of identity. Language in the
generated explanations is deliberately hedged ("may indicate", "possible").
"""

from __future__ import annotations

from urllib.parse import urlparse

from ..models.investigation import Investigation
from ..models.source import Correlation

MAX_CORRELATIONS = 60

# Domains too common to be a meaningful shared signal.
_NOISE_DOMAINS = {
    "google.com", "gstatic.com", "googleapis.com", "apple.com", "microsoft.com",
    "cloudflare.com", "facebook.com", "twitter.com", "x.com", "instagram.com",
    "youtube.com", "wikipedia.org", "github.com", "reddit.com", "pinterest.com",
    "linkedin.com", "tumblr.com", "medium.com", "wordpress.org", "creativecommons.org",
    "amazon.com", "amzn.to", "youtu.be", "goo.gl", "t.co", "bit.ly", "discord.gg",
    "discord.com", "telegram.me", "t.me", "tiktok.com", "snapchat.com", "whatsapp.com",
    "bing.com", "yahoo.com", "adobe.com", "bootstrap.com", "jquery.com", "w3.org",
    "schema.org", "gravatar.com", "unsplash.com", "shutterstock.com", "pexels.com",
}


def _domain_of(url: str) -> str:
    try:
        netloc = urlparse(url).netloc.lower()
    except ValueError:
        return ""
    return netloc[4:] if netloc.startswith("www.") else netloc


def _external_domains(links: list[str], own_domain: str) -> set[str]:
    domains = set()
    for link in links:
        domain = _domain_of(link)
        if domain and domain != own_domain and domain not in _NOISE_DOMAINS:
            domains.add(domain)
    return domains


def correlate(inv: Investigation) -> list[Correlation]:
    """Find possible public relationships between found results."""
    found = [r for r in inv.results if r.status == "FOUND"]
    correlations: list[Correlation] = []

    # ---------------------------------------------------- public cross-links
    # Source A's public page links to source B's public profile URL.
    for a in found:
        a_domain = a.evidence.domain or ""
        for b in found:
            if a.source == b.source:
                continue
            b_domain = b.evidence.domain or ""
            b_profile_host = _domain_of(b.url)
            if a_domain and b_domain and a_domain == b_domain:
                continue  # same site, skip
            for link in a.evidence.public_links:
                link_domain = _domain_of(link)
                if link_domain and link_domain == b_profile_host:
                    username_in_link = inv.username.lower() in link.lower()
                    correlations.append(
                        Correlation(
                            type="public_cross_link",
                            source_a=a.source,
                            source_b=b.source,
                            signal=link,
                            confidence="likely" if username_in_link else "possible",
                            explanation=(
                                f"The public {a.source} page links to a page on "
                                f"{b_profile_host}, where a profile with this username was found. "
                                "This is a publicly visible cross-link; it may indicate the same "
                                "person or organisation, but it is not proof."
                            ),
                        )
                    )
                    break

    # --------------------------------------------------- shared public domains
    domain_owners: dict[str, list[str]] = {}
    for r in found:
        own = r.evidence.domain or ""
        for d in _external_domains(r.evidence.public_links, own):
            domain_owners.setdefault(d, []).append(r.source)

    for domain, owners in domain_owners.items():
        unique_owners = sorted(set(owners))
        if len(unique_owners) < 2:
            continue
        for i in range(len(unique_owners)):
            for j in range(i + 1, len(unique_owners)):
                correlations.append(
                    Correlation(
                        type="shared_public_domain",
                        source_a=unique_owners[i],
                        source_b=unique_owners[j],
                        signal=domain,
                        confidence="possible",
                        explanation=(
                            f"Both public pages reference the same public domain ({domain}). "
                            "This is a possible shared-domain signal, not an identity claim."
                        ),
                    )
                )

    # ------------------------------------------------------- username reuse
    # The same username found across multiple distinct categories.
    by_category: dict[str, list[str]] = {}
    for r in found:
        if r.confidence in ("high", "medium"):
            by_category.setdefault(r.category, []).append(r.source)
    categories = sorted(by_category)
    if len(categories) >= 2:
        for i in range(len(categories)):
            for j in range(i + 1, len(categories)):
                correlations.append(
                    Correlation(
                        type="username_reuse",
                        source_a=by_category[categories[i]][0],
                        source_b=by_category[categories[j]][0],
                        signal=inv.username,
                        confidence="possible",
                        explanation=(
                            f"The exact username appears publicly in both the "
                            f"{categories[i]} and {categories[j]} categories. "
                            "This may indicate username reuse by one person, multiple people "
                            "choosing the same username, or coincidence."
                        ),
                    )
                )

    # Keep the strongest / most varied signals first, then cap.
    order = {"likely": 0, "possible": 1}
    correlations.sort(key=lambda c: order.get(c.confidence, 2))
    return correlations[:MAX_CORRELATIONS]
