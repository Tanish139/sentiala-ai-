"""The Sentiala source registry: 100+ publicly accessible username sources.

Adding a new source = adding one tuple here. No core engine changes
are ever required.

Tuple layout:
    (name, category, url_template, reliability, error_hints, probe_only)

- ``{u}`` in the URL is replaced with the username.
- ``reliability``: how reliably this platform's response indicates existence.
- ``error_hints``: lowercase substrings that mean "profile does not exist".
- ``probe_only``: URL is a public search/lookup page rather than a profile
  page, so matches are reported with lower confidence.
"""

from __future__ import annotations

from ..models.source import SourceSpec

_RAW_SOURCES: list[tuple] = [
    # ------------------------------------------------------------- Social
    ("Instagram", "Social", "https://www.instagram.com/{u}/", "medium", ("sorry, this page isn't available",), False),
    ("Reddit", "Social", "https://www.reddit.com/user/{u}", "high", ("nobody on reddit goes by that name",), False),
    ("X (Twitter)", "Social", "https://x.com/{u}", "medium", ("this account doesn", "page not found"), False),
    ("TikTok", "Social", "https://www.tiktok.com/@{u}", "medium", ("couldn't find this account",), False),
    ("YouTube", "Social", "https://www.youtube.com/@{u}", "high", ("this page isn't available",), False),
    ("Pinterest", "Social", "https://www.pinterest.com/{u}/", "medium", ("sorry! we couldn't find",), False),
    ("Tumblr", "Social", "https://{u}.tumblr.com", "high", ("whatever you were looking for doesn't currently exist", "there's nothing here"), False),
    ("Threads", "Social", "https://www.threads.net/@{u}", "medium", ("sorry, this page isn't available",), False),
    ("Mastodon", "Social", "https://mastodon.social/@{u}", "high", ("the page you are looking for isn't here",), False),
    ("Bluesky", "Social", "https://bsky.app/profile/{u}", "low", (), False),
    ("Twitch", "Social", "https://www.twitch.tv/{u}", "high", ("content is unavailable", "sorry, the page you requested"), False),
    ("VK", "Social", "https://vk.com/{u}", "medium", ("page not found", "profile is blocked"), False),
    ("Rumble", "Social", "https://rumble.com/user/{u}", "medium", (), False),
    ("Telegram", "Social", "https://t.me/{u}", "high", ("sorry, this page doesn't exist", "nobody on telegram"), False),
    ("Minds", "Social", "https://www.minds.com/{u}", "medium", (), False),
    ("Gab", "Social", "https://gab.com/{u}", "medium", ("page not found",), False),
    ("Truth Social", "Social", "https://truthsocial.com/@{u}", "low", (), False),
    ("Keybase", "Social", "https://keybase.io/{u}", "high", ("but that profile is not found", "profile not found"), False),
    ("Facebook", "Social", "https://www.facebook.com/{u}", "low", (), False),
    ("LinkedIn", "Social", "https://www.linkedin.com/in/{u}", "low", (), False),
    # ---------------------------------------------------------- Developer
    ("GitHub", "Developer", "https://github.com/{u}", "high", ("page not found",), False),
    ("GitLab", "Developer", "https://gitlab.com/{u}", "high", ("page not found",), False),
    ("Bitbucket", "Developer", "https://bitbucket.org/{u}/", "medium", (), False),
    ("Codeberg", "Developer", "https://codeberg.org/{u}", "high", (), False),
    ("CodePen", "Developer", "https://codepen.io/{u}", "high", ("404",), False),
    ("Replit", "Developer", "https://replit.com/@{u}", "medium", (), False),
    ("Kaggle", "Developer", "https://www.kaggle.com/{u}", "medium", (), False),
    ("Hugging Face", "Developer", "https://huggingface.co/{u}", "high", ("404",), False),
    ("Docker Hub", "Developer", "https://hub.docker.com/u/{u}", "medium", (), False),
    ("SourceForge", "Developer", "https://sourceforge.net/u/{u}/profile/", "medium", (), False),
    ("Gitea", "Developer", "https://gitea.com/{u}", "medium", (), False),
    ("HackerRank", "Developer", "https://www.hackerrank.com/profile/{u}", "medium", (), False),
    ("Codewars", "Developer", "https://www.codewars.com/users/{u}", "high", ("404",), False),
    ("LeetCode", "Developer", "https://leetcode.com/{u}/", "medium", (), False),
    ("Hackaday.io", "Developer", "https://hackaday.io/{u}", "medium", (), False),
    ("Exercism", "Developer", "https://exercism.org/profiles/{u}", "high", (), False),
    ("Glitch", "Developer", "https://glitch.com/@{u}", "medium", (), False),
    ("CodeSandbox", "Developer", "https://codesandbox.io/u/{u}", "medium", (), False),
    # --------------------------------------------------------- Publishing
    ("Medium", "Publishing", "https://medium.com/@{u}", "high", ("404", "out of nothing comes nothing"), False),
    ("Dev.to", "Publishing", "https://dev.to/{u}", "high", ("404", "this page does not exist"), False),
    ("Hashnode", "Publishing", "https://hashnode.com/@{u}", "high", (), False),
    ("Substack", "Publishing", "https://{u}.substack.com", "medium", (), False),
    ("Blogger", "Publishing", "https://{u}.blogspot.com", "high", ("blog not found",), False),
    ("Write.as", "Publishing", "https://write.as/{u}/", "medium", (), False),
    ("WordPress.com", "Publishing", "https://{u}.wordpress.com", "medium", ("do you want to register",), False),
    ("Quora", "Publishing", "https://www.quora.com/profile/{u}", "low", (), False),
    ("Wattpad", "Publishing", "https://www.wattpad.com/user/{u}", "medium", (), False),
    ("Issuu", "Publishing", "https://issuu.com/{u}", "medium", (), False),
    ("Telegraph", "Publishing", "https://telegra.ph/{u}", "low", (), True),
    # ----------------------------------------------------------- Creative
    ("Behance", "Creative", "https://www.behance.net/{u}", "medium", (), False),
    ("Dribbble", "Creative", "https://dribbble.com/{u}", "high", ("whoops, that page is gone",), False),
    ("ArtStation", "Creative", "https://www.artstation.com/{u}", "medium", (), False),
    ("DeviantArt", "Creative", "https://www.deviantart.com/{u}", "high", ("browse the art of", "page not found"), False),
    ("Vimeo", "Creative", "https://vimeo.com/{u}", "high", ("oh no, this vimeo", "page not found"), False),
    ("SoundCloud", "Creative", "https://soundcloud.com/{u}", "high", ("we can't find that user",), False),
    ("Flickr", "Creative", "https://www.flickr.com/people/{u}", "medium", (), False),
    ("500px", "Creative", "https://500px.com/p/{u}", "medium", (), False),
    ("Unsplash", "Creative", "https://unsplash.com/@{u}", "high", ("404",), False),
    ("Mixcloud", "Creative", "https://www.mixcloud.com/{u}/", "medium", (), False),
    ("Bandcamp", "Creative", "https://bandcamp.com/{u}", "medium", (), False),
    ("Imgur", "Creative", "https://imgur.com/user/{u}", "medium", (), False),
    ("Newgrounds", "Creative", "https://{u}.newgrounds.com", "medium", (), False),
    ("Sketchfab", "Creative", "https://sketchfab.com/{u}", "medium", (), False),
    ("Redbubble", "Creative", "https://www.redbubble.com/people/{u}/shop", "medium", (), False),
    ("Instructables", "Creative", "https://www.instructables.com/member/{u}/", "medium", (), False),
    # ------------------------------------------------------------- Gaming
    ("Steam", "Gaming", "https://steamcommunity.com/id/{u}", "high", ("the specified profile could not be found",), False),
    ("Roblox", "Gaming", "https://www.roblox.com/search/users/results?keyword={u}&maxRows=1&startIndex=0", "medium", (), True),
    ("Chess.com", "Gaming", "https://www.chess.com/member/{u}", "high", ("page not found",), False),
    ("Lichess", "Gaming", "https://lichess.org/@/{u}", "high", ("page not found",), False),
    ("Speedrun.com", "Gaming", "https://www.speedrun.com/user/{u}", "medium", (), False),
    ("osu!", "Gaming", "https://osu.ppy.sh/users/{u}", "medium", ("user not found",), False),
    ("itch.io", "Gaming", "https://{u}.itch.io", "medium", (), False),
    ("Backloggd", "Gaming", "https://www.backloggd.com/u/{u}/", "medium", (), False),
    # --------------------------------------------------------- Professional
    ("About.me", "Professional", "https://about.me/{u}", "high", (), False),
    ("Linktree", "Professional", "https://linktr.ee/{u}", "high", ("page not found",), False),
    ("Gravatar", "Professional", "https://gravatar.com/{u}", "high", ("profile not found",), False),
    ("ORCID", "Professional", "https://orcid.org/{u}", "low", (), False),
    ("Speaker Deck", "Professional", "https://speakerdeck.com/{u}", "high", (), False),
    ("SlideShare", "Professional", "https://www.slideshare.net/{u}", "medium", (), False),
    ("Patreon", "Professional", "https://www.patreon.com/{u}", "medium", (), False),
    ("Ko-fi", "Professional", "https://ko-fi.com/{u}", "medium", (), False),
    ("Buy Me a Coffee", "Professional", "https://buymeacoffee.com/{u}", "high", (), False),
    ("GitHub Pages", "Professional", "https://{u}.github.io", "high", ("404", "there isn't a github page here"), False),
    ("Beacons", "Professional", "https://beacons.ai/{u}", "medium", (), False),
    ("Carrd", "Professional", "https://{u}.carrd.co", "medium", (), False),
    # ------------------------------------------------------------ Packages
    ("npm", "Packages", "https://www.npmjs.com/~{u}", "high", (), False),
    ("PyPI", "Packages", "https://pypi.org/user/{u}/", "medium", (), False),
    ("Crates.io", "Packages", "https://crates.io/users/{u}", "medium", (), False),
    ("Packagist", "Packages", "https://packagist.org/users/{u}/", "high", (), False),
    ("NuGet", "Packages", "https://www.nuget.org/profiles/{u}", "medium", (), False),
    ("Anaconda", "Packages", "https://anaconda.org/{u}", "medium", (), False),
    ("MetaCPAN", "Packages", "https://metacpan.org/author/{u}", "medium", (), False),
    ("Hex.pm", "Packages", "https://hex.pm/users/{u}", "medium", (), False),
    ("SoloLearn", "Packages", "https://www.sololearn.com/profile/{u}", "low", (), False),
    # ---------------------------------------------------------- Communities
    ("Hacker News", "Communities", "https://news.ycombinator.com/user?id={u}", "high", ("no such user",), False),
    ("Lobsters", "Communities", "https://lobste.rs/u/{u}", "medium", (), False),
    ("Wikipedia", "Communities", "https://en.wikipedia.org/wiki/User:{u}", "high", ("wikipedia does not have a user page",), False),
    ("Fandom", "Communities", "https://community.fandom.com/wiki/User:{u}", "medium", (), False),
    ("Product Hunt", "Communities", "https://www.producthunt.com/@{u}", "medium", (), False),
    ("Indie Hackers", "Communities", "https://www.indiehackers.com/{u}", "low", (), False),
    ("Goodreads", "Communities", "https://www.goodreads.com/{u}", "medium", ("page not found",), False),
    ("Letterboxd", "Communities", "https://letterboxd.com/{u}/", "high", ("sorry, we couldn",), False),
    ("MyAnimeList", "Communities", "https://myanimelist.net/profile/{u}", "high", ("user does not exist", "page not found"), False),
    ("Trakt", "Communities", "https://trakt.tv/users/{u}", "medium", (), False),
    ("Last.fm", "Communities", "https://www.last.fm/user/{u}", "high", (), False),
    ("Spotify", "Communities", "https://open.spotify.com/user/{u}", "low", (), False),
    ("Steemit", "Communities", "https://steemit.com/@{u}", "medium", (), False),
    ("XDA Forums", "Communities", "https://forum.xda-developers.com/m/{u}/", "low", (), False),
    ("BoardGameGeek", "Communities", "https://boardgamegeek.com/user/{u}", "high", ("user does not exist",), False),
    ("Duolingo", "Communities", "https://www.duolingo.com/2017-06-30/users?username={u}", "medium", (), True),
    ("Genius", "Communities", "https://genius.com/{u}", "medium", (), False),
    ("Rate Your Music", "Communities", "https://rateyourmusic.com/~{u}", "medium", (), False),
    ("Discogs", "Communities", "https://www.discogs.com/user/{u}", "high", (), False),
    ("Thingiverse", "Communities", "https://www.thingiverse.com/{u}/designs", "medium", (), False),
    ("Printables", "Communities", "https://www.printables.com/@{u}", "medium", (), False),
    ("Etsy", "Communities", "https://www.etsy.com/shop/{u}", "low", (), False),
    ("Gravatar Blog", "Communities", "https://blog.gravatar.com/author/{u}", "low", (), True),
]


def _build_registry() -> dict[str, SourceSpec]:
    registry: dict[str, SourceSpec] = {}
    for name, category, url, reliability, hints, probe_only in _RAW_SOURCES:
        if name in registry:
            raise ValueError(f"Duplicate source name in registry: {name}")
        registry[name] = SourceSpec(
            name=name,
            category=category,
            url_template=url,
            reliability=reliability,
            error_hints=tuple(h.lower() for h in hints),
            probe_only=probe_only,
        )
    return registry


# The single authoritative registry instance.
SOURCE_REGISTRY: dict[str, SourceSpec] = _build_registry()
