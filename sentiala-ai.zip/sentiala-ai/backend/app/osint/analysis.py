"""AI analysis layer.

Priority:
1. If an external, OpenAI-compatible AI API is configured and reachable,
   use it - but ONLY to interpret collected evidence.
2. Otherwise, fall back to a local, evidence-based analysis.

Either way the AI must never invent evidence: the external prompt only
receives aggregated statistics and the response is validated. Any
failure degrades gracefully to the local fallback.
"""

from __future__ import annotations

import json

import httpx

from ..config import Settings
from ..models.investigation import AnalysisReport, ExposureScore, Investigation

_SYSTEM_PROMPT = (
    "You are the analysis module of Sentiala AI, an ethical OSINT tool. "
    "You only interpret the evidence you are given; you never invent facts. "
    "Correlations are possible signals, never proof of identity. "
    "Respond ONLY with a JSON object with keys: summary (string), "
    "risk_notes (array of strings), confidence (one of high/medium/low). "
    "The summary must clearly hedge identity claims."
)


def _evidence_pack(inv: Investigation, score: ExposureScore) -> dict:
    """Aggregated observed evidence - the only input to any AI."""
    found = [r for r in inv.results if r.status == "FOUND"]
    return {
        "username": inv.username,
        "sources_checked": inv.total_sources,
        "profiles_found": len(found),
        "found_platforms": [r.source for r in found][:40],
        "categories_found": inv.categories_found,
        "public_domains": inv.public_domains[:30],
        "public_links_total": sum(len(r.evidence.public_links) for r in found),
        "pages_with_metadata": sum(
            1 for r in found if r.evidence.page_title_available or r.evidence.description_available
        ),
        "correlation_signals": [
            {"type": c.type, "confidence": c.confidence} for c in inv.correlations[:30]
        ],
        "search_discovery_hits": len(inv.discovery),
        "exposure_score_components": score.components,
    }


async def analyze(
    inv: Investigation,
    score: ExposureScore,
    settings: Settings | None = None,
    client: httpx.AsyncClient | None = None,
) -> AnalysisReport:
    settings = settings or Settings.from_env()
    if settings.ai_api_key:
        report = await _analyze_external(inv, score, settings, client)
        if report is not None:
            return report
    return _analyze_local(inv, score)


# ----------------------------------------------------------------------
async def _analyze_external(
    inv: Investigation,
    score: ExposureScore,
    settings: Settings,
    client: httpx.AsyncClient | None = None,
) -> AnalysisReport | None:
    payload = {
        "model": settings.ai_model,
        "messages": [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {
                "role": "user",
                "content": "Evidence pack (observed public data only):\n"
                + json.dumps(_evidence_pack(inv, score)),
            },
        ],
        "temperature": 0.2,
    }
    headers = {"Authorization": f"Bearer {settings.ai_api_key}"}
    try:
        if client is not None:
            response = await client.post(
                f"{settings.ai_base_url.rstrip('/')}/chat/completions",
                json=payload,
                headers=headers,
                timeout=settings.ai_timeout,
            )
        else:
            async with httpx.AsyncClient(timeout=settings.ai_timeout) as own:
                response = await own.post(
                    f"{settings.ai_base_url.rstrip('/')}/chat/completions",
                    json=payload,
                    headers=headers,
                )
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"]
        parsed = json.loads(_extract_json(content))
        summary = str(parsed.get("summary", "")).strip()
        risk_notes = [str(n) for n in parsed.get("risk_notes", []) if str(n).strip()]
        confidence = str(parsed.get("confidence", "low")).lower()
        if confidence not in ("high", "medium", "low"):
            confidence = "low"
        if not summary:
            return None
        return AnalysisReport(
            summary=summary,
            exposure_score=score.value,
            risk_notes=risk_notes[:10],
            confidence=confidence,
            analyzed_by="external-ai",
        )
    except Exception:
        # Any failure (network, auth, malformed response) -> local fallback.
        return None


def _extract_json(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        return text.strip("`").lstrip("json").strip()
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end != -1:
        return text[start : end + 1]
    return text


# ----------------------------------------------------------------------
def _analyze_local(inv: Investigation, score: ExposureScore) -> AnalysisReport:
    """Deterministic, evidence-based fallback analysis."""
    found = [r for r in inv.results if r.status == "FOUND"]
    found_count = len(found)
    categories = inv.categories_found
    top_platforms = ", ".join(r.source for r in found[:6])
    more = f" and {found_count - 6} more" if found_count > 6 else ""

    if found_count == 0:
        summary = (
            f"No public profiles with the username '{inv.username}' were confirmed "
            f"across {inv.total_sources} checked sources. Some sources may block "
            "automated access, so absence here is not proof of absence anywhere. "
            "This indicates a small publicly discoverable footprint for this username."
        )
        confidence = "high" if inv.completed_count >= inv.total_sources else "medium"
        notes = [
            "No confirmed public profile was found for this username on the checked sources.",
            "Several sources may have blocked or timed out; their state is shown per source.",
        ]
    else:
        summary = (
            f"The username '{inv.username}' appears publicly on {found_count} of "
            f"{inv.total_sources} checked sources across {len(categories)} categories "
            f"({', '.join(categories[:4])}"
            f"{' and more' if len(categories) > 4 else ''}). "
            f"Confirmed platforms include {top_platforms}{more}. "
        )
        if inv.correlations:
            types = sorted({c.type for c in inv.correlations})
            summary += (
                f"{len(inv.correlations)} possible correlation signal(s) were observed "
                f"({', '.join(types)}). These may indicate username reuse or shared public "
                "references; they do not establish that any accounts belong to the same person. "
            )
        else:
            summary += "No public cross-references between the found profiles were observed. "
        if inv.discovery:
            summary += (
                f"Public web discovery additionally surfaced {len(inv.discovery)} indexed page(s) "
                "mentioning the username. "
            )
        summary += "Overall, this represents a "
        summary += ("large" if score.value >= 70 else "moderate" if score.value >= 40 else "small")
        summary += " publicly discoverable footprint for this username. "
        summary += "All findings describe publicly visible information only and do not "
        summary += "establish that any accounts belong to the same person."

        confidence = "high" if found_count >= 10 and len(categories) >= 4 else "medium" if found_count >= 3 else "low"

        notes = []
        if len(categories) >= 3:
            notes.append(
                f"The same username appears publicly across {len(categories)} distinct "
                "categories, which makes cross-platform association easier."
            )
        if any(c.type == "public_cross_link" for c in inv.correlations):
            notes.append(
                "Some public pages contain visible cross-links to other platforms where this "
                "username also appears - a strong, publicly visible association signal."
            )
        if any(c.type == "shared_public_domain" for c in inv.correlations):
            notes.append(
                "Several public pages reference the same external domain, which may link them."
            )
        meta = sum(1 for r in found if r.evidence.description_available)
        if meta > 0:
            notes.append(
                f"{meta} public profile page(s) expose a public description or bio."
            )
        links_total = sum(len(r.evidence.public_links) for r in found)
        if links_total > 50:
            notes.append(
                f"The found public pages expose {links_total} public links in total, "
                "widening the discoverable footprint."
            )
        if inv.discovery:
            notes.append(
                f"The username is referenced on {len(inv.discovery)} publicly indexed "
                "search result page(s)."
            )
        if not notes:
            notes.append(
                "The public footprint is narrow: few profiles, limited metadata and no "
                "observed cross-references between platforms."
            )

    return AnalysisReport(
        summary=summary.strip(),
        exposure_score=score.value,
        risk_notes=notes[:8],
        confidence=confidence,
        analyzed_by="local-evidence-analysis",
    )
