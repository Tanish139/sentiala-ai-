"""Evidence engine: turns raw HTTP responses into honest evidence.

Rules that keep Sentiala honest:
- A 404/410 or an error-hint page means NOT_FOUND (with the source's
  reliability reflected in confidence).
- 5xx / network errors are ERROR - never interpreted as "not found".
- 403 / 429 are BLOCKED - the site declined the request.
- A page that loads but does not visibly contain the username is
  UNCERTAIN (JS-rendered or generic page), never FOUND.
- Only pages that actually show the username are FOUND, and their
  match score is derived from observable evidence only.
"""

from __future__ import annotations

import time
from urllib.parse import urlparse

import httpx

from ..models.source import Evidence, SourceResult, SourceSpec
from ..utils.html import (
    extract_og_description,
    extract_og_image,
    extract_og_site_name,
    extract_og_title,
    extract_meta_description,
    extract_public_links,
    extract_title,
)


def _domain(url: str) -> str:
    try:
        netloc = urlparse(url).netloc.lower()
        return netloc[4:] if netloc.startswith("www.") else netloc
    except ValueError:
        return ""


def _reliability_bonus(reliability: str) -> int:
    return {"high": 10, "medium": 5, "low": 0}.get(reliability, 0)


def _redirects_away(source: SourceSpec, username: str, response: httpx.Response) -> bool:
    """Detect redirects to a login wall or a generic search page."""
    if not response.history:
        return False
    final = response.url
    wanted = username.lower()
    host_ok = _domain(str(final)) == _domain(source.build_url(username))
    path_or_host_has_username = wanted in str(final).lower()
    return not (host_ok and path_or_host_has_username)


def build_result(
    source: SourceSpec,
    username: str,
    response: httpx.Response | None = None,
    error: Exception | None = None,
) -> SourceResult:
    """Build one SourceResult from a response or an error."""
    url = source.build_url(username)
    result = SourceResult(source=source.name, category=source.category, url=url)
    result.set_probe_only(source.probe_only)
    result.evidence.scanned_at = time.strftime("%Y-%m-%dT%H:%M:%S")

    # ------------------------------------------------------------- errors
    if error is not None:
        if isinstance(error, httpx.TimeoutException):
            result.status = "TIMEOUT"
            result.note = "Source did not respond within the timeout."
        else:
            result.status = "ERROR"
            result.note = "Source could not be reached."
        return result

    assert response is not None
    status_code = response.status_code
    body = response.text or ""
    lower = body.lower()
    username_lower = username.lower()
    evidence = Evidence(
        final_url=str(response.url),
        http_status=status_code,
        domain=_domain(str(response.url)) or _domain(url),
        redirect_followed=bool(response.history),
    )
    evidence.scanned_at = result.evidence.scanned_at

    # ------------------------------------------------------- hard errors
    if status_code >= 500:
        result.status = "ERROR"
        result.note = f"Source returned HTTP {status_code}."
        result.evidence = evidence
        return result
    if status_code in (401, 403, 429):
        result.status = "BLOCKED"
        result.note = f"Source declined the request (HTTP {status_code})."
        result.evidence = evidence
        return result
    if _redirects_away(source, username, response):
        result.status = "BLOCKED"
        result.note = "Request was redirected away from the profile URL (possible login wall)."
        result.evidence = evidence
        return result

    # ------------------------------------------------------ page analysis
    evidence.title = extract_title(body) or extract_og_title(body)
    evidence.description = extract_meta_description(body) or extract_og_description(body)
    evidence.public_links = extract_public_links(body)
    evidence.page_title_available = evidence.title is not None
    evidence.description_available = evidence.description is not None
    evidence.public_links_available = bool(evidence.public_links)
    username_in_title = username_lower in (evidence.title or "").lower()
    username_in_body = username_lower in lower

    not_found_hint = any(hint in lower for hint in source.error_hints)

    if status_code in (404, 410) or not_found_hint:
        result.status = "NOT_FOUND"
        result.confidence = "high" if source.reliability == "high" else "medium"
        result.match_score = 0
        result.evidence = evidence
        return result

    # Page loaded (2xx/3xx). Only report FOUND when the username is visible.
    if username_in_body or username_in_title:
        result.status = "FOUND"
        result.evidence = evidence
        evidence.username_found = username_in_body

        score = 50 + _reliability_bonus(source.reliability)
        if username_in_title:
            score += 15
        if evidence.description_available:
            score += 10
        if evidence.public_links_available:
            score += 10
        if source.probe_only:
            score -= 15
        result.match_score = max(35, min(99, score))

        strong = username_in_title and source.reliability == "high" and not source.probe_only
        if strong:
            result.confidence = "high"
        elif source.probe_only or source.reliability == "low":
            result.confidence = "low"
        else:
            result.confidence = "medium"
        if source.probe_only:
            result.note = "Match found on a public search page; verify the profile manually."
        return result

    # Reachable but username not visible: be honest about uncertainty.
    result.status = "UNCERTAIN"
    result.confidence = "low"
    result.note = "Page is reachable but the username is not visible (may require JavaScript)."
    result.evidence = evidence
    return result


# ----------------------------------------------------------------------
def enrich_result(result: SourceResult, body: str, username: str) -> None:
    """Deep-scan enrichment: parse detailed public profile attributes.

    Only fills in what is genuinely present on the public page. Missing
    attributes stay None and the UI shows "Not publicly available."
    """
    if result.status != "FOUND" or not body:
        return
    ev = result.evidence
    og_title = extract_og_title(body)
    ev.og_site_name = extract_og_site_name(body)
    ev.bio = extract_og_description(body) or ev.description
    ev.avatar_url = extract_og_image(body)

    # Display name: og:title often is "Name (@handle)" - keep the part
    # before any parenthesised handle, minus common site suffixes.
    candidate = og_title or ev.title
    if candidate:
        display = candidate
        for sep in (" (@", " (", " | ", " – ", " - ", " · "):
            idx = display.find(sep)
            if idx > 0:
                display = display[:idx]
        display = display.strip()
        # Never present the raw username, the site name or the domain
        # label as a display name - that would be inventing data.
        site_labels = {(ev.og_site_name or "").lower(), domain_first_label(ev.final_url or "")}
        if (
            display
            and display.lower() != username.lower()
            and display.lower() not in site_labels
        ):
            ev.display_name = display


def domain_first_label(url: str) -> str:
    try:
        host = urlparse(url).netloc.lower()
    except ValueError:
        return ""
    host = host[4:] if host.startswith("www.") else host
    return host.split(".")[0]
