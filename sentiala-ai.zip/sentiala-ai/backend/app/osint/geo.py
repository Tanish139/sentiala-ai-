"""Geographic signal analysis.

ONLY evidence-backed public signals are reported. The single signal type
Sentiala legitimately observes is a **country-code top-level domain**
(ccTLD) that appears in public links on a found public profile, or in
publicly indexed search results for the username.

A ccTLD reference means: "this public page references a domain registered
under this country code". It is a *public geographic signal* — it is NOT
the account owner's location, and it is never presented as one.

No countries, profiles or signals are ever fabricated. If no ccTLD
evidence exists, the result is empty and the UI says so.
"""

from __future__ import annotations

from urllib.parse import urlparse

from ..models.investigation import GeoSignal, Investigation

# ccTLD -> (country name, ISO code, latitude, longitude) — centroid used
# only to place a marker on the world map. Common, unambiguous codes.
CCTLD_COUNTRIES = {
    "in": ("India", "IN", 22.35, 78.66),
    "pk": ("Pakistan", "PK", 30.37, 69.34),
    "bd": ("Bangladesh", "BD", 23.68, 90.35),
    "lk": ("Sri Lanka", "LK", 7.87, 80.77),
    "np": ("Nepal", "NP", 28.39, 84.12),
    "cn": ("China", "CN", 35.86, 104.19),
    "jp": ("Japan", "JP", 36.20, 138.25),
    "kr": ("South Korea", "KR", 35.90, 127.76),
    "hk": ("Hong Kong", "HK", 22.39, 114.10),
    "tw": ("Taiwan", "TW", 23.69, 120.96),
    "sg": ("Singapore", "SG", 1.35, 103.81),
    "my": ("Malaysia", "MY", 4.21, 101.97),
    "th": ("Thailand", "TH", 15.87, 100.99),
    "vn": ("Vietnam", "VN", 14.05, 108.27),
    "ph": ("Philippines", "PH", 12.87, 121.77),
    "id": ("Indonesia", "ID", -0.78, 113.92),
    "au": ("Australia", "AU", -25.27, 133.77),
    "nz": ("New Zealand", "NZ", -40.90, 174.88),
    "uk": ("United Kingdom", "GB", 55.37, -3.43),
    "gb": ("United Kingdom", "GB", 55.37, -3.43),
    "ie": ("Ireland", "IE", 53.41, -8.24),
    "fr": ("France", "FR", 46.22, 2.21),
    "de": ("Germany", "DE", 51.16, 10.45),
    "at": ("Austria", "AT", 47.51, 14.55),
    "ch": ("Switzerland", "CH", 46.81, 8.22),
    "it": ("Italy", "IT", 41.87, 12.56),
    "es": ("Spain", "ES", 40.46, -3.74),
    "pt": ("Portugal", "PT", 39.39, -8.22),
    "nl": ("Netherlands", "NL", 52.13, 5.29),
    "be": ("Belgium", "BE", 50.50, 4.46),
    "lu": ("Luxembourg", "LU", 49.81, 6.13),
    "se": ("Sweden", "SE", 60.12, 18.63),
    "no": ("Norway", "NO", 60.47, 8.46),
    "dk": ("Denmark", "DK", 56.26, 9.50),
    "fi": ("Finland", "FI", 61.92, 25.74),
    "is": ("Iceland", "IS", 64.96, -19.02),
    "pl": ("Poland", "PL", 51.91, 19.14),
    "cz": ("Czechia", "CZ", 49.81, 15.47),
    "sk": ("Slovakia", "SK", 48.66, 19.69),
    "hu": ("Hungary", "HU", 47.16, 19.50),
    "ro": ("Romania", "RO", 45.94, 24.96),
    "bg": ("Bulgaria", "BG", 42.73, 25.48),
    "gr": ("Greece", "GR", 39.07, 21.82),
    "tr": ("Türkiye", "TR", 38.96, 35.24),
    "ru": ("Russia", "RU", 61.52, 105.31),
    "ua": ("Ukraine", "UA", 48.38, 31.16),
    "by": ("Belarus", "BY", 53.70, 27.95),
    "lt": ("Lithuania", "LT", 55.16, 23.88),
    "lv": ("Latvia", "LV", 56.87, 24.60),
    "ee": ("Estonia", "EE", 58.59, 25.01),
    "hr": ("Croatia", "HR", 45.10, 15.19),
    "rs": ("Serbia", "RS", 44.01, 21.00),
    "si": ("Slovenia", "SI", 46.15, 14.99),
    "mx": ("Mexico", "MX", 23.63, -102.55),
    "br": ("Brazil", "BR", -14.23, -51.92),
    "ar": ("Argentina", "AR", -38.41, -63.61),
    "cl": ("Chile", "CL", -35.67, -71.54),
    "co": ("Colombia", "CO", 4.57, -74.29),
    "pe": ("Peru", "PE", -9.19, -75.01),
    "uy": ("Uruguay", "UY", -32.52, -55.76),
    "ca": ("Canada", "CA", 56.13, -106.34),
    "us": ("United States", "US", 37.09, -95.71),
    "il": ("Israel", "IL", 31.04, 34.85),
    "sa": ("Saudi Arabia", "SA", 23.88, 45.07),
    "ae": ("United Arab Emirates", "AE", 23.42, 53.84),
    "eg": ("Egypt", "EG", 26.82, 30.80),
    "za": ("South Africa", "ZA", -30.55, 22.93),
    "ng": ("Nigeria", "NG", 9.08, 8.67),
    "ke": ("Kenya", "KE", -0.02, 37.90),
    "ma": ("Morocco", "MA", 31.79, -7.09),
    "ke": ("Kenya", "KE", -0.02, 37.90),
}

# Domain suffixes that look like ccTLDs but are widely used generically
# and therefore carry no geographic meaning.
GENERIC_SUFFICES = {
    "co", "com", "net", "org", "info", "io", "me", "tv", "gg", "so",
    "fm", "am", "cc", "cd", "dj", "gt", "la", "ly", "sh", "st", "to", "ws",
    "gd", "ms", "nu", "su", "tk", "tl", "vu",
}


def domain_country(domain: str) -> tuple[str, str, float, float] | None:
    """Map a domain to (country, iso, lat, lon) via its ccTLD, if unambiguous."""
    if not domain:
        return None
    labels = domain.rstrip(".").split(".")
    if len(labels) < 2:
        return None
    tld = labels[-1].lower()
    if len(tld) != 2 or tld in GENERIC_SUFFICES:
        return None
    if tld not in CCTLD_COUNTRIES:
        return None
    # Two-label ccTLDs like .co.in / .com.br: the second-level label is
    # generic, so the country remains the last label.
    return CCTLD_COUNTRIES[tld]


def analyze_geographic_signals(inv: Investigation) -> list[GeoSignal]:
    """Collect public geographic signals (ccTLD references) from evidence."""
    signals: list[GeoSignal] = []
    seen: set[tuple[str, str, str]] = set()

    # 1. ccTLDs referenced in public links on FOUND profiles
    for result in inv.results:
        if result.status != "FOUND":
            continue
        own_domain = result.evidence.domain or ""
        for link in result.evidence.public_links:
            try:
                host = urlparse(link).netloc.lower()
            except ValueError:
                continue
            host = host[4:] if host.startswith("www.") else host
            if host == own_domain:
                continue
            country = domain_country(host)
            if not country:
                continue
            key = (result.source, host, country[1])
            if key in seen:
                continue
            seen.add(key)
            name, iso, lat, lon = country
            signals.append(
                GeoSignal(
                    country=name,
                    country_code=iso,
                    latitude=lat,
                    longitude=lon,
                    signal_type="country_code_domain",
                    domain=host,
                    source=result.source,
                    url=link,
                    confidence="weak",
                    explanation=(
                        f"The public {result.source} profile references the domain '{host}', "
                        f"which is registered under the {name} country-code TLD '.{iso.lower()}'. "
                        "This is a public geographic signal about a referenced domain - it does "
                        "not establish the account owner's location."
                    ),
                )
            )

    # 2. ccTLDs in publicly indexed search results
    for hit in inv.discovery:
        country = domain_country(hit.domain)
        if not country:
            continue
        key = ("discovery", hit.domain, country[1])
        if key in seen:
            continue
        seen.add(key)
        name, iso, lat, lon = country
        signals.append(
            GeoSignal(
                country=name,
                country_code=iso,
                latitude=lat,
                longitude=lon,
                signal_type="country_code_domain",
                domain=hit.domain,
                source="Public web discovery",
                url=hit.url,
                confidence="weak",
                explanation=(
                    f"A publicly indexed search result for the username is hosted on '{hit.domain}', "
                    f"registered under the {name} country-code TLD '.{iso.lower()}'. "
                    "This is a public geographic signal about a hosting domain - it does not "
                    "establish the account owner's location."
                ),
            )
        )

    return signals
