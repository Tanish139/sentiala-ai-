"""API routes."""

from __future__ import annotations

import asyncio
import uuid

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse

from ..models.investigation import Investigation
from ..schemas.investigation import (
    HealthResponse,
    InvestigationCreate,
    InvestigationCreated,
)
from ..services.report import render_report
from ..utils.validation import validate_username

router = APIRouter(prefix="/api")


def _state(request: Request):
    return request.app.state


@router.get("/health", response_model=HealthResponse)
async def health(request: Request) -> HealthResponse:
    state = _state(request)
    return HealthResponse(
        status="operational",
        app=state.settings.app_name,
        version=state.settings.app_version,
        sources=state.registry.total,
        categories=state.registry.categories,
    )


@router.get("/sources")
async def sources(request: Request) -> dict:
    state = _state(request)
    return state.registry.summary()


@router.post("/investigations", response_model=InvestigationCreated, status_code=201)
async def create_investigation(body: InvestigationCreate, request: Request) -> InvestigationCreated:
    state = _state(request)
    validation = validate_username(body.username)
    if not validation.valid:
        raise HTTPException(status_code=422, detail=validation.reason)

    username = body.username.strip()
    investigation = Investigation.create(username)

    async def _runner() -> None:
        try:
            await state.engine.run(investigation)
        finally:
            state.db.save_investigation(investigation.to_dict())

    state.investigations[investigation.id] = investigation
    state.tasks.append(asyncio.create_task(_runner()))
    return InvestigationCreated(
        id=investigation.id,
        username=username,
        status=investigation.status,
        total_sources=state.registry.total,
    )


@router.get("/investigations")
async def list_investigations(request: Request) -> list[dict]:
    state = _state(request)
    live = [
        {
            "id": inv.id,
            "username": inv.username,
            "status": inv.status,
            "created_at": inv.created_at,
            "counts": inv.to_dict()["counts"],
            "score": inv.score.value if inv.score else None,
        }
        for inv in state.investigations.values()
    ]
    stored = state.db.list_investigations()
    seen = {item["id"] for item in live}
    return live + [item for item in stored if item["id"] not in seen]


@router.get("/investigations/{inv_id}")
async def get_investigation(inv_id: str, request: Request) -> dict:
    state = _state(request)
    investigation = state.investigations.get(inv_id)
    if investigation is not None:
        return investigation.to_dict()
    stored = state.db.get_investigation(inv_id)
    if stored is None:
        raise HTTPException(status_code=404, detail="Investigation not found.")
    return stored


@router.get("/investigations/{inv_id}/report", response_class=HTMLResponse)
async def investigation_report(inv_id: str, request: Request) -> str:
    state = _state(request)
    investigation = state.investigations.get(inv_id)
    if investigation is not None:
        return render_report(investigation.to_dict())
    stored = state.db.get_investigation(inv_id)
    if stored is None:
        raise HTTPException(status_code=404, detail="Investigation not found.")
    return render_report(stored)
