"""SQLite persistence for investigations.

SQLite is used by default so that Sentiala runs locally with zero
setup. Persistence is intentionally simple: the investigation snapshot
is stored as JSON alongside a few indexed columns.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path

_SCHEMA = """
CREATE TABLE IF NOT EXISTS investigations (
    id          TEXT PRIMARY KEY,
    username    TEXT NOT NULL,
    status      TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL,
    result_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_investigations_created
    ON investigations (created_at DESC);
"""


class Database:
    def __init__(self, path: Path | str) -> None:
        self._path = Path(path)
        if str(self._path) != ":memory:":
            self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self._path), check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        with self._lock, self._conn:
            self._conn.executescript(_SCHEMA)

    # ------------------------------------------------------------------
    def save_investigation(self, inv_dict: dict) -> None:
        import time

        with self._lock, self._conn:
            self._conn.execute(
                """
                INSERT INTO investigations (id, username, status, created_at, updated_at, result_json)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    status = excluded.status,
                    updated_at = excluded.updated_at,
                    result_json = excluded.result_json
                """,
                (
                    inv_dict["id"],
                    inv_dict["username"],
                    inv_dict["status"],
                    inv_dict["created_at"],
                    time.strftime("%Y-%m-%dT%H:%M:%S"),
                    json.dumps(inv_dict),
                ),
            )

    def get_investigation(self, inv_id: str) -> dict | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT result_json FROM investigations WHERE id = ?", (inv_id,)
            ).fetchone()
        return json.loads(row[0]) if row else None

    def list_investigations(self, limit: int = 50) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT id, username, status, created_at, result_json
                FROM investigations ORDER BY created_at DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
        summaries = []
        for inv_id, username, status, created_at, blob in rows:
            data = json.loads(blob)
            summaries.append(
                {
                    "id": inv_id,
                    "username": username,
                    "status": status,
                    "created_at": created_at,
                    "counts": data.get("counts", {}),
                    "score": (data.get("score") or {}).get("value"),
                }
            )
        return summaries

    def close(self) -> None:
        with self._lock:
            self._conn.close()
