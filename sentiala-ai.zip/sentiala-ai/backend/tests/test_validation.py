"""Tests: username validation."""

from backend.app.utils.validation import validate_username


def test_valid_usernames():
    for name in ["torvalds", "Linus.Torvalds", "dev_01", "x-9", "ab", "A" * 32]:
        assert validate_username(name).valid, name


def test_too_short():
    assert not validate_username("").valid
    assert not validate_username("x").valid


def test_too_long():
    assert not validate_username("a" * 33).valid


def test_illegal_characters():
    for name in ["bad name", "semi;colon", "quote'", 'dq"', "slash/", "back\\slash",
                 "<script>", "%41", "café", "tab\tchar", "new\nline"]:
        assert not validate_username(name).valid, name


def test_edge_shapes():
    assert not validate_username(".starts").valid
    assert not validate_username("ends.").valid
    assert not validate_username("..").valid
    assert not validate_username("None").valid  # reserved
    assert not validate_username(12345).valid   # non-string


def test_reason_returned():
    result = validate_username("")
    assert result.reason
