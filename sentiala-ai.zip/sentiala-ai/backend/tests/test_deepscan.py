"""Tests: deep-scan upgrades - stages, enrichment, geo signals, evidence items."""

import asyncio

import httpx

from backend.app.config import Settings
from backend.app.models.investigation import Investigation
from backend.app.models.source import DiscoveryResult, Evidence, SourceResult
from backend.app.osint.discovery import DiscoveryEngine
from backend.app.osint.engine import InvestigationEngine
from backend.app.osint.evidence import enrich_result
from backend.app.osint.evidence_items import build_evidence_items
from backend.app.osint.geo import analyze_geographic_signals, domain_country
from backend.app.osint.registry import SourceRegistry
from backend.app.osint.scoring import compute_exposure_score
from backend.app.models.source import SourceSpec


# ---------------------------------------------------------------- helpers
def _found(platform, category, links=(), domain=None, extra=None):
    result = SourceResult(
        source=platform,
        category=category,
        url=f"https://{domain or 'x.com'}/{platform.lower()}",
        status="FOUND",
        confidence="medium",
        match_score=75,
        evidence=Evidence(
            username_found=True,
            page_title_available=True,
            description_available=True,
            domain=domain or "x.com",
            public_links=list(links),
        ),
    )
    for key, value in (extra or {}).items():
        setattr(result.evidence, key, value)
    return result


def _inv_with(results, discovery=(), correlations=()):
    inv = Investigation.create("testuser")
    inv.total_sources = 10
    inv.results = results
    inv.result_index = {r.source: r for r in results}
    inv.discovery = list(discovery)
    inv.correlations = list(correlations)
    return inv


# ------------------------------------------------------------ enrichment
def test_enrich_result_extracts_public_attributes():
    result = _found("GitHub", "Developer", domain="github.com")
    body = """
    <html><head>
    <meta property="og:title" content="Linus Torvalds (testuser) · GitHub">
    <meta property="og:description" content="Public profile of testuser, kernel stuff.">
    <meta property="og:image" content="https://avatars.githubusercontent.com/u/1?v=4">
    <meta property="og:site_name" content="GitHub">
    </head></html>"""
    enrich_result(result, body, "testuser")
    assert result.evidence.display_name == "Linus Torvalds"
    assert "kernel stuff" in result.evidence.bio
    assert result.evidence.avatar_url == "https://avatars.githubusercontent.com/u/1?v=4"
    assert result.evidence.og_site_name == "GitHub"


def test_enrich_result_never_invents_missing_data():
    result = _found("Plain", "Social", domain="plain.io")
    enrich_result(result, "<html><body>no meta tags</body></html>", "testuser")
    assert result.evidence.display_name is None
    assert result.evidence.bio is None
    assert result.evidence.avatar_url is None


def test_enrich_result_skips_non_found():
    result = SourceResult("X", "Social", "https://x.com/y", "NOT_FOUND", "medium")
    enrich_result(result, "<title>nope</title>", "testuser")
    assert result.evidence.display_name is None


# ------------------------------------------------------------------- geo
def test_domain_country_maps_cctld():
    assert domain_country("example.co.in")[0] == "India"
    assert domain_country("site.de")[0] == "Germany"
    assert domain_country("example.io") is None       # generic
    assert domain_country("example.com") is None
    assert domain_country("example.co.uk")[0] == "United Kingdom"


def test_geo_signals_from_cctld_links():
    inv = _inv_with([
        _found("GitHub", "Developer", links=["https://blog.example.in/post"], domain="github.com"),
    ])
    signals = analyze_geographic_signals(inv)
    assert len(signals) == 1
    assert signals[0].country == "India"
    assert signals[0].source == "GitHub"
    assert "does not establish the account owner's location" in signals[0].explanation


def test_geo_signals_from_discovery_domains():
    inv = _inv_with(
        [_found("A", "Social", domain="a.com")],
        discovery=[DiscoveryResult("https://x.example.fr/p", None, "x.example.fr", None, "t")],
    )
    signals = analyze_geographic_signals(inv)
    assert any(s.country == "France" and s.source == "Public web discovery" for s in signals)


def test_no_geo_signals_when_no_cctld_evidence():
    inv = _inv_with([
        _found("GitHub", "Developer", links=["https://generic.io/x"], domain="github.com"),
    ])
    assert analyze_geographic_signals(inv) == []


# ---------------------------------------------------------- evidence items
def test_evidence_items_classifications():
    from backend.app.models.source import Correlation

    inv = _inv_with(
        [_found("GitHub", "Developer", domain="github.com", extra={"bio": "Public bio.", "display_name": "Some One"})],
        discovery=[DiscoveryResult("https://d.com/x", "Title", "d.com", "snip", "t")],
        correlations=[Correlation("shared_public_domain", "A", "B", "dom.com", "possible", "why")],
    )
    items = build_evidence_items(inv)
    classes = {i.classification for i in items}
    assert "DIRECT EVIDENCE" in classes
    assert "CORRELATED SIGNAL" in classes
    assert "UNCONFIRMED" in classes
    direct = [i for i in items if i.classification == "DIRECT EVIDENCE"]
    assert any(i.evidence_type == "username match" for i in direct)
    assert any(i.evidence_type == "public bio" for i in direct)


def test_evidence_items_weak_signal_for_uncertain():
    uncertain = SourceResult("TikTok", "Social", "https://tiktok.com/@u", "UNCERTAIN", "low",
                             note="Page is reachable but the username is not visible")
    inv = _inv_with([uncertain])
    items = build_evidence_items(inv)
    assert any(i.classification == "WEAK SIGNAL" for i in items)


def test_evidence_items_never_claim_identity():
    inv = _inv_with([_found("GitHub", "Developer", domain="github.com")])
    joined = " ".join(i.why_it_matters for i in build_evidence_items(inv))
    lowered = joined.lower()
    # no item may assert identity beyond "the username exists"
    for phrase in ("belongs to the same person", "is the same person",
                   "identity confirmed", "confirmed identity", "definitely"):
        assert phrase not in lowered


# ---------------------------------------------------------------- scoring
def test_score_groups_present():
    from backend.app.models.investigation import ExposureScore

    inv = _inv_with([_found("A", "Developer"), _found("B", "Gaming")])
    score = compute_exposure_score(inv, SourceRegistry())
    assert set(score.groups) == {
        "source_coverage", "identity_signals", "cross_platform_correlation",
        "public_information_exposure", "geographic_signals",
    }
    assert all(0 <= v <= 100 for v in score.groups.values())
    # groups respond to real inputs
    assert score.groups["cross_platform_correlation"] == 0
    inv.correlations = [1, 2, 3]  # any non-empty list drives the group up
    score2 = compute_exposure_score(inv, SourceRegistry())
    assert score2.groups["cross_platform_correlation"] == 60


# ----------------------------------------------------------------- stages
def _mock_client(username):
    def handle(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        if "github.com" in url:
            return httpx.Response(200, text=(
                f"<title>{username} · GitHub</title>"
                "<meta property='og:title' content='Some One (x) · GitHub'>"
                "<meta property='og:description' content='A public bio.'>"
                "<meta property='og:image' content='https://img.githubusercontent.com/a.png'>"
                "<a href='https://blog.example.in/about'>blog</a>"
            ), request=request)
        return httpx.Response(404, text="not found", request=request)

    return httpx.AsyncClient(transport=httpx.MockTransport(handle), follow_redirects=True)


def test_deep_scan_pipeline_stages():
    registry = SourceRegistry({
        "GitHub": SourceSpec("GitHub", "Developer", "https://github.com/{u}", "high", ("page not found",)),
        "Reddit": SourceSpec("Reddit", "Social", "https://reddit.com/user/{u}", "high", ()),
    })
    settings = Settings(request_timeout=5, max_concurrency=5, discovery_enabled=False, ai_api_key="")
    engine = InvestigationEngine(registry, settings)
    inv = Investigation.create("someuser")

    async def scenario():
        async with _mock_client("someuser") as client:
            return await engine.run(inv, client=client)

    inv = asyncio.run(scenario())
    d = inv.to_dict()

    assert inv.status == "COMPLETED"
    # every deep-scan stage ran and completed
    assert [s["status"] for s in d["stages"]] == ["DONE"] * 10
    stage_keys = [s["key"] for s in d["stages"]]
    assert stage_keys[0] == "initializing" and stage_keys[-1] == "report"
    # variant list exposed (even when discovery is disabled)
    assert d["variants"] == ["someuser"]
    # platform detail fields present
    gh = next(r for r in d["results"] if r["platform"] == "GitHub")
    assert gh["source_type"] == "public profile page"
    assert gh["match_explanation"]
    assert gh["public_evidence"]["display_name"] == "Some One"
    assert gh["public_evidence"]["bio"] == "A public bio."
    assert gh["public_evidence"]["avatar_url"].startswith("https://img")
    assert gh["public_evidence"]["response_time_ms"] >= 0
    assert gh["public_evidence"]["scanned_at"]
    # evidence items and geo signals flow through the API shape
    assert d["evidence_items"]
    assert any(i["classification"] == "DIRECT EVIDENCE" for i in d["evidence_items"])
    assert d["geo_signals"] and d["geo_signals"][0]["country"] == "India"
    assert d["counts"]["geo_countries"] == 1
    assert d["score"]["groups"]["geographic_signals"] > 0


def test_discovery_variant_dedup_and_tagging():
    settings = Settings(request_timeout=5, discovery_enabled=True, ai_api_key="")
    engine = DiscoveryEngine(settings)

    page1 = ('<a class="result__a" href="https://a.com/x">A</a>'
             '<a class="result__snippet">s</a>')
    page2 = ('<a class="result__a" href="https://a.com/x">A dup</a>'
             '<a class="result__a" href="https://b.com/y">B</a>'
             '<a class="result__snippet">s1</a><a class="result__snippet">s2</a>')

    def handle(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text=page1 if b"User" in request.content else page2, request=request)

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(handle)) as client:
            return await engine.search_many(["User", "user"], client=client)

    result = asyncio.run(scenario())
    # variant 1 keeps its hit; variant 2 dedups the same URL and adds the new one
    assert [h.url for h in result["User"]] == ["https://a.com/x"]
    assert {h.url for h in result["user"]} == {"https://b.com/y"}
    assert all(h.matched_variant in ("User", "user") for hits in result.values() for h in hits)
