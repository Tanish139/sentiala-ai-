"""Tests: FastAPI endpoints (health, create, retrieve, errors) with a stub engine."""

import time

import pytest
from fastapi.testclient import TestClient

from backend.app.config import Settings
from backend.app.main import create_app
from backend.app.models.source import Evidence, SourceResult


class StubEngine:
    """Deterministic engine so API tests never touch the network."""

    async def run(self, inv, client=None):
        inv.total_sources = 2
        inv.add_event("Investigation initialized")
        for name, cat, status in [("GitHub", "Developer", "FOUND"), ("Reddit", "Social", "NOT_FOUND")]:
            inv.add_result(
                SourceResult(
                    source=name,
                    category=cat,
                    url=f"https://x/{name}",
                    status=status,
                    confidence="high" if status == "FOUND" else "medium",
                    match_score=80 if status == "FOUND" else 0,
                    evidence=Evidence(username_found=status == "FOUND", domain="x"),
                )
            )
        inv.discovery_status = "FAILED"
        inv.correlations = []
        inv.correlation_status = "DONE"
        inv.analysis_status = "DONE"
        from backend.app.models.investigation import AnalysisReport, ExposureScore

        inv.score = ExposureScore(30, {"profile_breadth": 50})
        inv.analysis = AnalysisReport(
            summary="Stub summary.",
            exposure_score=30,
            risk_notes=[],
            confidence="low",
        )
        inv.status = "COMPLETED"
        inv.add_event("Investigation finalized")


@pytest.fixture()
def client(tmp_path):
    app = create_app(Settings(database_path=tmp_path / "test.db", discovery_enabled=False))
    app.state.engine = StubEngine()
    with TestClient(app) as test_client:
        yield test_client


def _wait_for_status(client, inv_id, status, timeout=5.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        data = client.get(f"/api/investigations/{inv_id}").json()
        if data["status"] == status:
            return data
        time.sleep(0.05)
    return data


def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "operational"
    assert body["sources"] >= 100
    assert body["free"] is True


def test_api_health_endpoint(client):
    body = client.get("/api/health").json()
    assert body["app"] == "Sentiala AI"


def test_sources_endpoint(client):
    body = client.get("/api/sources").json()
    assert body["total_sources"] >= 100
    assert sum(body["categories"].values()) == body["total_sources"]


def test_create_and_get_investigation(client):
    response = client.post("/api/investigations", json={"username": "testuser"})
    assert response.status_code == 201
    created = response.json()
    assert created["username"] == "testuser"
    assert created["total_sources"] >= 100

    data = _wait_for_status(client, created["id"], "COMPLETED")
    assert data["status"] == "COMPLETED"
    assert data["counts"]["found"] == 1
    assert data["analysis"]["summary"] == "Stub summary."
    assert 0 <= data["score"]["value"] <= 100
    assert data["progress"]["percent"] == 100


def test_list_investigations(client):
    client.post("/api/investigations", json={"username": "listuser"})
    response = client.get("/api/investigations")
    assert response.status_code == 200
    usernames = [item["username"] for item in response.json()]
    assert "listuser" in usernames


def test_invalid_username_rejected(client):
    for bad in ["", "  ", "bad name!", "x" * 40, "..", "admin"]:
        response = client.post("/api/investigations", json={"username": bad})
        assert response.status_code == 422, bad


def test_unknown_investigation_404(client):
    assert client.get("/api/investigations/doesnotexist").status_code == 404
    assert client.get("/api/investigations/doesnotexist/report").status_code == 404


def test_html_report_generated(client):
    created = client.post("/api/investigations", json={"username": "reportuser"}).json()
    _wait_for_status(client, created["id"], "COMPLETED")
    response = client.get(f"/api/investigations/{created['id']}/report")
    assert response.status_code == 200
    assert "text/html" in response.headers["content-type"]
    assert "reportuser" in response.text
    assert "GITHUB" in response.text.upper()


def test_frontend_served(client):
    response = client.get("/")
    assert response.status_code == 200
    assert "Sentiala" in response.text
