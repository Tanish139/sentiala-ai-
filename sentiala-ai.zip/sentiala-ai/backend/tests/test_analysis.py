"""Tests: AI analysis - local fallback, external validation, degradation."""

import asyncio
import json

import httpx

from backend.app.config import Settings
from backend.app.models.investigation import ExposureScore, Investigation
from backend.app.models.source import Evidence, SourceResult
from backend.app.osint.analysis import _analyze_local, _extract_json, analyze


def _inv():
    inv = Investigation.create("testuser")
    inv.total_sources = 50
    inv.results = [
        SourceResult("GitHub", "Developer", "https://github.com/testuser", "FOUND", "high",
                     85, Evidence(username_found=True, page_title_available=True,
                                  description_available=True, domain="github.com")),
        SourceResult("Chess.com", "Gaming", "https://chess.com/member/testuser", "FOUND", "medium",
                     70, Evidence(username_found=True, domain="chess.com")),
    ]
    inv.result_index = {r.source: r for r in inv.results}
    return inv


def _run(coro):
    return asyncio.run(coro)


def _mock_client(handler):
    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


def test_local_fallback_summary_reflects_evidence():
    inv = _inv()
    report = _analyze_local(inv, ExposureScore(42, {}))
    assert "testuser" in report.summary
    assert "2 of 50" in report.summary
    assert report.analyzed_by == "local-evidence-analysis"
    assert report.confidence in ("high", "medium", "low")
    assert report.risk_notes


def test_local_fallback_no_profiles():
    inv = Investigation.create("ghost")
    inv.total_sources = 50
    report = _analyze_local(inv, ExposureScore(5, {}))
    assert "No public profiles" in report.summary


def test_local_fallback_hedges_identity():
    inv = _inv()
    report = _analyze_local(inv, ExposureScore(60, {}))
    joined = report.summary + " ".join(report.risk_notes)
    # never claims identity; language stays hedged
    assert "definitely belong" not in joined
    assert "same person" in joined or "not establish" in joined or "do not establish" in joined


def test_analyze_without_key_uses_local(monkeypatch):
    monkeypatch.delenv("SENTIALA_AI_API_KEY", raising=False)
    settings = Settings(ai_api_key="", discovery_enabled=False)
    inv = _inv()
    report = _run(analyze(inv, ExposureScore(40, {}), settings=settings))
    assert report.analyzed_by == "local-evidence-analysis"


def test_analyze_with_external_ai_success():
    settings = Settings(ai_api_key="test-key", ai_base_url="https://fake/v1", discovery_enabled=False)

    def handler(request):
        return httpx.Response(200, json={
            "choices": [{"message": {"content": json.dumps({
                "summary": "The username appears across several public platforms.",
                "risk_notes": ["Cross-category username reuse observed."],
                "confidence": "medium",
            })}}]
        })

    async def scenario():
        inv = _inv()
        async with _mock_client(handler) as client:
            return await analyze(inv, ExposureScore(55, {}), settings=settings, client=client)

    report = _run(scenario())
    assert report.analyzed_by == "external-ai"
    assert report.confidence == "medium"
    assert report.risk_notes


def test_analyze_external_failure_degrades_to_local():
    settings = Settings(ai_api_key="test-key", ai_base_url="https://fake/v1", discovery_enabled=False)

    def handler(request):
        return httpx.Response(500, text="boom")

    async def scenario():
        inv = _inv()
        async with _mock_client(handler) as client:
            return await analyze(inv, ExposureScore(55, {}), settings=settings, client=client)

    report = _run(scenario())
    assert report.analyzed_by == "local-evidence-analysis"


def test_analyze_external_malformed_degrades_to_local():
    settings = Settings(ai_api_key="test-key", ai_base_url="https://fake/v1", discovery_enabled=False)

    def handler(request):
        return httpx.Response(200, json={"choices": [{"message": {"content": "not json at all"}}]})

    async def scenario():
        inv = _inv()
        async with _mock_client(handler) as client:
            return await analyze(inv, ExposureScore(55, {}), settings=settings, client=client)

    report = _run(scenario())
    assert report.analyzed_by == "local-evidence-analysis"


def test_extract_json_from_codefence():
    assert _extract_json("```json\n{\"a\": 1}\n```") == '{"a": 1}'
    assert _extract_json('prefix {"a": 1} suffix') == '{"a": 1}'
