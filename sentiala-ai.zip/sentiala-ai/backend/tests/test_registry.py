"""Tests: source registry integrity and URL generation."""

import pytest

from backend.app.models.source import SourceSpec
from backend.app.osint.registry import SourceRegistry
from backend.app.osint.sources import _RAW_SOURCES


def test_registry_has_at_least_100_sources():
    registry = SourceRegistry()
    assert registry.total >= 100
    assert registry.total == len(_RAW_SOURCES)


def test_registry_reports_100_plus():
    summary = SourceRegistry().summary()
    assert summary["total_sources"] >= 100
    assert summary["total_sources"] == sum(summary["categories"].values())


def test_source_names_unique():
    names = [s[0] for s in _RAW_SOURCES]
    assert len(names) == len(set(names))


def test_expected_categories_present():
    categories = SourceRegistry().categories
    for expected in ["Social", "Developer", "Publishing", "Creative", "Gaming", "Professional", "Packages"]:
        assert expected in categories


def test_url_template_generation():
    registry = SourceRegistry()
    github = registry.get("GitHub")
    assert github is not None
    assert github.build_url("torvalds") == "https://github.com/torvalds"


def test_url_template_subdomain_generation():
    registry = SourceRegistry()
    tumblr = registry.get("Tumblr")
    assert tumblr.build_url("someone") == "https://someone.tumblr.com"


def test_url_always_contains_username():
    registry = SourceRegistry()
    for source in registry.all_sources():
        url = source.build_url("SomeUser_01")
        assert "SomeUser_01" in url, source.name


def test_source_fields_valid():
    for source in SourceRegistry().all_sources():
        assert isinstance(source, SourceSpec)
        assert source.category
        assert source.reliability in ("high", "medium", "low")


def test_get_unknown_source_returns_none():
    assert SourceRegistry().get("DoesNotExist123") is None
