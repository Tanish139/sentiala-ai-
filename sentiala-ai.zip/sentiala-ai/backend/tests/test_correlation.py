"""Tests: correlation engine - possible signals, never identity claims."""

from backend.app.models.investigation import Investigation
from backend.app.models.source import Correlation, Evidence, SourceResult
from backend.app.osint.correlation import correlate


def _found(platform, category, links=(), domain="example.com", url=None):
    return SourceResult(
        source=platform,
        category=category,
        url=url or f"https://{domain}/{platform.lower()}",
        status="FOUND",
        confidence="medium",
        match_score=70,
        evidence=Evidence(
            username_found=True,
            page_title_available=True,
            domain=domain,
            public_links=list(links),
        ),
    )


def test_shared_public_domain_detected():
    inv = Investigation.create("user1")
    inv.total_sources = 10
    inv.results = [
        _found("GitHub", "Developer", links=["https://myblog.dev/about"], domain="github.com"),
        _found("Reddit", "Social", links=["https://myblog.dev/post"], domain="reddit.com"),
    ]
    inv.result_index = {r.source: r for r in inv.results}
    correlations = correlate(inv)
    shared = [c for c in correlations if c.type == "shared_public_domain"]
    assert shared, "expected a shared_public_domain correlation"
    assert shared[0].signal == "myblog.dev"
    assert "not an identity claim" in shared[0].explanation or "not proof" in shared[0].explanation


def test_noise_domains_ignored():
    inv = Investigation.create("user1")
    inv.total_sources = 10
    inv.results = [
        _found("A", "Developer", links=["https://google.com/x"], domain="a.io"),
        _found("B", "Social", links=["https://google.com/y"], domain="b.io"),
    ]
    inv.result_index = {r.source: r for r in inv.results}
    assert not [c for c in correlate(inv) if c.type == "shared_public_domain"]


def test_cross_link_detected():
    inv = Investigation.create("user1")
    inv.total_sources = 10
    inv.results = [
        _found("GitHub", "Developer", links=["https://reddit.com/user/user1"], domain="github.com"),
        _found("Reddit", "Social", links=[], domain="reddit.com", url="https://reddit.com/user/user1"),
    ]
    inv.result_index = {r.source: r for r in inv.results}
    correlations = correlate(inv)
    cross = [c for c in correlations if c.type == "public_cross_link"]
    assert cross
    assert cross[0].source_a == "GitHub" and cross[0].source_b == "Reddit"
    assert cross[0].confidence == "likely"  # username present in the link


def test_username_reuse_across_categories():
    inv = Investigation.create("shareduser")
    inv.total_sources = 10
    inv.results = [
        _found("GitHub", "Developer", domain="github.com"),
        _found("Chess.com", "Gaming", domain="chess.com"),
        _found("SoundCloud", "Creative", domain="soundcloud.com"),
    ]
    inv.result_index = {r.source: r for r in inv.results}
    correlations = correlate(inv)
    reuse = [c for c in correlations if c.type == "username_reuse"]
    assert reuse
    for c in reuse:
        assert "not proof" in c.explanation or "may indicate" in c.explanation


def test_no_correlations_when_single_result():
    inv = Investigation.create("lonely")
    inv.total_sources = 10
    inv.results = [_found("GitHub", "Developer", domain="github.com")]
    inv.result_index = {r.source: r for r in inv.results}
    assert correlate(inv) == []


def test_correlation_dict_shape():
    c = Correlation("t", "A", "B", "s", "possible", "e")
    d = c.to_dict()
    assert set(d) == {"type", "source_a", "source_b", "signal", "confidence", "explanation"}
