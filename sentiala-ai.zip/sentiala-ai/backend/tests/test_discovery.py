"""Tests: public web discovery parsing and deduplication."""

from backend.app.osint.discovery import parse_results


def _ddg_page(results):
    blocks, snippets = [], []
    for url, title, snippet in results:
        blocks.append(
            f'<a rel="nofollow" class="result__a" href="{url}">{title}</a>'
        )
        snippets.append(f'<a class="result__snippet">{snippet}</a>')
    body = "<html><body>" + "".join(
        f'<div class="result results_links">{b}{s}</div>'
        for b, s in zip(blocks, snippets)
    ) + "</body></html>"
    return body


def test_parse_basic_results():
    body = _ddg_page([
        ("//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fuser%2Ftorvalds&rut=abc",
         "torvalds - Example", "Profile page of torvalds"),
        ("https://other.org/t", "Other page", "unrelated"),
    ])
    results = parse_results(body, "torvalds", "test-provider")
    assert len(results) == 2
    first = results[0]
    assert first.url == "https://example.com/user/torvalds"
    assert first.domain == "example.com"
    assert first.title == "torvalds - Example"
    assert first.confidence == "high"  # username in title
    assert results[1].confidence == "medium"


def test_urls_deduplicated():
    body = _ddg_page([
        ("https://a.com/x", "A", "s1"),
        ("https://a.com/x", "A again", "s2"),
        ("https://b.com/y", "B", "s3"),
    ])
    results = parse_results(body, "user", "test")
    assert len(results) == 2
    assert {r.url for r in results} == {"https://a.com/x", "https://b.com/y"}


def test_non_http_urls_skipped():
    body = _ddg_page([("javascript:void(0)", "X", "y")])
    assert parse_results(body, "user", "test") == []


def test_empty_page_returns_empty():
    assert parse_results("<html></html>", "user", "test") == []


def test_limit_enforced():
    rows = [(f"https://site{i}.com/{i}", f"T{i}", "s") for i in range(50)]
    results = parse_results(_ddg_page(rows), "user", "test", limit=30)
    assert len(results) == 30


def test_html_entities_stripped():
    body = _ddg_page([("https://x.com/a", "Tom & Jerry", "<b>bold</b> snippet")])
    result = parse_results(body, "user", "test")[0]
    assert result.title == "Tom & Jerry"
    assert result.snippet == "bold snippet"
