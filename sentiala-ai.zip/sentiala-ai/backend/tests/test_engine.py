"""Tests: the investigation engine against a fully mocked network."""

import asyncio

import httpx

from backend.app.config import Settings
from backend.app.models.source import SourceSpec
from backend.app.osint.engine import InvestigationEngine
from backend.app.osint.registry import SourceRegistry


def _registry():
    return SourceRegistry(
        {
            "GitHub": SourceSpec("GitHub", "Developer", "https://github.com/{u}", "high", ("page not found",)),
            "Reddit": SourceSpec("Reddit", "Social", "https://reddit.com/user/{u}", "high", ("nobody on reddit",)),
            "SlowSite": SourceSpec("SlowSite", "Social", "https://slow.example/{u}", "medium", ()),
            "BrokenSite": SourceSpec("BrokenSite", "Developer", "https://broken.example/{u}", "medium", ()),
            "WalledSite": SourceSpec("WalledSite", "Social", "https://walled.example/{u}", "low", ()),
        }
    )


def _handler(username):
    def handle(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        if "github.com" in url:
            return httpx.Response(200, text=f"<title>{username} · GitHub</title><meta name='description' content='dev'>", request=request)
        if "reddit.com" in url:
            return httpx.Response(404, text="nobody on reddit goes by that name", request=request)
        if "slow.example" in url:
            raise httpx.ConnectTimeout("timed out")
        if "broken.example" in url:
            return httpx.Response(503, text="maintenance", request=request)
        if "walled.example" in url:
            return httpx.Response(200, text="<title>Log in</title>please log in", request=request)
        return httpx.Response(200, text="ok", request=request)

    return httpx.MockTransport(handle)


def _settings():
    return Settings(
        request_timeout=5,
        max_concurrency=5,
        discovery_enabled=False,
        ai_api_key="",
    )


def test_engine_full_run_with_all_states():
    engine = InvestigationEngine(_registry(), _settings())
    from backend.app.models.investigation import Investigation

    inv = Investigation.create("targetuser")

    async def scenario():
        async with httpx.AsyncClient(transport=_handler("targetuser"), follow_redirects=True) as client:
            return await engine.run(inv, client=client)

    inv = asyncio.run(scenario())

    assert inv.status == "COMPLETED"
    by_source = {r.source: r for r in inv.results}
    assert by_source["GitHub"].status == "FOUND"
    assert by_source["Reddit"].status == "NOT_FOUND"
    assert by_source["SlowSite"].status in ("TIMEOUT", "ERROR")  # timeout surfaces as TimeoutException
    assert by_source["BrokenSite"].status == "ERROR"
    assert by_source["WalledSite"].status in ("UNCERTAIN", "FOUND", "BLOCKED")
    # errors never count as NOT_FOUND
    for name in ("SlowSite", "BrokenSite"):
        assert by_source[name].status != "NOT_FOUND"
        assert by_source[name].match_score == 0


def test_engine_completes_when_a_source_fails():
    """One failing source must not stop the whole investigation."""
    engine = InvestigationEngine(_registry(), _settings())
    from backend.app.models.investigation import Investigation

    inv = Investigation.create("targetuser")

    async def scenario():
        async with httpx.AsyncClient(transport=_handler("targetuser"), follow_redirects=True) as client:
            return await engine.run(inv, client=client)

    inv = asyncio.run(scenario())
    assert inv.status == "COMPLETED"
    assert inv.completed_count == inv.total_sources == 5
    # deduplicated: one result per source
    assert len(inv.results) == len({r.source for r in inv.results})


def test_engine_produces_score_analysis_and_timeline():
    engine = InvestigationEngine(_registry(), _settings())
    from backend.app.models.investigation import Investigation

    inv = Investigation.create("targetuser")

    async def scenario():
        async with httpx.AsyncClient(transport=_handler("targetuser"), follow_redirects=True) as client:
            return await engine.run(inv, client=client)

    inv = asyncio.run(scenario())
    assert inv.score is not None
    assert 0 <= inv.score.value <= 100
    assert inv.analysis is not None
    assert inv.analysis.analyzed_by == "local-evidence-analysis"
    assert any("initialized" in e.message.lower() for e in inv.timeline)
    assert any("finalized" in e.message.lower() for e in inv.timeline)


def test_engine_progress_dict_shape():
    engine = InvestigationEngine(_registry(), _settings())
    from backend.app.models.investigation import Investigation

    inv = Investigation.create("targetuser")

    async def scenario():
        async with httpx.AsyncClient(transport=_handler("targetuser"), follow_redirects=True) as client:
            return await engine.run(inv, client=client)

    inv = asyncio.run(scenario())
    d = inv.to_dict()
    assert d["progress"]["total"] == 5
    assert d["progress"]["completed"] == 5
    assert d["progress"]["percent"] == 100
    assert d["counts"]["found"] >= 1
