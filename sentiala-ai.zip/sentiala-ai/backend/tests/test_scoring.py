"""Tests: transparent exposure scoring."""

from backend.app.models.investigation import Investigation
from backend.app.models.source import DiscoveryResult, Evidence, SourceResult
from backend.app.osint.registry import SourceRegistry
from backend.app.osint.scoring import compute_exposure_score


def _inv(found_specs, discovery=0):
    inv = Investigation.create("scorer")
    inv.total_sources = 100
    inv.results = []
    for platform, category, links in found_specs:
        inv.results.append(
            SourceResult(
                source=platform,
                category=category,
                url=f"https://x/{platform}",
                status="FOUND",
                confidence="medium",
                evidence=Evidence(username_found=True, page_title_available=True,
                                  domain="x", public_links=links),
            )
        )
    inv.result_index = {r.source: r for r in inv.results}
    inv.discovery = [
        DiscoveryResult(f"https://d{i}.com", None, f"d{i}.com", None, "test")
        for i in range(discovery)
    ]
    return inv


def test_empty_investigation_scores_low():
    score = compute_exposure_score(_inv([]), SourceRegistry())
    assert 0 <= score.value <= 100
    assert score.value < 10


def test_score_bounds():
    registry = SourceRegistry()
    big = _inv([(f"p{i}", "Social", [f"https://ext{i%20}.com/x"]) for i in range(40)], discovery=25)
    score = compute_exposure_score(big, registry)
    assert 0 <= score.value <= 100
    assert score.value > 50


def test_more_profiles_do_not_lower_score():
    registry = SourceRegistry()
    small = compute_exposure_score(_inv([("a", "Social", [])]), registry)
    large = compute_exposure_score(
        _inv([(f"p{i}", "Social", []) for i in range(10)]), registry
    )
    assert large.value >= small.value


def test_breakdown_contains_all_components():
    score = compute_exposure_score(_inv([("a", "Social", [])]), SourceRegistry())
    assert set(score.components) == {
        "profile_breadth", "category_breadth", "public_links",
        "metadata_availability", "username_reuse", "web_discovery", "domain_diversity",
    }
    assert all(0 <= v <= 100 for v in score.components.values())


def test_discovery_counts_toward_score():
    registry = SourceRegistry()
    no_disc = compute_exposure_score(_inv([("a", "Social", [])]), registry)
    with_disc = compute_exposure_score(_inv([("a", "Social", [])], discovery=10), registry)
    assert with_disc.components["web_discovery"] > no_disc.components["web_discovery"]


def test_score_is_not_mysterious():
    """The score must carry a visible component breakdown."""
    score = compute_exposure_score(_inv([("a", "Social", []), ("b", "Gaming", [])]), SourceRegistry())
    d = score.to_dict()
    assert d["value"] == score.value
    assert len(d["components"]) == 7
