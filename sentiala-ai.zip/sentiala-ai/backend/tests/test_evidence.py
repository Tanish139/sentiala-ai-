"""Tests: evidence parsing - honest state classification."""

import httpx
import pytest

from backend.app.models.source import SourceSpec
from backend.app.osint.evidence import build_result


GITHUB = SourceSpec("GitHub", "Developer", "https://github.com/{u}", "high", ("page not found",))
SOFT = SourceSpec("SoftSite", "Social", "https://soft.example/{u}", "low", ())


def _response(status=200, body="", url="https://github.com/torvalds", history=None):
    request = httpx.Request("GET", url)
    return httpx.Response(status, text=body, request=request, history=history or [])


def test_found_with_title_and_description():
    body = """
    <html><title>torvalds (Linus) · GitHub</title>
    <meta name="description" content="Developer profile of torvalds">
    <a href="https://example.org/project">project</a></html>"""
    result = build_result(GITHUB, "torvalds", response=_response(200, body))
    assert result.status == "FOUND"
    assert result.evidence.username_found
    assert result.evidence.page_title_available
    assert result.evidence.description_available
    assert result.evidence.public_links_available
    assert result.evidence.public_links == ["https://example.org/project"]
    assert result.match_score >= 70


def test_404_is_not_found():
    result = build_result(GITHUB, "torvalds", response=_response(404, "Page not found"))
    assert result.status == "NOT_FOUND"
    assert result.match_score == 0


def test_200_with_error_hint_is_not_found():
    body = "<html><title>GitHub</title><body>page not found anywhere</body></html>"
    result = build_result(GITHUB, "torvalds", response=_response(200, body))
    assert result.status == "NOT_FOUND"


def test_500_is_error_never_not_found():
    result = build_result(GITHUB, "torvalds", response=_response(500, "oops"))
    assert result.status == "ERROR"
    assert result.status != "NOT_FOUND"


def test_403_is_blocked():
    result = build_result(GITHUB, "torvalds", response=_response(403, "forbidden"))
    assert result.status == "BLOCKED"


def test_timeout_is_timeout_not_not_found():
    result = build_result(GITHUB, "torvalds", error=httpx.ReadTimeout("too slow"))
    assert result.status == "TIMEOUT"


def test_network_error_is_error():
    result = build_result(GITHUB, "torvalds", error=httpx.ConnectError("no route"))
    assert result.status == "ERROR"


def test_js_page_without_username_is_uncertain():
    """200 page where the username is not visible must NOT be FOUND."""
    body = "<html><title>SoftSite</title><body>Enable JavaScript to view profiles.</body></html>"
    result = build_result(SOFT, "torvalds", response=_response(200, body, url="https://soft.example/torvalds"))
    assert result.status == "UNCERTAIN"
    assert result.status != "FOUND"
    assert "verify" in result.note.lower() or "javascript" in result.note.lower()


def test_redirect_to_login_wall_is_blocked():
    request = httpx.Request("GET", "https://soft.example/torvalds")
    redirect = httpx.Response(302, request=request)
    final = httpx.Response(
        200,
        text="<html><title>Log in</title></html>",
        request=httpx.Request("GET", "https://soft.example/login"),
        history=[redirect],
    )
    result = build_result(SOFT, "torvalds", response=final)
    assert result.status == "BLOCKED"
    assert "redirect" in result.note.lower()


def test_og_description_used_when_meta_missing():
    body = """
    <html><title>softsite</title>
    <meta property="og:description" content="Public profile of torvalds"></html>"""
    result = build_result(SOFT, "torvalds", response=_response(200, body, url="https://soft.example/torvalds"))
    assert result.evidence.description_available
    assert result.evidence.description == "Public profile of torvalds"


def test_probe_only_lowerers_confidence():
    probe = SourceSpec("Probe", "Social", "https://p.example/{u}", "high", (), True)
    body = f"<html><title>probe</title><body>match for probeuser here</body></html>"
    result = build_result(probe, "probeuser", response=_response(200, body, url="https://p.example/probeuser"))
    assert result.status == "FOUND"
    assert result.confidence == "low"
    assert "search page" in result.note.lower()


def test_evidence_dict_shape():
    body = "<html><title>torvalds</title></html>"
    result = build_result(GITHUB, "torvalds", response=_response(200, body))
    d = result.to_dict()
    assert d["platform"] == "GitHub"
    assert set(d["public_evidence"]) >= {
        "username_found", "page_title_available", "description_available", "public_links_available"
    }
